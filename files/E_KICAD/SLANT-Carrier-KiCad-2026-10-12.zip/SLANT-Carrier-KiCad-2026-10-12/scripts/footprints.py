"""Writes the SLANT.pretty footprint library for the carrier board (KiCad 7 format), from the vendors' own drawings.
Every dimension's source is in the footprint's descr field and in the README ("Footprints").
Coordinates are KiCad's: x right, y down, in the footprint's own frame, viewed from the component side."""
import os, uuid

LIB = "SLANT.pretty"
NS = uuid.UUID("6b0e4f3e-9d8a-4b55-8a8e-5f1a2c3d4e60")


def U(*k):
    return str(uuid.uuid5(NS, "/".join(map(str, k))))


def f(v):
    return f"{v:.4f}".rstrip("0").rstrip(".") if isinstance(v, float) else str(v)


class FP:
    def __init__(self, name, descr, tags, tht=False):
        self.name, self.descr, self.tags, self.is_tht = name, descr, tags, tht
        self.items = []

    def pad(self, num, kind, shape, x, y, w, h, layers, drill=None, extra=""):
        d = f" (drill {drill})" if drill is not None and not isinstance(drill, tuple) else (
            f" (drill oval {f(drill[0])} {f(drill[1])})" if drill is not None else "")
        self.items.append(f'  (pad "{num}" {kind} {shape} (at {f(x)} {f(y)}) (size {f(w)} {f(h)}){d} '
                          f'(layers {layers}){extra} (tstamp {U(self.name, "pad", num, x, y)}))')

    def smd(self, num, x, y, w, h, mask=0.05, rr=None, layers='"F.Cu" "F.Paste" "F.Mask"'):
        shape = "roundrect" if rr else "rect"
        extra = f" (roundrect_rratio {rr})" if rr else ""
        extra += f" (solder_mask_margin {mask})" if mask is not None else ""
        self.pad(num, "smd", shape, x, y, w, h, layers, extra=extra)

    def tht(self, num, x, y, d, drill, shape="circle"):
        self.pad(num, "thru_hole", shape, x, y, d, d, '"*.Cu" "*.Mask"', drill=drill)

    def rect(self, layer, x0, y0, x1, y1, w=0.05):
        self.items.append(f'  (fp_rect (start {f(x0)} {f(y0)}) (end {f(x1)} {f(y1)}) (stroke (width {w}) (type solid)) '
                          f'(fill none) (layer "{layer}") (tstamp {U(self.name, layer, x0, y0, x1, y1)}))')

    def line(self, layer, x0, y0, x1, y1, w=0.12):
        self.items.append(f'  (fp_line (start {f(x0)} {f(y0)}) (end {f(x1)} {f(y1)}) (stroke (width {w}) (type solid)) '
                          f'(layer "{layer}") (tstamp {U(self.name, "l", layer, x0, y0, x1, y1)}))')

    def circle(self, layer, x, y, r, w=0.12):
        self.items.append(f'  (fp_circle (center {f(x)} {f(y)}) (end {f(x + r)} {f(y)}) (stroke (width {w}) (type solid)) '
                          f'(fill none) (layer "{layer}") (tstamp {U(self.name, "c", layer, x, y)}))')

    def body(self, w, h, crt=0.25, pin1=None, silk=True):
        self.rect("F.Fab", -w / 2, -h / 2, w / 2, h / 2, 0.1)
        self.rect("F.CrtYd", -w / 2 - crt, -h / 2 - crt, w / 2 + crt, h / 2 + crt, 0.05)
        if silk:
            self.rect("F.SilkS", -w / 2 - 0.1, -h / 2 - 0.1, w / 2 + 0.1, h / 2 + 0.1, 0.12)
        if pin1:
            self.circle("F.SilkS", pin1[0], pin1[1], 0.15, 0.3)

    def crtyd_pads(self, x0, y0, x1, y1):
        self.rect("F.CrtYd", x0, y0, x1, y1, 0.05)

    def write(self, ylab=3.0):
        attr = "through_hole" if self.is_tht else "smd"
        s = [f'(footprint "{self.name}" (version 20221018) (generator slant_footprints)',
             '  (layer "F.Cu")', f'  (descr "{self.descr}")', f'  (tags "{self.tags}")', f'  (attr {attr})',
             f'  (fp_text reference "REF**" (at 0 {-ylab}) (layer "F.SilkS") (effects (font (size 1 1) (thickness 0.15))) (tstamp {U(self.name, "ref")}))',
             f'  (fp_text value "{self.name}" (at 0 {ylab}) (layer "F.Fab") (effects (font (size 1 1) (thickness 0.15))) (tstamp {U(self.name, "val")}))',
             f'  (fp_text user "${{REFERENCE}}" (at 0 0) (layer "F.Fab") (effects (font (size 0.5 0.5) (thickness 0.08))) (tstamp {U(self.name, "fabref")}))']
        s += self.items + [")"]
        open(f"{LIB}/{self.name}.kicad_mod", "w").write("\n".join(s) + "\n")


os.makedirs(LIB, exist_ok=True)

# ------------------------------------------------------------------ TI TPS26636, PWP0020T (HTSSOP-20)
p = FP("TI_PWP0020T_HTSSOP-20_P0.65mm_EP3.4x6.5mm",
       "TI PWP0020T (TPS2663 datasheet SLVSE94G, drawing 4224598/A, example board layout): pads 1.5 x 0.45, pitch 0.65, "
       "rows 5.8 apart; thermal pad copper 3.4 x 6.5, solder-mask-defined opening 2.96 x 2.96; optional vias 3 x 3 at 1.3 "
       "(TI shows 0.2 drill; 0.3 drill used here, the default minimum). Mask 0.05 on signal pads.", "HTSSOP-20 PWP TPS26636")
for i in range(10):
    y = -2.925 + 0.65 * i
    p.smd(str(i + 1), -2.90, y, 1.5, 0.45, rr=0.25)
    p.smd(str(20 - i), 2.90, y, 1.5, 0.45, rr=0.25)
p.smd("21", 0, 0, 3.4, 6.5, mask=None, layers='"F.Cu"')
p.smd("21", 0, 0, 2.96, 2.96, mask=0, layers='"F.Cu" "F.Paste" "F.Mask"')
for ix in (-1, 0, 1):
    for iy in (-1, 0, 1):
        p.tht("21", 1.3 * ix, 1.3 * iy, 0.6, 0.3)
p.body(4.4, 6.5, silk=False, pin1=(-3.9, -3.5))
p.crtyd_pads(-3.9, -3.55, 3.9, 3.55)
p.write(4.5)

# ------------------------------------------------------------------ TI TPS25947, RPW0010A (VQFN-HR-10, 2 x 2)
p = FP("TI_RPW0010A_VQFN-HR-10_2x2mm",
       "TI RPW0010A (drawing 4225183/A, MPQF568; TPS25947 datasheet SLVSFC9C): L-shaped corner pads (bar 0.60 x 0.30 "
       "plus 0.25 x 0.35 leg), side pads 0.60 x 0.25, IN and OUT bars 0.30 x 2.40, gap 0.20; mask 0.05 max, NSMD. "
       "Pin 1 top left; pins 1-4 down the left, 5 IN and 6 OUT in the centre, 7-10 up the right.", "VQFN-HR RPW TPS25947")
for num, sx in (("1", -1), ("10", 1)):
    p.smd(num, 0.90 * sx, -0.70, 0.60, 0.30); p.smd(num, 0.725 * sx, -1.025, 0.25, 0.35)
for num, sx in (("4", -1), ("7", 1)):
    p.smd(num, 0.90 * sx, 0.70, 0.60, 0.30); p.smd(num, 0.725 * sx, 1.025, 0.25, 0.35)
p.smd("2", -0.90, -0.225, 0.60, 0.25); p.smd("3", -0.90, 0.225, 0.60, 0.25)
p.smd("9", 0.90, -0.225, 0.60, 0.25); p.smd("8", 0.90, 0.225, 0.60, 0.25)
p.smd("5", -0.25, 0, 0.30, 2.40); p.smd("6", 0.25, 0, 0.30, 2.40)
p.body(2.0, 2.0, silk=False, pin1=(-1.5, -1.3))
p.crtyd_pads(-1.45, -1.45, 1.45, 1.45)
p.write(2.2)

# ------------------------------------------------------------------ TI TPS73801, DCQ0006A (SOT-223, 5 leads + tab 6)
p = FP("TI_DCQ0006A_SOT-223_5Lead_Tab6",
       "TI DCQ0006A (TPS73801 datasheet SLVS915D, drawing 4214845/C): five lead pads 2.05 x 0.65 at pitch 1.27, tab "
       "pad 6 (GND) 2.05 x 3.2, lead row to tab 6.0; mask 0.07; optional tab vias 0.2.", "SOT-223 DCQ TPS73801")
for i in range(5):
    p.smd(str(i + 1), -3.00, -2.54 + 1.27 * i, 2.05, 0.65, mask=0.07)
p.smd("6", 3.00, 0, 2.05, 3.2, mask=0.07)
p.body(3.5, 6.5, silk=False, pin1=(-4.3, -3.2))
p.crtyd_pads(-4.3, -3.6, 4.3, 3.6)
p.write(4.6)

# ------------------------------------------------------------------ TI TPS3435, DDF0008A (SOT-23-THIN-8)
p = FP("TI_DDF0008A_SOT-23-THIN-8",
       "TI DDF0008A (TPS3435 datasheet SNVSCF7A, drawing 4222047/E): pads 1.05 x 0.45, pitch 0.65, rows 2.6 apart; "
       "mask 0.05.", "SOT-23-8 DDF TPS3435")
for i in range(4):
    y = -0.975 + 0.65 * i
    p.smd(str(i + 1), -1.30, y, 1.05, 0.45, rr=0.25)
    p.smd(str(8 - i), 1.30, y, 1.05, 0.45, rr=0.25)
p.body(1.6, 2.9, silk=False, pin1=(-2.1, -1.4))
p.crtyd_pads(-2.1, -1.7, 2.1, 1.7)
p.write(2.6)

# ------------------------------------------------------------------ TDK CCG10 (DIP, through hole)
p = FP("TDK_CCG10_DIP-6_THT",
       "TDK-Lambda CCG10 DIP (outline C298-02-01B; manual C286-04-11E Table 8-1 and Fig 8-1(b), top view): body "
       "19.0 x 12.4 x 11.5; pins 0.7 x 0.5, 3.5 long; hole 1.2, land 2.0. Pins 1-3 (+Vin, RC, -Vin) on the left column "
       "(5.08 then 2.54), pins 6-4 (+Vout, TRM, -Vout) on the right column at 2.54, offset 1.52; columns 17.20 apart.",
       "CCG10 DC-DC TDK", tht=True)
for num, u, v in (("1", 0.90, 2.39), ("2", 0.90, 7.47), ("3", 0.90, 10.01),
                  ("6", 18.10, 3.91), ("5", 18.10, 6.45), ("4", 18.10, 8.99)):
    p.pad(num, "thru_hole", "rect" if num == "1" else "circle", u - 9.5, v - 6.2, 2.0, 2.0, '"*.Cu" "*.Mask"', drill=1.2)
p.body(19.0, 12.4, crt=0.5, pin1=(-9.0, -5.6))
p.write(7.5)

# ------------------------------------------------------------------ AEM P700L fuse, Figure 1
p = FP("AEM_P700L_Figure1",
       "AEM P700L (datasheet Oct-2025 and spec Rev M, Figure 1, 4.0 A): body 8.38 +-0.25 long (A, over the terminals) x "
       "5.97 +-0.38 wide (C) x 4.06 max high (B); land pads 2.79 (G, along the axis) x 2.54 (F), 4.06 (H) between "
       "inner edges, so centres 6.86 apart.", "fuse AEM P700L")
p.smd("1", -3.43, 0, 2.79, 2.54, mask=0.05)
p.smd("2", 3.43, 0, 2.79, 2.54, mask=0.05)
p.body(8.38, 5.97, crt=0.35)
p.write(4.0)

# ------------------------------------------------------------------ Harwin Gecko G125-MV12605L1P (male, latched)
p = FP("Harwin_G125-MV12605L1P_2x13_P1.25mm_Latch",
       "Harwin G125-MV12605L1P (drawing G125-MVXXX05LXP issue 8, sheet 4, recommended PCB layout; spec C125XX issue 15 "
       "A1.2): holes 0.55 at pitch 1.25, rows 1.25 apart, end columns 15.00 apart; latch slots 1.00 x 1.90, centres "
       "17.50 apart, long axis across the rows. Pins numbered row by row: 1-13 on one row, 14-26 on the other, 14 across "
       "from 1 (26-way order extrapolated from Harwin's 10-way drawing: TBC). Pad 0.90 (0.175 mm annular ring; KiCad's Harwin G125 footprints use 0.95), chosen for the isolation gaps between pins; "
       "latch slots unplated (a plated ring would leave 0.03 mm to the end pads; soldering the barbs needs a plated slot: TBC). Latch barbs specified for 1.6 mm boards: retention on 2.4 mm TBC. Body 20.20 x 4.90.",
       "Harwin Gecko G125 latch 2x13", tht=True)
for k in range(13):
    x = -7.5 + 1.25 * k
    p.tht(str(k + 1), x, -0.625, 0.90, 0.55, shape="rect" if k == 0 else "circle")
    p.tht(str(k + 14), x, 0.625, 0.90, 0.55)
for sx in (-1, 1):   # unplated: a plated ring would sit 0.03 mm from the end pins' pads
    p.pad("", "np_thru_hole", "oval", 8.75 * sx, 0, 1.0, 1.9, '"*.Cu" "*.Mask"', drill=(1.0, 1.9))
p.body(20.2, 4.9, crt=0.25, pin1=(-7.5, -1.5), silk=False)
p.line("F.SilkS", -10.2, -2.55, 10.2, -2.55); p.line("F.SilkS", -10.2, 2.55, 10.2, 2.55)
p.write(3.6)

# ------------------------------------------------------------------ Molex 87831-1420 (Milli-Grid, 2 x 7, vertical)
p = FP("Molex_87831-1420_2x07_P2.00mm_Vertical",
       "Molex 87831-1420 (sales drawing SD-87831-0001 Rev A25, sheets 9-10): through hole 0.90 +-0.05 at 2.00 pitch, rows "
       "2.00 apart, end holes 12.00 apart; no peg (PEG N.A.); body 16.65 x 6.30, 6.40 above the seating plane. Circuit 1 "
       "lower left in the top view with circuit 2 across the row above it (odd and even rows; only 1 and 2 are labelled). "
       "Pad 1.5 (annular ring chosen here).", "Molex Milli-Grid 87831", tht=True)
for k in range(7):
    x = -6.0 + 2.0 * k
    p.tht(str(2 * k + 1), x, 1.0, 1.5, 0.9, shape="rect" if k == 0 else "circle")
    p.tht(str(2 * k + 2), x, -1.0, 1.5, 0.9)
p.body(16.65, 6.30, crt=0.25, pin1=(-6.0, 2.6))
p.write(4.2)

# ------------------------------------------------------------------ Thermistor lead turrets (Keystone 1593-2)
p = FP("Turret_Pair_Keystone_1593-2_P5.08mm_TBC",
       "Two lead-termination turrets for a leaded thermistor (Keystone 1593-2, SnPb hot dip). Hole 1.6, pad 2.8 and "
       "5.08 spacing are placeholders: the Keystone drawing has not been read (TBC).", "turret thermistor TBC", tht=True)
p.tht("1", -2.54, 0, 2.8, 1.6); p.tht("2", 2.54, 0, 2.8, 1.6)
p.crtyd_pads(-4.2, -1.65, 4.2, 1.65)
p.rect("F.Fab", -4.0, -1.5, 4.0, 1.5, 0.1)
p.write(2.6)

# ------------------------------------------------------------------ Raspberry Pi CM5 carrier connectors
# CM5 datasheet RP-008180-DS-7 Fig 4 and Raspberry Pi's STEP RP-007222-DD-2 (module frame, top view, x 0..55, y 0..40):
# connectors centred at x 25.0, y 37.0 (pins 1-100) and y 3.0 (pins 101-200); pins 1/2 and 101/102 at the end away from
# the U.FL (x = 25.0 + 9.8); odd pins on the row toward +y in the top view. Carrier land pattern: Amphenol 10164227
# drawing Rev C sheet 4 (and Hirose DF40C-*DS-0.4V(51)): pads 0.20 x 1.14 at 0.40 pitch, 19.60 end to end, outer ends
# 3.78 apart, inner ends 1.5 apart (row centres 2.64). Mounting holes M2.5 at (3.5, 3.5) and the other three corners.
# The footprint frame is the module seen from the carrier's component side with the module above it (a normal carrier).
# Origin: module centre (27.5, 20.0). KiCad y = -(module y - 20).
p = FP("RaspberryPi_CM5_Carrier_2x_Amphenol_10164227-1004A1RLF",
       "Raspberry Pi CM5 carrier footprint: two Amphenol 10164227-1004A1RLF (4.0 mm stack). Connector positions from "
       "Raspberry Pi's STEP RP-007222-DD-2 (centres x 25.0, y 3.0 and 37.0 in the module frame); pin 1 end and odd-row "
       "side from CM5 datasheet RP-008180-DS-7 Fig 4 (read from the figure). Pads 0.20 x 1.14 at 0.40 pitch, row centres "
       "2.64 (Amphenol drawing 10164227 Rev C sheet 4; mask over the inner 0.44 mm TBC). Four M2.5 holes. Mapping of the "
       "module top view onto the carrier TBC against the CM5IO layout.", "Raspberry Pi CM5 DF40 Amphenol")
CX, CY = 27.5, 20.0
for n in range(1, 201):
    top = n <= 100
    k = n - 1 if top else n - 101
    c = k // 2
    xs = 34.8 - 0.4 * c
    yc = 37.0 if top else 3.0
    ys = yc + (1.32 if (n % 2 == 1) else -1.32)
    p.smd(str(n), xs - CX, -(ys - CY), 0.20, 1.14, mask=0.05, layers='"F.Cu" "F.Paste" "F.Mask"')
for hx, hy in ((3.5, 3.5), (51.5, 3.5), (3.5, 36.5), (51.5, 36.5)):
    p.pad("", "np_thru_hole", "circle", hx - CX, -(hy - CY), 2.7, 2.7, '"*.Cu" "*.Mask"', drill=2.7)
for yc in (3.0, 37.0):   # connector bodies 22.60 x 3.2 (Amphenol table, A and C)
    p.rect("F.Fab", 25.0 - 11.3 - CX, -(yc + 1.6 - CY), 25.0 + 11.3 - CX, -(yc - 1.6 - CY), 0.1)
    p.rect("F.CrtYd", 25.0 - 11.55 - CX, -(yc + 2.15 - CY), 25.0 + 11.55 - CX, -(yc - 2.15 - CY), 0.05)
    p.rect("F.SilkS", 25.0 - 11.4 - CX, -(yc + 2.0 - CY), 25.0 + 11.4 - CX, -(yc - 2.0 - CY), 0.12)
p.rect("F.Fab", -27.5, -20.0, 27.5, 20.0, 0.1)   # module outline
p.circle("F.SilkS", 35.2 - CX, -(37.0 + 2.4 - CY), 0.2, 0.3)
p.write(21.5)
print("written", len(os.listdir(LIB)))
