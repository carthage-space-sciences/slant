"""SLANT carrier board, option A4 (CM5): schematic content as data. Revision A4-3.

Every pin number and name comes from the vendor datasheet named in each symbol's 'ds' field, read on
10 Oct 2026 (see README). Figure-only items (TDK CCG filter and pin positions) were read from the rendered
vendor PDF. Values marked 'derived' are computed here from datasheet equations. A4-3 fits commercial parts
where the space-grade variant is not buyable, and applies NASA EEE-INST-002 derating.
"""

# ----------------------------------------------------------------------------------------------- symbols
# pin tuple: (number, name, electrical type, side 'L' or 'R')
P, PI, PO, I, O, B, OC, TS, NC = "passive", "power_in", "power_out", "input", "output", "bidirectional", \
    "open_collector", "tri_state", "no_connect"

SYM = {}


def ic(name, pins, ds, desc):
    SYM[name] = dict(kind="ic", pins=pins, ds=ds, desc=desc)


def two(name, desc, graphic):
    SYM[name] = dict(kind="two", pins=[("1", "~", P, "L"), ("2", "~", P, "R")], ds="", desc=desc, g=graphic)


for nm, d, g in (("R", "Resistor", "R"), ("C", "Capacitor", "C"), ("C_Pol", "Polarized capacitor", "CP"),
                 ("L", "Inductor", "L"), ("Fuse", "Fuse", "F"), ("Crystal", "Crystal", "Y"),
                 ("Thermistor", "NTC thermistor", "RT")):
    two(nm, d, g)
SYM["D_Schottky"] = dict(kind="two", pins=[("1", "K", P, "L"), ("2", "A", P, "R")], ds="", desc="Schottky diode (pin 1 cathode)", g="D")
SYM["TestPoint"] = dict(kind="one", pins=[("1", "~", P, "L")], ds="", desc="Test point", g="TP")
SYM["MountingHole"] = dict(kind="one", pins=[("1", "~", P, "L")], ds="", desc="Mounting hole, plated, PC/104 rod", g="MH")
SYM["PWR_FLAG"] = dict(kind="flag", pins=[("1", "pwr", PO, "L")], ds="", desc="Power flag for ERC")

SYM["D_TVS"] = dict(kind="two", pins=[("1", "K", P, "L"), ("2", "A", P, "R")], ds="", desc="Unidirectional TVS diode (pin 1 cathode)", g="D")

ic("TPS2663", [
    ("1", "IN", PI, "L"), ("2", "IN", PI, "L"), ("3", "IN", PI, "L"), ("6", "IN_SYS", PI, "L"),
    ("7", "UVLO", I, "L"), ("8", "PLIM", I, "L"), ("12", "MODE", I, "L"), ("13", "SHDN", I, "L"),
    ("9", "GND", PI, "L"), ("21", "EP", PI, "L"),
    ("18", "OUT", PO, "R"), ("19", "OUT", PO, "R"), ("20", "OUT", PO, "R"), ("4", "B_GATE", O, "R"),
    ("5", "DRV", O, "R"), ("10", "dVdT", P, "R"), ("11", "ILIM", P, "R"), ("14", "IMON", O, "R"),
    ("15", "FLT", OC, "R"), ("16", "PGTH", I, "R"), ("17", "PGOOD", OC, "R")],
   "https://www.ti.com/lit/ds/symlink/tps2663.pdf",
   "eFuse 4.5-60 V, 6 A, HTSSOP-20 (PWP); TPS26636: output clamp 35.7-39 V")

ic("CCG10", [("1", "+VIN", PI, "L"), ("2", "RC", I, "L"), ("3", "-VIN", PI, "L"),
             ("6", "+VOUT", PO, "R"), ("5", "TRM", P, "R"), ("4", "-VOUT", PI, "R")],
   "https://product.tdk.com/system/files/dam/doc/product/power/switching-power/dc-dc-converter/instruction_manual/ccg1r5_3_6_10_apl.pdf",
   "Isolated DC-DC, 9-36 V to 5 V 2 A, DIP")

ic("TPS25947", [("5", "IN", PI, "L"), ("1", "EN/UVLO", I, "L"), ("2", "OVLO", I, "L"), ("8", "GND", PI, "L"),
                ("6", "OUT", PO, "R"), ("4", "~{FLT}", OC, "R"), ("3", "AUXOFF", OC, "R"), ("7", "DVDT", P, "R"),
                ("9", "ILM", P, "R"), ("10", "ITIMER", P, "R")],
   "https://www.ti.com/lit/ds/symlink/tps25947.pdf", "eFuse 2.7-23 V, 5.5 A, VQFN-HR-10 (RPW); TPS259470x pinout")

ic("INA293B", [("4", "IN+", I, "L"), ("5", "IN-", I, "L"), ("3", "VS", PI, "R"), ("2", "GND", PI, "R"),
               ("1", "OUT", O, "R")],
   "https://www.ti.com/lit/ds/symlink/ina293.pdf", "Current-sense amplifier, B pinout, SOT-23-5 (DBV)")

ic("TPS73801", [("1", "IN", PI, "L"), ("5", "EN", I, "L"), ("3", "GND", PI, "L"), ("6", "GND/TAB", PI, "L"),
                ("2", "OUT", PO, "R"), ("4", "FB", I, "R")],
   "https://www.ti.com/lit/ds/symlink/tps73801.pdf", "1 A LDO, adjustable, SOT-223 (DCQ): five leads, tab is pin 6")

ic("TL7700", [("5", "VCC", PI, "L"), ("2", "SENSE", I, "L"), ("1", "CT", P, "L"), ("4", "GND", PI, "L"),
              ("8", "RESET", OC, "R"), ("3", "NC", NC, "R"), ("6", "NC", NC, "R"), ("7", "NC", NC, "R")],
   "https://www.ti.com/lit/ds/symlink/tl7700.pdf", "Supply voltage supervisor, TSSOP-8 (PW)")

ic("TPS3435C", [("8", "VDD", PI, "L"), ("3", "WDI", I, "L"), ("2", "MR", I, "L"), ("4", "GND", PI, "L"),
                ("7", "WDO", OC, "R"), ("1", "SET0", I, "R"), ("5", "SET1", I, "R"), ("6", "WD-EN", I, "R")],
   "https://www.ti.com/lit/gpn/TPS3435", "Timeout watchdog, pinout option C, SOT-23-THN-8 (DDF)")

ic("REF50", [("2", "VIN", PI, "L"), ("4", "GND", PI, "L"), ("5", "TRIM/NR", P, "L"), ("1", "DNC", NC, "L"),
             ("6", "VOUT", PO, "R"), ("3", "TEMP", O, "R"), ("7", "NC", NC, "R"), ("8", "DNC", NC, "R")],
   "https://www.ti.com/lit/gpn/REF50", "Precision voltage reference, I/AI grade pinout, SOIC-8 (D)")

ic("MCP2518FD", [("14", "VDD", PI, "L"), ("13", "nCS", I, "L"), ("10", "SCK", I, "L"), ("11", "SDI", I, "L"),
                 ("12", "SDO", TS, "L"), ("4", "INT", OC, "L"), ("7", "VSS", PI, "L"),
                 ("1", "TXCAN", O, "R"), ("2", "RXCAN", I, "R"), ("6", "OSC1", I, "R"), ("5", "OSC2", O, "R"),
                 ("3", "CLKO/SOF", O, "R"), ("8", "INT1/GPIO1", B, "R"), ("9", "INT0/GPIO0/XSTBY", B, "R")],
   "https://ww1.microchip.com/downloads/aemDocuments/documents/APID/ProductDocuments/DataSheets/MCP2518FD-External-CAN-FD-Controller-with-SPI-Interface-DS20006027.pdf",
   "CAN FD controller, SPI, SOIC-14 (SL)")

ic("Crystal_4pad", [("1", "X1", P, "L"), ("2", "GND", P, "L"), ("3", "X2", P, "R"), ("4", "GND", P, "R")],
   "https://abracon.com/datasheets/ABM8AIG.pdf", "Crystal, 3.2 x 2.5 mm 4-pad (pads 2 and 4 ground; confirm on drawing)")

ic("SN65HVD233", [("3", "VCC", PI, "L"), ("1", "D", I, "L"), ("4", "R", O, "L"), ("5", "LBK", I, "L"),
                  ("2", "GND", PI, "L"), ("7", "CANH", B, "R"), ("6", "CANL", B, "R"), ("8", "RS", I, "R")],
   "https://www.ti.com/lit/ds/symlink/sn65hvd233.pdf", "3.3 V CAN transceiver, SOIC-8 (D)")

ic("ESD2CAN24", [("1", "IO1", P, "L"), ("2", "IO2", P, "L"), ("3", "GND", P, "R")],
   "https://www.ti.com/lit/ds/symlink/esd2can24-q1.pdf", "Dual 24 V ESD diode for CAN, SOT-23 (DBZ)")

ic("TPS22919", [("1", "IN", PI, "L"), ("3", "ON", I, "L"), ("2", "GND", PI, "L"), ("4", "NC", NC, "L"),
                ("6", "VOUT", PO, "R"), ("5", "QOD", P, "R")],
   "https://www.ti.com/lit/ds/symlink/tps22919.pdf", "Load switch 1.6-5.5 V, 1.5 A, SC-70-6 (DCK)")

ic("BAS70W", [("1", "A", P, "L"), ("2", "NC", NC, "L"), ("3", "K", P, "R")],
   "https://assets.nexperia.com/documents/data-sheet/BAS70W-Q.pdf", "Schottky diode 70 V 70 mA, SOT-323")

ic("SN65C1168E", [("16", "VCC", PI, "L"), ("15", "1D", I, "L"), ("4", "1DE", I, "L"), ("9", "2D", I, "L"),
                  ("12", "2DE", I, "L"), ("3", "1R", O, "L"), ("5", "2R", O, "L"), ("8", "GND", PI, "L"),
                  ("14", "1Y", O, "R"), ("13", "1Z", O, "R"), ("10", "2Y", O, "R"), ("11", "2Z", O, "R"),
                  ("2", "1A", I, "R"), ("1", "1B", I, "R"), ("6", "2A", I, "R"), ("7", "2B", I, "R")],
   "https://www.ti.com/lit/ds/symlink/sn65c1168e.pdf", "Dual RS-422 driver and receiver, TSSOP-16 (PW)")

ic("ADC128S102", [("2", "VA", PI, "L"), ("13", "VD", PI, "L"), ("1", "~{CS}", I, "L"), ("16", "SCLK", I, "L"),
                  ("14", "DIN", I, "L"), ("15", "DOUT", TS, "L"), ("3", "AGND", PI, "L"), ("12", "DGND", PI, "L"),
                  *[(str(n), f"IN{n - 4}", I, "R") for n in range(4, 12)]],
   "https://www.ti.com/lit/ds/symlink/adc128s102.pdf", "8-ch 12-bit SAR ADC, SPI, TSSOP-16 (PW/MT)")

ic("TPD4E05U06", [("1", "D1+", P, "L"), ("2", "D1-", P, "L"), ("4", "D2+", P, "L"), ("5", "D2-", P, "L"),
                  ("3", "GND", P, "R"), ("8", "GND", P, "R"), ("6", "NC", NC, "R"), ("7", "NC", NC, "R"),
                  ("9", "NC", NC, "R"), ("10", "NC", NC, "R")],
   "https://www.ti.com/lit/ds/symlink/tpd4e05u06.pdf", "Quad 5.5 V ESD array, USON-10 (DQA)")


def conn(name, n, ds, desc, names=None, rows=2):
    pins = []
    for k in range(1, n + 1):
        nm = names[k - 1] if names else str(k)
        side = ("L" if k % 2 else "R") if rows == 2 else ("L" if k <= n // 2 else "R")
        pins.append((str(k), nm, P, side))
    SYM[name] = dict(kind="ic", pins=pins, ds=ds, desc=desc)


conn("Conn_2x13", 26, "https://www.harwin.com/products/G125-MV12605L1P/",
     "Harwin Gecko G125-MV12605L1P, 1.25 mm, 2 x 13, latched, through-hole; pins 1-13 one row, 14-26 the other", rows=1)
conn("Conn_2x07_Molex87831", 14, "https://www.molex.com/en-us/products/part-detail/878311420",
     "Molex Milli-Grid 87831-1420, 2 mm, 2x7, shrouded")
conn("Conn_16_Flex", 16, "", "Flex link to XIMEA head, 16-way (connector TBC with XIMEA)", rows=1)

# CM5 connectors (CM5 datasheet RP-008180-DS-7, Table 4). Pins 1-100 top connector, 101-200 bottom.
CM5_PINS = {
    1: "GND", 2: "GND", 3: "Ethernet_Pair3_P", 4: "Ethernet_Pair1_P", 5: "Ethernet_Pair3_N", 6: "Ethernet_Pair1_N",
    7: "GND", 8: "GND", 9: "Ethernet_Pair2_N", 10: "Ethernet_Pair0_N", 11: "Ethernet_Pair2_P", 12: "Ethernet_Pair0_P",
    13: "GND", 14: "GND", 15: "Ethernet_nLED3", 16: "Fan_Tacho", 17: "Ethernet_nLED2", 18: "Ethernet_SYNC_OUT",
    19: "Fan_PWM", 20: "EEPROM_nWP", 21: "LED_nACT", 22: "GND", 23: "GND", 24: "GPIO26", 25: "GPIO21", 26: "GPIO19",
    27: "GPIO20", 28: "GPIO13", 29: "GPIO16", 30: "GPIO6", 31: "GPIO12", 32: "GND", 33: "GND", 34: "GPIO5",
    35: "ID_SC", 36: "ID_SD", 37: "GPIO7", 38: "GPIO11", 39: "GPIO8", 40: "GPIO9", 41: "GPIO25", 42: "GND",
    43: "GND", 44: "GPIO10", 45: "GPIO24", 46: "GPIO22", 47: "GPIO23", 48: "GPIO27", 49: "GPIO18", 50: "GPIO17",
    51: "GPIO15", 52: "GND", 53: "GND", 54: "GPIO4", 55: "GPIO14", 56: "GPIO3", 57: "SD_CLK", 58: "GPIO2",
    59: "GND", 60: "GND", 61: "SD_DAT3", 62: "SD_CMD", 63: "SD_DAT0", 64: "SD_DAT5", 65: "GND", 66: "GND",
    67: "SD_DAT1", 68: "SD_DAT4", 69: "SD_DAT2", 70: "SD_DAT7", 71: "GND", 72: "SD_DAT6", 73: "SD_VDD_OVERRIDE",
    74: "GND", 75: "SD_PWR_ON", 76: "VBAT", 77: "5V", 78: "GPIO_VREF", 79: "5V", 80: "SCL0", 81: "5V", 82: "SDA0",
    83: "5V", 84: "CM5_3.3V", 85: "5V", 86: "CM5_3.3V", 87: "5V", 88: "CM5_1.8V", 89: "WL_nDisable",
    90: "CM5_1.8V", 91: "BT_nDisable", 92: "PWR_Button", 93: "nRPIBOOT", 94: "CC1", 95: "LED_nPWR", 96: "CC2",
    97: "CAM_GPIO0", 98: "GND", 99: "PMIC_Enable", 100: "CAM_GPIO1",
    101: "USB_OTG_ID", 102: "PCIe_CLK_nREQ", 103: "USB_N", 104: "PCIE_nWAKE", 105: "USB_P", 106: "PCIE_PWR_EN",
    107: "GND", 108: "GND", 109: "PCIe_nRST", 110: "PCIe_CLK_P", 111: "VBUS_EN", 112: "PCIe_CLK_N", 113: "GND",
    114: "GND", 115: "MIPI0_D0_N", 116: "PCIe_RX_P", 117: "MIPI0_D0_P", 118: "PCIe_RX_N", 119: "GND", 120: "GND",
    121: "MIPI0_D1_N", 122: "PCIe_TX_P", 123: "MIPI0_D1_P", 124: "PCIe_TX_N", 125: "GND", 126: "GND",
    127: "MIPI0_C_N", 128: "USB3-0-RX_N", 129: "MIPI0_C_P", 130: "USB3-0-RX_P", 131: "GND", 132: "GND",
    133: "MIPI0_D2_N", 134: "USB3-0-DP", 135: "MIPI0_D2_P", 136: "USB3-0-DM", 137: "GND", 138: "GND",
    139: "MIPI0_D3_N", 140: "USB3-0-TX_N", 141: "MIPI0_D3_P", 142: "USB3-0-TX_P", 143: "HDMI1_HOTPLUG",
    144: "GND", 145: "HDMI1_SDA", 146: "HDMI1_TX2_P", 147: "HDMI1_SCL", 148: "HDMI1_TX2_N", 149: "HDMI1_CEC",
    150: "GND", 151: "HDMI0_CEC", 152: "HDMI1_TX1_P", 153: "HDMI0_HOTPLUG", 154: "HDMI1_TX1_N", 155: "GND",
    156: "GND", 157: "USB3-1-RX_N", 158: "HDMI1_TX0_P", 159: "USB3-1-RX_P", 160: "HDMI1_TX0_N", 161: "GND",
    162: "GND", 163: "USB3-1-DP", 164: "HDMI1_CLK_P", 165: "USB3-1-DM", 166: "HDMI1_CLK_N", 167: "GND",
    168: "GND", 169: "USB3-1-TX_N", 170: "HDMI0_TX2_P", 171: "USB3-1-TX_P", 172: "HDMI0_TX2_N", 173: "GND",
    174: "GND", 175: "MIPI1_D0_N", 176: "HDMI0_TX1_P", 177: "MIPI1_D0_P", 178: "HDMI0_TX1_N", 179: "GND",
    180: "GND", 181: "MIPI1_D1_N", 182: "HDMI0_TX0_P", 183: "MIPI1_D1_P", 184: "HDMI0_TX0_N", 185: "GND",
    186: "GND", 187: "MIPI1_C_N", 188: "HDMI0_CLK_P", 189: "MIPI1_C_P", 190: "HDMI0_CLK_N", 191: "GND",
    192: "GND", 193: "MIPI1_D2_N", 194: "MIPI1_D3_N", 195: "MIPI1_D2_P", 196: "MIPI1_D3_P", 197: "GND",
    198: "GND", 199: "HDMI0_SDA", 200: "HDMI0_SCL"}
assert len(CM5_PINS) == 200 and sorted(CM5_PINS) == list(range(1, 201))


def cm5_type(nm):
    if nm == "GND" or nm == "5V":
        return PI
    if nm in ("CM5_3.3V", "CM5_1.8V"):
        return PO
    if nm == "GPIO_VREF":
        return PI
    if nm in ("WL_nDisable", "BT_nDisable", "nRPIBOOT", "PMIC_Enable", "PWR_Button", "EEPROM_nWP", "USB_OTG_ID"):
        return I
    return B


SYM["CM5"] = dict(kind="ic", ds="https://pip-assets.raspberrypi.com/categories/944-raspberry-pi-compute-module-5/documents/RP-008180-DS-7-cm5-datasheet.pdf",
                  desc="Raspberry Pi Compute Module 5; unit A = top connector pins 1-100, unit B = bottom connector pins 101-200",
                  units=[[(str(k), CM5_PINS[k], cm5_type(CM5_PINS[k]), "L" if k % 2 else "R") for k in rng]
                         for rng in (range(1, 101), range(101, 201))])

# Repeated power-output pins: KiCad's ERC flags two power outputs on one net, so only the first pin of each
# repeated power-output name stays power_out; the others are passive (same net, same function).
for _nm, _s in SYM.items():
    for _ui, _pins in enumerate(_s["units"] if "units" in _s else [_s["pins"]]):
        _seen = set()
        for _i, (_n, _name, _t, _side) in enumerate(_pins):
            if _t == PO:
                if _name in _seen:
                    _pins[_i] = (_n, _name, P, _side)
                _seen.add(_name)

# ----------------------------------------------------------------------------------------------- parts
SHEETS = [("power_entry", "Power entry, limiter and isolated converter"), ("rails", "5 V rails, switches and supervision"),
          ("cm5", "Compute module CM5"), ("interfaces", "Host interfaces: CAN and RS-422"),
          ("housekeeping", "Housekeeping ADC, reference, rail sensing and thermistors"),
          ("maint_head", "Maintenance port and head link")]

COMP = []


def add(ref, sym, value, sheet, pins, unit=1, **f):
    COMP.append(dict(ref=ref, sym=sym, value=value, sheet=sheet, pins=pins, unit=unit, f=f))


def R(ref, val, a, b, sheet, **f):
    add(ref, "R", val, sheet, {"1": a, "2": b}, **f)


def C(ref, val, a, b, sheet, **f):
    add(ref, "C", val, sheet, {"1": a, "2": b}, **f)


TBC = "TBC"
GND, PRTN = "GND", "PRI_RTN"
# Derating (NASA EEE-INST-002, README section "Derating"): ceramic capacitors at <= 60 % of rated voltage; on rails
# below 10 V, small values are 100 V rated and larger values come from lots screened to MIL-PRF-123 Group B
# (low-voltage humidity). Resistors at <= 50 % of rated power. Default sizes: resistors 0805 (0.125 W),
# capacitors 0805 unless the value names a size.
SAT = "Space-grade variant not buyable on 10 Oct 2026; commercial part fitted (KC rule)."

# ---------------- power entry
s = "power_entry"
# Rows: 1-13 and 14-26, 14 across from 1 (Harwin C125XX). Three isolation domains along the connector, each kept two
# pitches (1.6 mm pad gap) from the next: host side (bus, return and the host's thermistor) in columns 1-4; payload
# signals and ground in columns 6-12; chassis at pin 26, diagonal to payload GND (0.87 mm pad gap). Column 5 is empty.
J1 = {"1": "BUS_IN", "2": "BUS_IN", "3": "BUS_IN", "14": PRTN, "15": PRTN, "16": PRTN,
      "4": "HOST_THERM_A", "17": "HOST_THERM_B", "5": None, "18": None,
      "6": "CMD_IN_P", "19": "CMD_IN_N", "7": "TLM_P", "20": "TLM_N", "8": "BULKOUT_P", "21": "BULKOUT_N",
      "9": "BULKIN_P", "22": "BULKIN_N", "10": "PPS_IN_P", "23": "PPS_IN_N", "11": "CANH", "24": "CANL",
      "12": GND, "25": None, "13": None, "26": "CHASSIS"}
add("J1", "Conn_2x13", "Harness header", s, J1, MPN="Harwin G125-MV12605L1P",
    Mate="Harwin G125-2042696L0 housing; crimp contacts G125-0010005 (power) and G125-0020005 (signal)",
    Note="Gecko 1.25 mm, 2 x 13, through-hole. Three contacts per power rail: 1.25 A max input / 3 = 0.42 A per contact (2 A per contact simultaneous rating; EEE-INST-002 derates to the wire gauge, 26 AWG 1.4 A). Harwin numbers row by row (specification C125XX issue 15, A1.2): 1-13 on one row, 14-26 on the other, 14 across from 1; the 26-way order is extrapolated from Harwin's 10-way drawing. Each pair sits across the rows (6/19 ... 11/24); bus and return across from each other (1-3/14-16). Isolation domains (A4-5): host side in columns 1-4 (bus, return, host thermistor), column 5 empty, payload in columns 6-12, chassis at pin 26; 1.6 mm pad gap between host and payload pins, 0.87 mm between payload GND and chassis (500 Vdc after conformal coat, IPC-2221B A7 0.8 mm). Latch barbs are specified for 1.6 mm boards (drawing G125-MVXXX05LXP issue 8); the board is 2.4 mm: confirm retention with Harwin or solder the barbs.")
add("F1", "Fuse", "4 A", s, {"1": "BUS_IN", "2": "BUS_F"}, MPN="AEM P700L-72-4.0", MPN_ALT="Littelfuse 0451004.MRL (commercial)",
    Note="TDK requires an external fuse of 4 A or lower for CCG10-24 (instruction manual C286-04-11E). EEE-INST-002: <= 50 % of rating, less 0.2 %/C above 25 C: at 60 C, 1.72 A allowed against 1.25 A maximum input.")
add("D5", "D_TVS", "TVS 36 V", s, {"1": "BUS_F", "2": PRTN}, MPN="TBC: SMBJ36A class (VRWM 36 V, VC <= 60 V)",
    Note="After the fuse, so a shorted TVS opens F1. Clamp stays under the TPS26636's 67 V absolute maximum. Rating TBC against the host surge specification.")
add("U1", "TPS2663", "TPS26636PWPR", s, {
    "1": "BUS_F", "2": "BUS_F", "3": "BUS_F", "6": "BUS_F", "7": "LIM_UVLO", "8": PRTN, "12": None,
    "13": "LIM_SHDN", "9": PRTN, "21": PRTN, "18": "BUS_SW", "19": "BUS_SW", "20": "BUS_SW", "4": None, "5": None,
    "10": "LIM_DVDT", "11": "LIM_ILIM", "14": "LIM_IMON", "15": "LIM_FLT", "16": PRTN, "17": None},
    MPN="TPS26636PWPR", MPN_ALT="ZES723LCL (space grade; not buyable)",
    Note="MODE open: latch-off after an overload; the host's per-pass power cycle (or SHDN low) resets it. IN_SYS tied to IN (no blocking FET); B_GATE, DRV floating. PLIM to GND: power limit off. PGTH to GND: PGOOD unused. Output clamp 35.7-39 V protects the CCG10 from bus surges. Recommended input 4.5-60 V: 36 V bus is 60 %.")
R("R1", "604k 1%", "BUS_F", "LIM_UVLO", s, Note="UVLO divider: rising 1.2 V x (604k + 100k)/100k = 8.45 V (8.28-8.62 V); falling 1.122 V x 7.04 = 7.90 V. Above 300k as the datasheet requires. 51 uA at 36 V.")
R("R2", "100k 1%", "LIM_UVLO", PRTN, s)
R("R3", "7.15k 1%", "LIM_ILIM", PRTN, s, Note="I_OL = 18 / R_ILIM[k] = 2.52 A (range 3-30k). Maximum payload input 1.25 A at 9 V (10 W).")
R("R4", "30.1k 1%", "LIM_IMON", PRTN, s, Note="IMON 27.9 uA/A x 30.1k = 0.84 V/A; 2.1 V at the limit, under the 4 V maximum. No capacitor on IMON (datasheet). Bus side: test point only.")
C("C1", "1u 100V X7R 1206", "BUS_F", PRTN, s, Note="CIN >= 1 uF (TPS2663 surge guidance)")
C("C2", "100n 100V", "BUS_F", PRTN, s, Note="IN_SYS >= 0.1 uF")
C("C3", "22n 100V", "LIM_DVDT", PRTN, s, Note="t_dVdT = 20.8e3 x VIN x C = 12.8 ms at 28 V; inrush into about 52 uF of filter capacitance 0.11 A")
add("TP1", "TestPoint", "IMON", s, {"1": "LIM_IMON"})
add("TP2", "TestPoint", "SHDN", s, {"1": "LIM_SHDN"}, Note="SHDN internally pulled up (2.7 V open circuit). Pull low and release to reset a latched trip on the bench. Keep the trace short.")
add("TP3", "TestPoint", "FLT", s, {"1": "LIM_FLT"}, Note="Open drain, active low; bench pull-up only (no bus-side logic supply)")
C("C4", "4.7u 100V X7R 1210", "BUS_SW", PRTN, s, MPN="KYOCERA AVX 12101C475K4Z2A",
  Note="TDK quick manual Sec 8 filter C1 position, now ceramic; also the TPS2663 output capacitor (>= 0.1 uF)")
add("L1", "L", "10u", s, {"1": "BUS_SW", "2": "BUS_FILT"}, MPN="Coilcraft XGL5050-103MEC", MPN_ALT="Murata LQH5BPN100MT0L (TDK quick manual Sec 8 family)",
    Note="TDK quick manual Sec 8 filter L1, 10 uH")
C("C12", "4.7u 100V X7R 1210", "BUS_FILT", PRTN, s, MPN="KYOCERA AVX 12101C475K4Z2A", Note="TDK filter C2 (10 uF) as 2 x 4.7 uF 100 V: 36 V is 36 % of rated")
C("C65", "4.7u 100V X7R 1210", "BUS_FILT", PRTN, s, MPN="KYOCERA AVX 12101C475K4Z2A")
R("R73", "1.0 1% 1206", "BUS_FILT", "FILT_DAMP", s, MPN="Vishay CRCW12061R00FKEA",
  Note="Damping leg across C2, replacing the electrolytic's ESR. Z0 = sqrt(10 uH / 9.4 uF) = 1.03 Ohm; with Cd/C = 3, the Middlebrook optimum R is about 0.75 Ohm. 1.0 Ohm chosen; filter output impedance to confirm against the CCG10 input impedance on the bench.")
for k, ref in enumerate(("C11", "C60", "C61", "C62", "C63", "C64")):
    C(ref, "4.7u 100V X7R 1210", "FILT_DAMP", PRTN, s, MPN="KYOCERA AVX 12101C475K4Z2A",
      **({"Note": "Damping capacitor bank, 6 x 4.7 uF = 28 uF (replaces the TDK 100 uF electrolytic: wet aluminum is not listed in EEE-INST-002)"} if k == 0 else {}))
add("U3", "CCG10", "CCG10-24-05SF", s, {"1": "BUS_FILT", "2": PRTN, "3": PRTN, "6": "5V_BUS", "5": "U3_TRM", "4": GND},
    MPN="TDK-Lambda CCG10-24-05SF", Note="RC tied to -Vin: always on (negative logic). Trimmed up through TRM (R72). Pin positions from quick manual Sec 8 top view.")
R("R72", "324k SOT", "U3_TRM", GND, s, Note="Rb, TRM to -Vout, trim up: Vout = 5.02 V + 10.10 / (15 + Rb[k]) (TDK manual Table 6-2) = 5.05 V at 324k. Select on test per converter for 5.05-5.08 V measured: the +-2 % setpoint tolerance is larger than the trim. Stay below 5.25 V, TDK's 105 % OVP minimum.")
C("C13", "1000p 2kV 1812", "BUS_FILT", "5V_BUS", s, Note="TDK quick manual Sec 8 filter C3, +Vin to +Vout across the barrier")
C("C14", "1000p 2kV 1812", PRTN, GND, s, Note="TDK quick manual Sec 8 filter C4, -Vin to -Vout across the barrier")
C("C15", "10u 25V X7R 1206", "5V_BUS", GND, s, Note="TDK quick manual Sec 8 filter C5")
C("C16", "22u 25V X7R 1210", "5V_BUS", GND, s, Note="5 V bulk, 2 x 22 uF ceramic (was 100 uF tantalum); output capacitance stays under TDK's 470 uF maximum")
C("C66", "22u 25V X7R 1210", "5V_BUS", GND, s)
R("R14", "0R DNP", GND, "CHASSIS", s, DNP=True, Note="Payload ground to chassis, not fitted: the host sets the single-point ground")
C("C19", "10n 2kV DNP 1812", GND, "CHASSIS", s, DNP=True)
for k in range(1, 5):
    add(f"H{k}", "MountingHole", "PC/104 rod", s, {"1": "CHASSIS"})
add("TP4", "TestPoint", "PRI_RTN", s, {"1": PRTN})

# ---------------- rails
s = "rails"


def efuse(ref, out, en, note):
    add(ref, "TPS25947", "TPS259470LRPWR", s, {"5": "5V_BUS", "1": en, "2": "OVLO_SET", "8": GND, "6": out,
                                              "4": f"{ref}_FLT", "3": None, "7": f"{ref}_DVDT",
                                              "9": f"{ref}_ILM", "10": f"{ref}_ITMR"},
        MPN="TPS259470LRPWR", MPN_ALT="TPS7H2201-SEP (space grade; no authorized stock)", Note=note)


efuse("U5", "SW1_OUT", "SW1_EN",
      "SW1, CM5 rail. L variant: latches off after an overcurrent fault until EN/UVLO is cycled (the supervisor and watchdog do this) or power is cycled. Reverse blocking when off. AUXOFF unused (open drain, floating).")
R("R15", "1.69k 1%", "U5_ILM", GND, s, Note="R_ILM = 3334 / I_LIM: 1.97 A (1.78-2.17 A, +-10 %). Above the converter's 2 A at the high end: a CM5 fault may hiccup the CCG10 first, which also power-cycles the CM5. Set from the bench boot-peak current. ILM also carries the current monitor, 182 uA/A.")
C("C20", "2.2n 100V", "U5_DVDT", GND, s, Note="SR = 2000 / C[pF] = 0.91 V/ms: 5 V in 5.5 ms; inrush 0.91 V/ms x C_out")
C("C67", "4.7n 100V", "U5_ITMR", GND, s, Note="Overcurrent blanking t = 1.51 V x 4.7 nF / 1.8 uA = 3.9 ms, then latch-off")
C("C21", "10u 25V X7R 1206", "5V_BUS", GND, s, Note="SW1 IN")
C("C22", "10u 25V X7R 1206", "SW1_OUT", GND, s, Note="SW1 OUT")
add("TP14", "TestPoint", "SW1_FLT", s, {"1": "U5_FLT"}, Note="Open drain, active low; bench pull-up")
R("R75", "37.4k 1%", "5V_BUS", "OVLO_SET", s, Note="OVLO divider shared by SW1 and SW2: rising 1.20 V x 4.74 = 5.69 V (5.61-5.80 V); falling 1.09 V x 4.74 = 5.17 V. Opens both switches if the converter output runs high.")
R("R76", "10.0k 1%", "OVLO_SET", GND, s)
efuse("U6", "SW2_OUT", "SW2_EN", "SW2, head rail. Same configuration as SW1.")
R("R16", "3.74k 1%", "U6_ILM", GND, s, Note="R_ILM: 0.89 A (about 0.80-0.98 A; TI states +-10 % above 1 A only). Head 3.4 W uncooled = 0.68 A at 5 V (xiJ manual). Max 0.98 A + CM5 0.9 A stays under the CCG10's 2 A, so a head fault trips SW2 before the converter hiccups.")
C("C23", "2.2n 100V", "U6_DVDT", GND, s)
C("C68", "4.7n 100V", "U6_ITMR", GND, s)
C("C24", "10u 25V X7R 1206", "5V_BUS", GND, s)
C("C25", "10u 25V X7R 1206", "SW2_OUT", GND, s)
add("TP15", "TestPoint", "SW2_FLT", s, {"1": "U6_FLT"})
R("R17", "20m 1% 1206", "SW1_OUT", "5V_CM5", s, MPN="Vishay WSL1206R0200FEA", Note="CM5 rail shunt: 20 mV/A. 2.17 A limit maximum: 94 mW, 38 % of 0.25 W (metal strip limit 50 %).")
R("R18", "20m 1% 1206", "SW2_OUT", "5V_HEAD", s, MPN="Vishay WSL1206R0200FEA", Note="Head rail shunt")
C("C26", "22u 25V X7R 1210", "5V_CM5", GND, s, Note="CM5 bulk, 2 x 22 uF ceramic (was 47 uF tantalum)")
C("C69", "22u 25V X7R 1210", "5V_CM5", GND, s)
C("C27", "22u 25V X7R 1210", "5V_HEAD", GND, s, Note="Head bulk, ceramic (was 22 uF tantalum)")
add("U7", "INA293B", "INA293B2IDBVR", s, {"4": "SW1_OUT", "5": "5V_CM5", "3": "3V7_A", "2": GND, "1": "I_CM5_AMP"},
    MPN="INA293B2IDBVR", MPN_ALT="INA951-SEP (space grade; not buyable)",
    Note="B pinout. 50 V/V x 20 mOhm = 1.0 V/A; output swings to VS - 0.15 V = 3.56 V (3.56 A)")
add("U8", "INA293B", "INA293B2IDBVR", s, {"4": "SW2_OUT", "5": "5V_HEAD", "3": "3V7_A", "2": GND, "1": "I_HEAD_AMP"},
    MPN="INA293B2IDBVR", MPN_ALT="INA951-SEP (space grade; not buyable)")
C("C28", "100n 100V", "3V7_A", GND, s, Note="U7 VS")
C("C29", "100n 100V", "3V7_A", GND, s, Note="U8 VS")
R("R19", "10k", GND, "SW2_EN", s, Note="Head off until the CM5 drives SW2_EN high (GPIO16). Against an RP1 boot pull-up of about 50k, EN sits at 0.55 V, under the 1.08 V falling threshold minimum.")
add("U10", "TPS73801", "TPS73801DCQR", s, {"1": "5V_BUS", "5": "5V_BUS", "3": GND, "6": GND,
                                           "2": "3V7_A", "4": "U10_FB"},
    MPN="TPS73801DCQR", MPN_ALT="TPS73801MDCQTPSEP",
    Note="Always-on 3.71 V: shunt amplifiers, watchdog, SW1_EN pull-up and watchdog straps (the 3.3 V module TPSM82823 has no stock until 4/2027 and is removed). Above CM5_3V3 max (3.465 V).")
R("R23", "2.49k", "3V7_A", "U10_FB", s, Note="R2 (top): VOUT = 1.21 V x (1 + 2.49k/1.21k) + 3 uA x 2.49k = 3.71 V (derived)")
R("R24", "1.21k", "U10_FB", GND, s, Note="R1 (bottom) < 4.17k")
C("C34", "10u 25V X7R 1206", "5V_BUS", GND, s)
C("C35", "10u 25V X7R 1206", "3V7_A", GND, s, Note=">= 10 uF, ESR <= 3 Ohm")
add("U11", "TL7700", "TL7700CPWR", s, {"5": "5V_BUS", "2": "U11_SENSE", "1": "U11_CT", "4": GND, "8": "SW1_EN",
                                       "3": None, "6": None, "7": None},
    MPN="TL7700CPWR", MPN_ALT="TL7700CMPWTPSEP",
    Note="Holds SW1 off until 5V_BUS is above ~4.67 V, then 10 ms more")
R("R25", "20.0k", "5V_BUS", "U11_SENSE", s, Note="R1: hysteresis = Is x 20.0k = 0.03-0.07 V (Is 1.5-3.5 uA, -40 to 85 C)")
R("R26", "2.40k", "U11_SENSE", GND, s, Note="R2: falling trip = Vs x 22.4/2.40: 4.67 V typ, 4.57-4.76 V (Vs 490-510 mV, -40 to 85 C); release at most 4.83 V, below the trimmed 5V_BUS minimum of 5.02 V. The trim gives the CM5 its margin; the supervisor catches brown-outs.")
C("C36", "100n 100V", "U11_CT", GND, s, Note="tpo = CT x 1e5 s = 10 ms")
C("C37", "100n 100V", "5V_BUS", GND, s)
add("U12", "TPS3435C", "TPS3435CAIEGDDFR", s, {"8": "3V7_A", "3": "WDI", "2": "3V7_A", "4": GND, "7": "SW1_EN",
                                               "1": "U12_SET0", "5": "U12_SET1", "6": "U12_WDEN"},
    MPN="TPS3435CAIEGDDFR", Note="Open-drain, no startup delay, 1 s base x 64 (SET1:SET0 = 11) = 64 s, min 57.6 s. WDO pulse 200 ms. VDD 3.71 V (1.04-6 V): WDI VIH = 0.7 x VDD = 2.60 V, met by a 3.3 V CM5 GPIO. Only WDI connects to the CM5.")
R("R27", "10k", "3V7_A", "U12_SET0", s, Note="SET0 high")
R("R28", "0R DNP", "U12_SET0", GND, s, DNP=True, Note="Fit and remove R27 for 32 s")
R("R29", "10k", "3V7_A", "U12_SET1", s, Note="SET1 high")
R("R30", "10k", "3V7_A", "U12_WDEN", s, Note="Watchdog always enabled")
C("C38", "100n 100V", "3V7_A", GND, s)
R("R31", "33k", "3V7_A", "SW1_EN", s, Note="EN pull-up for the wired TL7700 RESET and TPS3435 WDO (both open drain). 0.11 mA sink; EN/UVLO falling threshold 1.08 V minimum, abs max 6.5 V.")
add("TP6", "TestPoint", "SW1_EN", s, {"1": "SW1_EN"})
add("TP7", "TestPoint", "5V_BUS", s, {"1": "5V_BUS"})
add("TP9", "TestPoint", "3V7_A", s, {"1": "3V7_A"})
add("TP10", "TestPoint", "GND", s, {"1": GND})

# ---------------- CM5
s = "cm5"
USE = {  # pin -> net; everything else on the connector is GND, 5V, 3.3V or no-connect
    20: "EEPROM_NWP", 24: "HEAD_TRIG", 28: "HOST_BULK_RXD", 29: "SW2_EN", 30: "WDI", 31: "HOST_BULK_TXD",
    34: "HOST_CMD_RXD", 37: "ADC_NCS", 38: "SPI0_SCLK", 39: "CAN_NCS", 40: "SPI0_MISO", 41: "CAN_NINT",
    44: "SPI0_MOSI", 48: "HOST_BULK_DE", 49: "PPS_IN", 50: "HOST_TLM_DE",
    51: "MAINT_UART_RX", 54: "HOST_TLM_TXD", 55: "MAINT_UART_TX", 78: "CM5_3V3",
    92: "PWR_BUT", 93: "NRPIBOOT", 99: "PMIC_EN", 103: "MAINT_USB_N", 105: "MAINT_USB_P",
    128: "HEAD_SSRX_N", 130: "HEAD_SSRX_P", 134: "HEAD_USB2_P", 136: "HEAD_USB2_N", 140: "HEAD_SSTX_N",
    142: "HEAD_SSTX_P"}


def cm5net(k):
    nm = CM5_PINS[k]
    if k in USE:
        return USE[k]
    if nm == "GND":
        return GND
    if nm == "5V":
        return "5V_CM5"
    if nm == "CM5_3.3V":
        return "CM5_3V3"
    return None


add("M1", "CM5", "Raspberry Pi CM5", s, {str(k): cm5net(k) for k in range(1, 101)}, unit=1,
    MPN="Raspberry Pi CM5004016 (4 GB RAM, 16 GB eMMC, no wireless)", Mate="2 x Amphenol 10164227-1004A1RLF, 4.0 mm stack",
    Note="GPIO_VREF tied to CM5_3.3V: 3.3 V GPIO. WL_nDisable, BT_nDisable left open (no wireless). CC1/CC2 open: set PSU_MAX_CURRENT in the boot EEPROM config. GPIO22/23 (pins 46, 47) free since the limiter-flag isolator was removed.")
add("M1", "CM5", "Raspberry Pi CM5", s, {str(k): cm5net(k) for k in range(101, 201)}, unit=2)
C("C39", "10u 25V X7R 1206", "CM5_3V3", GND, s, Note="Local bulk on CM5_3V3 (600 mA total available)")
add("TP11", "TestPoint", "CM5_3V3", s, {"1": "CM5_3V3"})
add("TP12", "TestPoint", "5V_CM5", s, {"1": "5V_CM5"})

# ---------------- interfaces
s = "interfaces"
add("U13", "MCP2518FD", "MCP2518FDT-E/SL", s, {"14": "CM5_3V3", "13": "CAN_NCS", "10": "SPI0_SCLK", "11": "SPI0_MOSI",
                                               "12": "SPI0_MISO", "4": "CAN_NINT", "7": GND, "1": "CAN_TXD",
                                               "2": "CAN_RXD", "6": "CAN_OSC1", "5": "CAN_OSC2", "3": None, "8": "CAN_INT1",
                                               "9": "CAN_INT0"},
    MPN="MCP2518FDT-E/SL", Note="Pinout from Microchip DS20006027B, read from a SparkFun-hosted copy because Microchip's site refuses automated access")
C("C40", "100n 100V", "CM5_3V3", GND, s)
R("R32", "10k", "CM5_3V3", "CAN_NINT", s, Note="INT configured open drain (IOCON.INTOD)")
R("R33", "10k", "CM5_3V3", "CAN_NCS", s, Note="Deselected while the CM5 boots")
R("R70", "10k", "CM5_3V3", "CAN_INT1", s, Note="INT1/GPIO1 reset as a GPIO input: pulled up rather than left floating")
R("R71", "10k", "CM5_3V3", "CAN_INT0", s, Note="INT0/GPIO0/XSTBY reset as a GPIO input: pulled up")
add("Y1", "Crystal_4pad", "40MHz", s, {"1": "CAN_OSC1", "2": GND, "3": "CAN_OSC2", "4": GND},
    MPN="Abracon ABM8AIG-40.000MHZ-12-2Z-T3", Note="40 MHz, CL 12 pF, +-20 ppm, +-50 ppm over -40 to 125 C, ESR 35 Ohm (Abracon page). Pad assignment (2 and 4 ground) to confirm on the ABM8AIG drawing.")
C("C41", "15p 100V C0G", "CAN_OSC1", GND, s, Note="C = 2 x (CL - Cstray) = 2 x (12 - 4.5) = 15 pF; trim on the bench for frequency")
C("C42", "15p 100V C0G", "CAN_OSC2", GND, s)
add("U14", "SN65HVD233", "SN65HVD233DR", s, {"3": "CM5_3V3", "1": "CAN_TXD", "4": "CAN_RXD", "5": GND,
                                             "2": GND, "7": "CANH", "6": "CANL", "8": "U14_RS"},
    MPN="SN65HVD233DR", MPN_ALT="SN55HVD233MDTPSEP")
C("C43", "100n 100V", "CM5_3V3", GND, s)
C("C44", "4.7u 25V X7R 0805", "CM5_3V3", GND, s, Note="Per SEP EVM decoupling")
R("R34", "10k", "U14_RS", GND, s, Note="Slope control, about 15 V/us (10k-100k range)")
add("D1", "ESD2CAN24", "ESD2CAN24-Q1", s, {"1": "CANH", "2": "CANL", "3": GND}, MPN="ESD2CAN24DBZRQ1",
    Note="Place at the harness header")
R("R35", "60.4 DNP", "CANH", "CAN_MID", s, DNP=True, Note="Split termination, fit only if the payload ends the bus")
R("R36", "60.4 DNP", "CAN_MID", "CANL", s, DNP=True)
C("C45", "4.7n 100V DNP", "CAN_MID", GND, s, DNP=True)

add("U15", "SN65C1168E", "SN65C1168EPWR", s, {"16": "5V_RS422", "15": "HOST_TLM_TXD", "4": "HOST_TLM_DE",
                                              "9": "HOST_BULK_TXD", "12": "HOST_BULK_DE", "3": "CMD_R",
                                              "5": "BULK_R", "8": GND, "14": "TLM_P", "13": "TLM_N",
                                              "10": "BULKOUT_P", "11": "BULKOUT_N", "2": "CMD_IN_P",
                                              "1": "CMD_IN_N", "6": "BULKIN_P", "7": "BULKIN_N"},
    MPN="SN65C1168EPWR", MPN_ALT="SN65C1168EMPWTSEP", Note="Host link: driver 1 telemetry out, driver 2 bulk out; receiver 1 command in, receiver 2 bulk in. Thin distributor stock: buy early.")
C("C46", "100n 100V", "5V_RS422", GND, s)
add("U18", "TPS22919", "TPS22919DCKR", s, {"1": "5V_CM5", "3": "CM5_3V3", "2": GND, "4": None, "6": "5V_RS422", "5": "5V_RS422"},
    MPN="TPS22919DCKR", MPN_ALT="TPS7H2221-SEP (space grade; not buyable)",
    Note="Gates the RS-422 5 V with the CM5's own 3.3 V: the receivers cannot drive CM5 GPIOs before CM5_3V3 is up. QOD tied to VOUT: internal 24 Ohm discharge when CM5_3V3 falls. ON VIH 1 V; smart pull-down. Pin 4 NC, left floating (datasheet).")
C("C58", "1u 25V X7R", "5V_CM5", GND, s, Note="U18 CIN 1 uF")
C("C59", "10u 25V X7R 1206", "5V_RS422", GND, s, Note="U18 COUT: rise about 1.3 ms at 5 V, inrush 10 uF x 5 V / 1.3 ms = 39 mA")
R("R37", "10k", GND, "HOST_TLM_DE", s, Note="Driver off until the CM5 enables it")
R("R38", "10k", GND, "HOST_BULK_DE", s)
R("R39", "10k", "CM5_3V3", "HOST_TLM_TXD", s, Note="Idle mark")
R("R40", "10k", "CM5_3V3", "HOST_BULK_TXD", s)
add("D4", "BAS70W", "BAS70W-Q", s, {"1": "5V_RS422", "2": None, "3": "5V_BIAS"}, MPN="Nexperia BAS70W-QX",
    Note="Feeds the fail-safe bias from 5V_RS422 and blocks reverse current: a host driving the lines while the CM5 is off cannot back-feed 5V_RS422 and the CM5's 5 V pins. 6.1 mA load against 70 mA IF (50 % derating allows 35 mA); 5 V against 70 V VR.")
for (ra, rb, rt, p, n, rout, dout, kk, rtop, rbot) in (
        ("R41", "R42", "R43", "CMD_IN_P", "CMD_IN_N", "CMD_R", "HOST_CMD_RXD", "R44", "10k", "15k"),
        ("R46", "R47", "R48", "BULKIN_P", "BULKIN_N", "BULK_R", "HOST_BULK_RXD", "R49", "2.2k", "3.3k"),
        ("R51", "R52", "R53", "PPS_IN_P", "PPS_IN_N", "PPS_R", "PPS_IN", "R54", "10k", "15k")):
    R(rt, "120 1206", p, n, s, Note="Receiver termination (cable impedance TBC). 1206 (0.25 W): 3.5 V differential gives 0.10 W, 41 %.")
    R(ra, "1k", "5V_BIAS", p, s, Note="Fail-safe bias: (5 V - 0.7 V diode) x 120/2120 = 0.24 V across the termination (> 0.2 V)")
    R(rb, "1k", n, GND, s)
    R(kk, rtop, rout, dout, s, Note="5 V receiver output to 3.3 V GPIO, ratio 0.6: 5.5 V gives 3.3 V; 3.8 V VOH min gives 2.28 V > 2.0 V VIH. "
      + ("Bulk link 2.2k/3.3k for edge rate." if rtop == "2.2k" else "Command and PPS links 10k/15k (low rates)."))
    R(f"R{int(kk[1:]) + 1}", rbot, dout, GND, s)
add("U16", "SN65C1168E", "SN65C1168EPWR", s, {"16": "5V_RS422", "15": GND, "4": GND, "9": GND, "12": GND,
                                              "3": "PPS_R", "5": None, "8": GND, "14": None, "13": None,
                                              "10": None, "11": None, "2": "PPS_IN_P", "1": "PPS_IN_N",
                                              "6": "U16_2A", "7": GND},
    MPN="SN65C1168EPWR", MPN_ALT="SN65C1168EMPWTSEP", Note="PPS receiver; drivers disabled, receiver 2 biased high")
C("C47", "100n 100V", "5V_RS422", GND, s)
R("R56", "10k", "5V_RS422", "U16_2A", s)

# ---------------- housekeeping
s = "housekeeping"
add("U19", "REF50", "REF5040IDR", s, {"2": "5V_BUS", "4": GND, "5": "REF_NR", "1": None, "6": "VREF",
                                      "3": None, "7": None, "8": None},
    MPN="REF5040IDR", MPN_ALT="REF5040MDREP (enhanced product)",
    Note="4.096 V, 0.05 %, 3 ppm/C, +-10 mA. VIN >= VOUT + 0.2 V = 4.30 V from 5V_BUS (always on). Load: ADC VA plus three thermistor dividers, under 4 mA. TEMP (60k source) and NC left open; DNC pins not connected.")
C("C70", "1u 25V X7R", "5V_BUS", GND, s, Note="VIN bypass, 1-10 uF")
C("C71", "1u 25V X7R", "REF_NR", GND, s, Note="Noise reduction, 1 uF (datasheet layout guideline)")
C("C48", "10u 25V X7R 1206", "VREF", GND, s, Note="CL: 10 uF + C72 + C49 = 11.1 uF, inside 1-50 uF; ceramic ESR is under the 1.5 Ohm maximum (series resistor optional)")
add("U17", "ADC128S102", "ADC128S102CIMTX/NOPB", s, {"2": "VREF", "13": "CM5_3V3", "1": "ADC_NCS", "16": "SPI0_SCLK",
                                                     "14": "SPI0_MOSI", "15": "SPI0_MISO", "3": GND, "12": GND,
                                                     "4": "ADC_IN0", "5": "ADC_IN1", "6": "ADC_IN2", "7": "ADC_IN3",
                                                     "8": "ADC_IN4", "9": "ADC_IN5", "10": "ADC_IN6", "11": "ADC_IN7"},
    MPN="ADC128S102CIMTX/NOPB", MPN_ALT="ADC128S102PWTSEP",
    Note="VA = VREF = 4.096 V is the reference: 1.00 mV per code. VD = CM5_3V3 (2.7 V to VA). SCLK 8-16 MHz.")
C("C72", "1u 25V X7R", "VREF", GND, s, Note="VA: 1 uF + 0.1 uF within 1 cm (ADC datasheet)")
C("C49", "100n 100V", "VREF", GND, s)
C("C50", "100n 100V", "CM5_3V3", GND, s, Note="VD")
R("R57", "10k", "CM5_3V3", "ADC_NCS", s)
R("R58", "10k", "5V_BUS", "ADC_IN0", s, Note="ch 0: 5V_BUS / 2")
R("R59", "10k", "ADC_IN0", GND, s)
C("C51", "100n 100V", "ADC_IN0", GND, s)
R("R60", "100", "I_CM5_AMP", "ADC_IN1", s, Note="ch 1: CM5 rail current, 1.0 V/A; RC 100 Ohm / 33 nF")
C("C52", "33n 100V", "ADC_IN1", GND, s)
R("R61", "100", "I_HEAD_AMP", "ADC_IN2", s, Note="ch 2: head rail current")
C("C53", "33n 100V", "ADC_IN2", GND, s)
TURRET = "Leads to 2 x Keystone 1593-2 turrets (SnPb hot dip) or Mill-Max SnPb equivalent"
for ch, rt, rb, cc, where in ((3, "RT2", "R62", "C54", "under the heat block plate (remote, leads to turrets)"),
                              (4, "RT3", "R63", "C55", "on the DC-DC converter +x face (remote, leads to turrets)"),
                              (5, "RT1", "R64", "C56", "on the board")):
    R(rb, "10k 0.1%", "VREF", f"ADC_IN{ch}", s, Note=f"ch {ch}: thermistor bias, ratiometric to VA")
    add(rt, "Thermistor", "10k NTC", s, {"1": f"ADC_IN{ch}", "2": GND}, MPN="TE 44907 (GSFC 311P18-07)",
        MPN_ALT="TE 44006RC (commercial)", Mate=TURRET, Note=where)
    C(cc, "100n 100V", f"ADC_IN{ch}", GND, s)
R("R65", "10k", "5V_HEAD", "ADC_IN6", s, Note="ch 6: 5V_HEAD / 2, direct SW2 state")
R("R66", "10k", "ADC_IN6", GND, s)
C("C57", "100n 100V", "ADC_IN6", GND, s)
R("R67", "10k", "ADC_IN7", GND, s, Note="ch 7: spare")
add("TP13", "TestPoint", "ADC_IN7", s, {"1": "ADC_IN7"})
add("RT4", "Thermistor", "10k NTC", s, {"1": "HOST_THERM_A", "2": "HOST_THERM_B"}, MPN="TE 44907 (GSFC 311P18-07)",
    MPN_ALT="TE 44006RC (commercial)", Mate=TURRET,
    Note="Host thermistor (J1 23, 24): read by the host while the payload is off. Not tied to payload circuits. Not yet in the CAD.")

# ---------------- maintenance and head link
s = "maint_head"
J2 = {"1": GND, "2": GND, "3": "MAINT_USB_P", "4": "MAINT_USB_N", "5": GND, "6": "MAINT_UART_TX",
      "7": "MAINT_UART_RX", "8": GND, "9": "NRPIBOOT", "10": "PMIC_EN", "11": "PWR_BUT", "12": "EEPROM_NWP",
      "13": "MAINT_3V3_REF", "14": GND}
add("J2", "Conn_2x07_Molex87831", "Maintenance header", s, J2, MPN="Molex 87831-1420",
    Note="Row assignment (odd/even) to confirm on drawing SD-87831-0001 sheet 8 before the footprint")
add("D2", "TPD4E05U06", "TPD4E05U06", s, {"1": "MAINT_USB_P", "2": "MAINT_USB_N", "4": "MAINT_UART_TX",
                                          "5": "MAINT_UART_RX", "3": GND, "8": GND, "6": None, "7": None,
                                          "9": None, "10": None}, MPN="TPD4E05U06DQAR")
add("D3", "TPD4E05U06", "TPD4E05U06", s, {"1": "NRPIBOOT", "2": "PMIC_EN", "4": "PWR_BUT", "5": "EEPROM_NWP",
                                          "3": GND, "8": GND, "6": None, "7": None, "9": None, "10": None},
    MPN="TPD4E05U06DQAR", Note="PMIC_EN and PWR_BUT are pulled to 5 V inside the CM5: within the 5.5 V working voltage")
R("R68", "10k", "EEPROM_NWP", GND, s, Note="Boot EEPROM write-protected in flight; ground equipment pulls the pin high to program")
R("R69", "100", "CM5_3V3", "MAINT_3V3_REF", s, Note="Logic-level reference for the ground adapter")
J3 = {"1": "5V_HEAD", "2": "5V_HEAD", "3": "5V_HEAD", "4": GND, "5": "HEAD_SSTX_P", "6": "HEAD_SSTX_N", "7": GND,
      "8": "HEAD_SSRX_P", "9": "HEAD_SSRX_N", "10": GND, "11": "HEAD_USB2_P", "12": "HEAD_USB2_N", "13": GND,
      "14": "HEAD_TRIG", "15": GND, "16": GND}
add("J3", "Conn_16_Flex", "Head link", s, J3, MPN="TBC with XIMEA",
    Note="USB 3.0 port 0 of the CM5 (TX AC-coupled on the CM5). 90 Ohm differential pairs. HEAD_TRIG (GPIO26) use TBC with XIMEA.")


# ----------------------------------------------------------------------------------------------- footprints (A4-4)
# Standard KiCad library footprints where the vendor's land pattern matches; SLANT:* are drawn for this board from the
# vendor's own drawing (README, "Footprints"). 'TBC' in a SLANT footprint's description names what is still unconfirmed.
FP_REF = {
    "U1": "SLANT:TI_PWP0020T_HTSSOP-20_P0.65mm_EP3.4x6.5mm", "U3": "SLANT:TDK_CCG10_DIP-6_THT",
    "U5": "SLANT:TI_RPW0010A_VQFN-HR-10_2x2mm", "U6": "SLANT:TI_RPW0010A_VQFN-HR-10_2x2mm",
    "U7": "Package_TO_SOT_SMD:SOT-23-5", "U8": "Package_TO_SOT_SMD:SOT-23-5",
    "U10": "SLANT:TI_DCQ0006A_SOT-223_5Lead_Tab6", "U11": "Package_SO:TSSOP-8_4.4x3mm_P0.65mm",
    "U12": "SLANT:TI_DDF0008A_SOT-23-THIN-8", "U13": "Package_SO:SOIC-14_3.9x8.7mm_P1.27mm",
    "U14": "Package_SO:SOIC-8_3.9x4.9mm_P1.27mm", "U19": "Package_SO:SOIC-8_3.9x4.9mm_P1.27mm",
    "U15": "Package_SO:TSSOP-16_4.4x5mm_P0.65mm", "U16": "Package_SO:TSSOP-16_4.4x5mm_P0.65mm",
    "U17": "Package_SO:TSSOP-16_4.4x5mm_P0.65mm", "U18": "Package_TO_SOT_SMD:SOT-363_SC-70-6",
    "D1": "Package_TO_SOT_SMD:SOT-23", "D2": "Package_SON:USON-10_2.5x1.0mm_P0.5mm",
    "D3": "Package_SON:USON-10_2.5x1.0mm_P0.5mm", "D4": "Package_TO_SOT_SMD:SOT-323_SC-70",
    "D5": "Diode_SMD:D_SMB", "F1": "SLANT:AEM_P700L_Figure1", "L1": "Inductor_SMD:L_Coilcraft_XAL5050-XXX",
    "Y1": "Crystal:Crystal_SMD_3225-4Pin_3.2x2.5mm", "J1": "SLANT:Harwin_G125-MV12605L1P_2x13_P1.25mm_Latch",
    "J2": "SLANT:Molex_87831-1420_2x07_P2.00mm_Vertical",
    "J3": "Connector_FFC-FPC:Hirose_FH12-16S-0.5SH_1x16-1MP_P0.50mm_Horizontal",
    "M1": "SLANT:RaspberryPi_CM5_Carrier_2x_Amphenol_10164227-1004A1RLF",
}


def footprint_for(c):
    r, v = c["ref"], c["value"]
    if r in FP_REF:
        return FP_REF[r]
    if c["sym"] == "R":
        return "Resistor_SMD:R_1206_3216Metric" if "1206" in v else "Resistor_SMD:R_0805_2012Metric"
    if c["sym"] == "C":
        for sz, fp in (("1812", "C_1812_4532Metric"), ("1210", "C_1210_3225Metric"), ("1206", "C_1206_3216Metric")):
            if sz in v:
                return "Capacitor_SMD:" + fp
        return "Capacitor_SMD:C_0805_2012Metric"
    if c["sym"] == "TestPoint":
        return "TestPoint:TestPoint_Pad_D1.5mm"
    if c["sym"] == "MountingHole":
        return "MountingHole:MountingHole_3.2mm_M3_Pad"
    if c["sym"] == "Thermistor":
        return "SLANT:Turret_Pair_Keystone_1593-2_P5.08mm_TBC"
    raise KeyError(r)


for _c in COMP:
    _c["f"]["Footprint"] = footprint_for(_c)
