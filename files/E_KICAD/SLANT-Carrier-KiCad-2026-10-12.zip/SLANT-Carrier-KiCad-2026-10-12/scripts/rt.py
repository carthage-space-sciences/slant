"""Grid router for the SLANT carrier board's critical nets (KC, 10 Oct 2026, 21:53: script the critical nets, autoroute
the rest). Two signal layers (F.Cu, B.Cu) and vias; In1 and In2 are planes.

Method. The board is a 0.05 mm raster. For the net being routed, a cell is open on a layer when its distance to every
piece of copper of another net is at least the required clearance plus half the track width; distances come from
Euclidean distance transforms of the copper rasters, one per clearance value. The required clearance follows the
project's rules:
  - net-class clearance, the larger of the two classes (0.15 mm Default, 0.2 mm otherwise);
  - 2.5 mm between host-side and payload copper (custom rule), applied as a region: host-side copper stays inside the
    host-side zone and payload copper outside the zone grown by 2.5 mm, except inside J1's courtyard where both sides
    keep 1.5 mm (J1 rules, KC 21:53);
  - 0.8 mm to chassis copper;
  - 0.5 mm to the board edge.
A path is the minimum-cost path through a three-plane stack (F.Cu, via plane, B.Cu) with eight moves in each plane and
one move between planes; a via plane cell is open where a via of the net's class fits on both outer layers. Cost is
path length plus 1.5 mm per via. Paths are reduced to straight segments at 0, 45 and 90 degrees.

Units mm, assembly frame (x right, y up); KiCad X = 100 + x, Y = 100 - y.
"""
import math
import numpy as np
import pcbnew
from scipy import ndimage as ndi
from skimage.graph import MCP_Geometric
from PIL import Image, ImageDraw
from shapely.geometry import Polygon, Point, LineString, box as sbox
from shapely.ops import unary_union
import shapely
from shapely import STRtree

MM = pcbnew.FromMM
RES = 0.05
X0, Y0 = -44.5, -48.5
NX, NY = int(round((46.75 - X0) / RES)), int(round((48.5 - Y0) / RES))
MARGIN = 0.07          # raster error allowance added to every clearance (copper may extend up to ~1 cell past its raster)
VIA_COST = 50.0        # cells (2.5 mm) per via
OUTER = [(46.22, -47.96), (46.22, 47.94), (-43.95, 47.94), (-43.95, 25.0), (-44.0, 25.0), (-44.0, 24.5), (-34.5, 24.5),
         (-34.5, 18.5), (-43.95, 18.5), (-43.95, -47.96)]
BOARD = Polygon(OUTER)
HOSTZ = Polygon([(-43.95, -47.96), (-11.0, -47.96), (-11.0, -5.0), (-26.0, -5.0), (-26.0, 8.9), (-43.95, 8.9)])
J1BOX = sbox(-32.78, 1.62, -27.32, 22.38)
BARRIER, J1GAP, CHASSIS_CLR, EDGE = 2.5, 1.5, 0.8, 0.5
HOSTCLS = ("BusSide", "BusSideSignal", "Host")
LAY = {"F": pcbnew.F_Cu, "B": pcbnew.B_Cu}


def K(x, y):
    return pcbnew.VECTOR2I(MM(100 + float(x)), MM(100 - float(y)))


def W(v):
    return (pcbnew.ToMM(v.x) - 100, 100 - pcbnew.ToMM(v.y))


def cell(x, y):
    return int(round((y - Y0) / RES)), int(round((x - X0) / RES))


def xy(i, j):
    return float(X0 + j * RES), float(Y0 + i * RES)


def raster(geoms, value=1, out=None, dtype=np.uint8):
    """Fill shapely polygons into an NY x NX array (row = y)."""
    arr = np.zeros((NY, NX), dtype) if out is None else out
    im = Image.new("1", (NX, NY), 0)
    d = ImageDraw.Draw(im)
    for g in geoms:
        for p in (g.geoms if hasattr(g, "geoms") else [g]):
            if p.is_empty:
                continue
            ext = [((x - X0) / RES, (y - Y0) / RES) for x, y in p.exterior.coords]
            d.polygon(ext, fill=1)
            for r in p.interiors:
                d.polygon([((x - X0) / RES, (y - Y0) / RES) for x, y in r.coords], fill=0)
    m = np.array(im, dtype=bool)
    arr[m] = value
    return arr


class Board:
    def __init__(self, path):
        self.b = pcbnew.LoadBoard(path)
        ns = self.b.GetDesignSettings().m_NetSettings
        self.cls = {str(k): v for k, v in ns.m_NetClasses.items()}
        self.cls["Default"] = ns.m_DefaultNetClass
        self.netid = {"": 0}
        self.netname = [""]
        self.netcls = [""]
        for n, ni in self.b.GetNetsByName().items():
            n = str(n)
            if n and n not in self.netid:
                self.netid[n] = len(self.netname); self.netname.append(n); self.netcls.append(ni.GetNetClassName())
        self.N = len(self.netname)
        # per-net properties
        self.is_host = np.array([c in HOSTCLS for c in self.netcls])
        self.is_chassis = np.array([n == "CHASSIS" for n in self.netname])
        self.clr = np.array([pcbnew.ToMM(self.cls[c].GetClearance()) if c in self.cls else 0.15 for c in self.netcls])
        self.clr[0] = 0.15
        # copper rasters: net id per cell, per outer layer; -1 = copper with no net (and holes)
        self.own = {L: np.zeros((NY, NX), np.int32) for L in LAY}
        self.trk = {L: np.zeros((NY, NX), np.int32) for L in LAY}     # tracks and vias only
        self.cl = {L: np.zeros((NY, NX), np.int32) for L in LAY}      # track centrelines and via discs: where a new
                                                                       # track may end and be joined in KiCad's sense
        self.items = {L: [] for L in LAY}      # (net id, shapely geometry) per layer, for exact checks near pads
        self.drill = np.zeros((NY, NX), np.int32)   # vias and plated holes: where copper joins F.Cu to B.Cu
        self.conn = {L: np.zeros((NY, NX), np.int32) for L in LAY}   # copper shrunk by 0.04 mm: pieces that touch here
                                                                      # overlap for certain (connectivity)
        self._tree = {}
        self.pads = []      # dicts: ref, num, net, layers, poly
        for fp in self.b.GetFootprints():
            for pd in fp.Pads():
                n = pd.GetNetname()
                layers = [L for L, lid in LAY.items() if pd.IsOnLayer(lid)]
                tht = pd.GetAttribute() in (pcbnew.PAD_ATTRIB_PTH, pcbnew.PAD_ATTRIB_NPTH)
                lid = LAY[layers[0]] if layers else pcbnew.F_Cu
                ps = pcbnew.SHAPE_POLY_SET()
                pd.TransformShapeToPolygon(ps, lid, 0, MM(0.005))
                polys = []
                for k in range(ps.OutlineCount()):
                    o = ps.Outline(k)
                    polys.append(Polygon([W(o.CPoint(i)) for i in range(o.PointCount())]))
                poly = unary_union(polys)
                if pd.GetAttribute() == pcbnew.PAD_ATTRIB_NPTH:
                    # unplated hole: the hole itself, held 0.25 mm (hole clearance) as no-net copper
                    c = W(pd.GetPosition()); ds = pd.GetDrillSize()
                    poly = poly.union(Point(c).buffer(pcbnew.ToMM(max(ds.x, ds.y)) / 2))
                    layers = ["F", "B"]
                rec = dict(ref=fp.GetReference(), num=pd.GetNumber(), net=n, layers=layers, poly=poly, tht=tht,
                           pos=W(pd.GetPosition()))
                self.pads.append(rec)
                v = self.netid.get(n, 0) if n else (-2 if pd.GetAttribute() == pcbnew.PAD_ATTRIB_NPTH else -1)
                shr = poly.buffer(-0.04)
                for L in layers:
                    raster([poly], v, self.own[L], np.int32)
                    if v > 0 and not shr.is_empty:
                        raster([shr], v, self.conn[L], np.int32)
                    self.items[L].append((v, poly))
                if pd.GetAttribute() == pcbnew.PAD_ATTRIB_PTH and v > 0:
                    raster([poly], v, self.drill, np.int32)
        for t in self.b.GetTracks():
            self._draw_item(t)
        self.allowed_cache = {}

    # ---------------------------------------------------------------- items
    def _draw_item(self, t):
        n = self.netid.get(t.GetNetname(), -1) or -1
        if t.GetClass() == "PCB_VIA":
            c = W(t.GetPosition()); g = Point(c).buffer(pcbnew.ToMM(t.GetWidth()) / 2)
            raster([g], n, self.drill, np.int32)
            for L in LAY:
                raster([g.buffer(-0.04)], n, self.conn[L], np.int32)
                raster([g], n, self.own[L], np.int32); raster([g], n, self.trk[L], np.int32)
                raster([Point(c).buffer(max(pcbnew.ToMM(t.GetWidth()) / 2 - 0.03, 0.03))], n, self.cl[L], np.int32)
                self.items[L].append((n, g)); self._tree.pop(L, None)
        else:
            L = "F" if t.GetLayer() == pcbnew.F_Cu else ("B" if t.GetLayer() == pcbnew.B_Cu else None)
            if L:
                g = LineString([W(t.GetStart()), W(t.GetEnd())]).buffer(pcbnew.ToMM(t.GetWidth()) / 2)
                raster([g], n, self.own[L], np.int32); raster([g], n, self.trk[L], np.int32)
                raster([LineString([W(t.GetStart()), W(t.GetEnd())]).buffer(0.03)], n, self.cl[L], np.int32)
                raster([LineString([W(t.GetStart()), W(t.GetEnd())]).buffer(max(pcbnew.ToMM(t.GetWidth()) / 2 - 0.04,
                                                                                    0.02))], n, self.conn[L], np.int32)
                self.items[L].append((n, g)); self._tree.pop(L, None)

    def add_track(self, net, L, pts, width, lock=True):
        for a, c in zip(pts[:-1], pts[1:]):
            if math.dist(a, c) < 1e-6:
                continue
            t = pcbnew.PCB_TRACK(self.b)
            t.SetStart(K(*a)); t.SetEnd(K(*c)); t.SetWidth(MM(width)); t.SetLayer(LAY[L])
            t.SetNet(self.b.FindNet(net)); t.SetLocked(lock)
            self.b.Add(t); self._draw_item(t)

    def add_via(self, net, p, dia, drill, lock=True):
        v = pcbnew.PCB_VIA(self.b)
        v.SetPosition(K(*p)); v.SetWidth(MM(dia)); v.SetDrill(MM(drill)); v.SetViaType(pcbnew.VIATYPE_THROUGH)
        v.SetLayerPair(pcbnew.F_Cu, pcbnew.B_Cu); v.SetNet(self.b.FindNet(net)); v.SetLocked(lock)
        self.b.Add(v); self._draw_item(v)

    # ---------------------------------------------------------------- clearance model
    def domain(self, net):
        if self.netname[self.netid[net]] == "CHASSIS":
            return "chassis"
        return "host" if self.is_host[self.netid[net]] else "payload"

    def req(self, net):
        """Required clearance from this net's copper to each other net's copper (array over net ids)."""
        k = self.netid[net]
        r = np.maximum(self.clr, self.clr[k])
        if self.netname[k] == "CHASSIS":
            r = np.maximum(r, CHASSIS_CLR)
        r = np.where(self.is_chassis, np.maximum(r, CHASSIS_CLR), r)
        # the barrier is applied as a region (allowed()), so other-domain copper only needs the netclass value here,
        # except near J1 where both domains meet: 1.5 mm
        dom_host = self.is_host[k]
        other = (self.is_host != dom_host) & ~self.is_chassis
        other[0] = False
        if self.netname[k] != "CHASSIS":
            r = np.where(other, np.maximum(r, J1GAP), r)
        r[k] = 0.0
        return r

    def allowed(self, net, hw):
        key = (self.domain(net), round(hw, 3))
        if key in self.allowed_cache:
            return self.allowed_cache[key]
        d = key[0]
        area = BOARD.buffer(-(EDGE + hw + MARGIN))
        if d == "host":
            reg = HOSTZ.buffer(-(hw + MARGIN))
        elif d == "payload":
            win = J1BOX.intersection(sbox(-50, 8.9 + J1GAP + hw + MARGIN, 50, 50))
            reg = BOARD.difference(HOSTZ.buffer(BARRIER + hw + MARGIN, join_style=2)).union(win)
        else:
            reg = BOARD
        m = raster([area.intersection(reg)], 1).astype(bool)
        self.allowed_cache[key] = m
        return m

    def dist_maps(self, net, extra_own=()):
        """Distance (mm) from each cell to the nearest copper needing each distinct clearance value, per layer."""
        k = self.netid[net]
        r = self.req(net)
        out = {}
        for L in LAY:
            own = self.own[L]
            # copper with no net (unconnected pins): the net-class clearance; unplated holes count as board edge (0.5 mm)
            rr = np.where(own >= 0, r[np.clip(own, 0, None)], np.where(own == -2, EDGE, self.clr[k]))
            occupied = (own != 0) & (own != k)
            for e in extra_own:
                occupied &= own != self.netid[e]
            maps = []
            for val in np.unique(rr[occupied]):
                m = occupied & (rr == val)
                dist = ndi.distance_transform_edt(~m) * RES
                maps.append((float(val), dist))
            out[L] = maps
        return out

    def open_cells(self, dmaps, hw, allowed):
        res = {}
        for L, maps in dmaps.items():
            ok = allowed.copy()
            for val, dist in maps:
                ok &= dist >= val + hw + MARGIN
            res[L] = ok
        return res

    def refine(self, net, hw, openc, allowed, region, extra_own=()):
        """Exact check (vector geometry) for cells near this net's pads, where the raster's 0.05 mm error matters."""
        k = self.netid[net]
        r = self.req(net)
        skip = {k} | {self.netid[e] for e in extra_own}
        rm = raster([region], 1).astype(bool)
        for L in LAY:
            cand = rm & allowed & ~openc[L]
            ii, jj = np.nonzero(cand)
            if len(ii) == 0:
                continue
            if L not in self._tree:
                self._tree[L] = STRtree([g for _, g in self.items[L]])
            tree = self._tree[L]
            nets = np.array([n for n, _ in self.items[L]])
            geoms = np.array([g for _, g in self.items[L]], dtype=object)
            pts = shapely.points(X0 + jj * RES, Y0 + ii * RES)
            reach = 2.6 + hw
            pi, gi = tree.query(shapely.buffer(pts, reach), predicate="intersects")
            ok = np.ones(len(pts), bool)
            if len(pi):
                gn = nets[gi]
                keep = ~np.isin(gn, list(skip)) & (gn != 0)
                pi, gi, gn = pi[keep], gi[keep], gn[keep]
                need = np.where(gn >= 0, r[np.clip(gn, 0, None)], np.where(gn == -2, EDGE, self.clr[k])) + hw + 0.015
                d = shapely.distance(pts[pi], geoms[gi])
                bad = d < need
                ok[np.unique(pi[bad])] = False
            openc[L][ii[ok], jj[ok]] = True
        return openc

    def components(self, k):
        """Connected pieces of net k's copper, as KiCad joins them: overlapping copper on a layer, and F.Cu to B.Cu
        only through vias and plated holes. Returns per-layer arrays of piece ids (0 = no copper of net k)."""
        lab, n0 = {}, 0
        for L in LAY:
            l, n = ndi.label(self.conn[L] == k)
            l[l > 0] += n0
            lab[L] = l; n0 += n
        parent = np.arange(n0 + 1)

        def find(a):
            while parent[a] != a:
                parent[a] = parent[parent[a]]; a = parent[a]
            return a
        d = self.drill == k
        for a, b in set(zip(lab["F"][d].tolist(), lab["B"][d].tolist())):
            if a and b:
                ra, rb = find(a), find(b)
                if ra != rb:
                    parent[max(ra, rb)] = min(ra, rb)
        root = np.array([find(i) for i in range(n0 + 1)])
        return {L: root[lab[L]] for L in LAY}

    # ---------------------------------------------------------------- routing
    def route(self, net, width, via=(0.7, 0.35), pads=None, layers=("F", "B"), extra_own=(), attract=None,
              max_vias=True, label="", reserve=None, pad_ext=None):
        """Connect the pads of a net (or the listed (ref, num) pads) as a tree. Returns the list of pads it could not
        reach. attract: (other_net, pitch) adds a cost for straying from that net's copper (pair coupling)."""
        k = self.netid[net]
        hw = (reserve or width) / 2
        allowed = self.allowed(net, hw)
        dm = self.dist_maps(net, extra_own)
        openc = self.open_cells(dm, hw, allowed)
        mine = [p for p in self.pads if p["net"] == net and (pads is None or (p["ref"], p["num"]) in pads)]
        region = unary_union([p["poly"].buffer(0.6) for p in mine] +
                             ([g.buffer(0.3) for g in pad_ext.values()] if pad_ext else []))
        openc = self.refine(net, hw, openc, allowed, region, extra_own)
        vr = via[0] / 2
        vallowed = self.allowed(net, vr)
        vopen = self.open_cells(dm, vr, vallowed)
        via_ok = vopen["F"] & vopen["B"] & openc["F"] & openc["B"]
        # no vias inside J1's courtyard
        via_ok &= ~raster([J1BOX], 1).astype(bool)
        cost = np.full((3, NY, NX), np.inf)
        for zi, L in ((0, "F"), (2, "B")):
            if L in layers:
                cost[zi][openc[L]] = 1.0
        if "F" in layers and "B" in layers and max_vias:
            cost[1][via_ok] = VIA_COST
        if attract:
            other, pitch = attract
            ko = self.netid[other]
            for zi, L in ((0, "F"), (2, "B")):
                dist = ndi.distance_transform_edt(self.own[L] != ko) * RES
                pen = 1.0 + 1.5 * np.clip(np.abs(dist - pitch) / pitch, 0, 2)
                cost[zi] = np.where(np.isfinite(cost[zi]), pen, np.inf)
        mypads = [p for p in self.pads if p["net"] == net and (pads is None or (p["ref"], p["num"]) in pads)]
        # pad cells, per pad: open cells inside the pad on its layers
        def pad_cells(p):
            g = p["poly"]
            if pad_ext and (p["ref"], p["num"]) in pad_ext:
                g = g.union(pad_ext[(p["ref"], p["num"])])
            m = raster([g], 1).astype(bool)
            cells = []
            for zi, L in ((0, "F"), (2, "B")):
                if L in p["layers"] and L in layers:
                    ii, jj = np.nonzero(m & np.isfinite(cost[zi]))
                    cells += [(zi, i, j) for i, j in zip(ii, jj)]
            return cells
        cellsets = {id(p): pad_cells(p) for p in mypads}
        unreach = [p for p in mypads if not cellsets[id(p)]]
        todo = [p for p in mypads if cellsets[id(p)]]
        if not todo:
            return unreach
        # start from the pad nearest the centroid
        cx = np.mean([p["pos"][0] for p in todo]); cy = np.mean([p["pos"][1] for p in todo])
        todo.sort(key=lambda p: math.hypot(p["pos"][0] - cx, p["pos"][1] - cy))
        tree = [todo.pop(0)]
        groups = []
        offs = [(0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1), (0, 1, 1), (0, 1, -1), (0, -1, 1), (0, -1, -1),
                (1, 0, 0), (-1, 0, 0)]
        padmask = {id(p): raster([p["poly"].buffer(-0.04) if not p["poly"].buffer(-0.04).is_empty else p["poly"]], 1)
                   .astype(bool) for p in mypads}

        def ids_of(p, C):
            out = set()
            for L in p["layers"]:
                v = np.unique(C[L][padmask[id(p)]])
                out |= set(v[v > 0].tolist())
            return out
        while todo:
            C = self.components(k)
            treeids = set()
            for p in tree:
                treeids |= ids_of(p, C)
            # pads whose copper already meets the tree (a track crossing them) are joined
            for q in list(todo):
                if ids_of(q, C) & treeids:
                    todo.remove(q); tree.append(q)
            if not todo:
                break
            # sources: tree pads and the centrelines of this net's tracks that belong to the tree
            starts = []
            for p in tree:
                starts += cellsets[id(p)]
            tid = np.array(sorted(treeids))
            for zi, L in ((0, "F"), (2, "B")):
                ii, jj = np.nonzero((self.cl[L] == k) & np.isin(C[L], tid) & np.isfinite(cost[zi]))
                starts += [(zi, i, j) for i, j in zip(ii, jj)]
            ends = []
            owner = {}
            for p in todo:
                for c in cellsets[id(p)]:
                    ends.append(c); owner[c] = p
                # the centrelines of this net's copper already joined to the pad are targets too (a lane or escape
                # drawn from the pad before routing; A4-8)
                pid = np.array(sorted(ids_of(p, C) - treeids))
                if len(pid):
                    for zi, L in ((0, "F"), (2, "B")):
                        ii, jj = np.nonzero((self.cl[L] == k) & np.isin(C[L], pid) & np.isfinite(cost[zi]))
                        for i, j in zip(ii, jj):
                            if (zi, i, j) not in owner:
                                ends.append((zi, i, j)); owner[(zi, i, j)] = p
            mcp = MCP_Geometric(cost, offsets=offs)
            cum, _ = mcp.find_costs(starts, ends, find_all_ends=False)
            reached = [c for c in ends if np.isfinite(cum[c])]
            if not reached:
                # the tree is closed in: keep it as one group and grow a new tree from the next pad, so pads that
                # can reach each other still join (A4-8); the pads outside the largest group are reported
                groups.append(tree)
                tree = [todo.pop(0)]
                continue
            end = min(reached, key=lambda c: cum[c])
            path = mcp.traceback(end)
            p = owner[end]
            planar = [c for c in path if c[0] != 1]
            if len(planar) < 2 and end in cellsets[id(p)]:
                zi, i, j = end
                L = "F" if zi == 0 else "B"
                minx, miny, maxx, maxy = p["poly"].bounds
                self.add_track(net, L, [xy(i, j), p["pos"]], min(width, maxx - minx, maxy - miny))
            elif len(planar) >= 2:
                self._commit(net, path, width, via)
            todo.remove(p); tree.append(p)
        groups.append(tree)
        big = max(groups, key=len)
        return unreach + [p for g in groups if g is not big for p in g]

    def fanout(self, net, pad, width, via, max_len=3.0):
        """Short track from an SMD pad to a via (the via joins the inner-layer plane of the same net)."""
        k = self.netid[net]
        hw = width / 2
        L = pad["layers"][0]
        zi = 0 if L == "F" else 2
        dm = self.dist_maps(net)
        openc = self.open_cells(dm, hw, self.allowed(net, hw))
        openc = self.refine(net, hw, openc, self.allowed(net, hw), pad["poly"].buffer(0.6))
        vr = via[0] / 2
        vopen = self.open_cells(dm, vr, self.allowed(net, vr))
        via_ok = vopen["F"] & vopen["B"] & openc["F"] & openc["B"] & ~raster([J1BOX], 1).astype(bool)
        # vias stay out of this net's own SMD pads
        for p in self.pads:
            if p["net"] == net and not p["tht"]:
                via_ok &= ~raster([p["poly"].buffer(vr + 0.05)], 1).astype(bool)
        cost = np.full((3, NY, NX), np.inf)
        cost[zi][openc[L]] = 1.0
        cost[1][via_ok] = VIA_COST
        m = raster([pad["poly"]], 1).astype(bool)
        ii, jj = np.nonzero(m & openc[L])
        starts = [(zi, i, j) for i, j in zip(ii, jj)]
        if not starts:
            return False
        win = pad["poly"].buffer(max_len)
        vi, vj = np.nonzero(via_ok & raster([win], 1).astype(bool))
        ends = [(1, i, j) for i, j in zip(vi, vj)]
        if not ends:
            return False
        mcp = MCP_Geometric(cost, offsets=[(0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1), (0, 1, 1), (0, 1, -1),
                                           (0, -1, 1), (0, -1, -1), (1, 0, 0), (-1, 0, 0)])
        cum, _ = mcp.find_costs(starts, ends, find_all_ends=False)
        reached = [c for c in ends if np.isfinite(cum[c])]
        if not reached:
            return False
        end = min(reached, key=lambda c: cum[c])
        path = mcp.traceback(end)
        pts = [xy(i, j) for (z, i, j) in path if z == zi]
        if len(pts) >= 2:
            self.add_track(net, L, simplify(pts), width)
        self.add_via(net, xy(end[1], end[2]), *via)
        return True

    def fanout_many(self, net, pads, width, via, max_len=3.0, share=False):
        """fanout() for many pads of one net. The net's own copper is not an obstacle to itself, so the open cells are
        computed once. Returns the pads that found no via site."""
        k = self.netid[net]
        hw = width / 2
        dm = self.dist_maps(net)
        al = self.allowed(net, hw)
        openc = self.open_cells(dm, hw, al)
        region = unary_union([p["poly"].buffer(0.6) for p in pads])
        openc = self.refine(net, hw, openc, al, region)
        vr = via[0] / 2
        vopen = self.open_cells(dm, vr, self.allowed(net, vr))
        via_ok = vopen["F"] & vopen["B"] & openc["F"] & openc["B"] & ~raster([J1BOX], 1).astype(bool)
        via_ok &= ~raster([p["poly"].buffer(vr + 0.05) for p in self.pads if p["net"] == net and not p["tht"]], 1
                          ).astype(bool)
        offs = [(0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1), (0, 1, 1), (0, 1, -1), (0, -1, 1), (0, -1, -1),
                (1, 0, 0), (-1, 0, 0)]
        failed = []
        for pad in pads:
            L = pad["layers"][0]
            zi = 0 if L == "F" else 2
            # vias placed for earlier pads (and other nets' new copper) block later via sites
            cost = np.full((3, NY, NX), np.inf)
            cost[zi][openc[L]] = 1.0
            cost[1][via_ok] = VIA_COST
            m = raster([pad["poly"]], 1).astype(bool)
            ii, jj = np.nonzero(m & openc[L])
            starts = [(zi, i, j) for i, j in zip(ii, jj)]
            win = raster([pad["poly"].buffer(max_len)], 1).astype(bool)
            vi, vj = np.nonzero(via_ok & win)
            ends = [(1, i, j) for i, j in zip(vi, vj)]
            shared = set()
            if share:
                # or end on this net's copper that already reaches the plane (a track centreline or via of the net,
                # or a plated pad of the net), outside this pad
                pm = raster([pad["poly"].buffer(0.05)], 1).astype(bool)
                tht = raster([q["poly"] for q in self.pads if q["net"] == net and q["tht"]] or [Point(0, 0).buffer(0)],
                             1).astype(bool)
                own = ((self.cl[L] == k) | tht) & openc[L] & win & ~pm
                si, sj = np.nonzero(own)
                shared = {(zi, i, j) for i, j in zip(si, sj)}
                ends += list(shared)
            if not starts or not ends:
                failed.append(pad); continue
            mcp = MCP_Geometric(cost, offsets=offs)
            cum, _ = mcp.find_costs(starts, ends, find_all_ends=False)
            reached = [c for c in ends if np.isfinite(cum[c])]
            if not reached:
                failed.append(pad); continue
            end = min(reached, key=lambda c: cum[c])
            path = mcp.traceback(end)
            pts = [xy(i, j) for (z, i, j) in path if z == zi]
            if len(pts) >= 2:
                self.add_track(net, L, simplify(pts), width)
            if end not in shared:
                p0 = xy(end[1], end[2])
                self.add_via(net, p0, *via)
                # a new via takes its site and the space around it (via-to-via spacing)
                via_ok &= ~raster([Point(p0).buffer(via[0] + 0.25)], 1).astype(bool)
        return failed

    def _commit(self, net, path, width, via):
        runs = []
        cur = None
        for z, i, j in path:
            if z == 1:
                if cur:
                    runs.append(cur); cur = None
                runs.append(("V", xy(i, j)))
                continue
            L = "F" if z == 0 else "B"
            if cur and cur[0] == L:
                cur[1].append(xy(i, j))
            else:
                if cur:
                    runs.append(cur)
                cur = (L, [xy(i, j)])
        if cur:
            runs.append(cur)
        placed = set()
        for r in runs:
            if r[0] == "V":
                key = (round(r[1][0], 3), round(r[1][1], 3))
                if key not in placed:
                    self.add_via(net, r[1], *via); placed.add(key)
            elif len(r[1]) >= 2:
                self.add_track(net, r[0], simplify(r[1]), width)

    def save(self, path):
        self.b.BuildConnectivity()
        pcbnew.SaveBoard(path, self.b)


def simplify(pts):
    """Keep the corners of a grid path."""
    if len(pts) <= 2:
        return pts
    out = [pts[0]]
    for a, b, c in zip(pts[:-2], pts[1:-1], pts[2:]):
        d1 = (round((b[0] - a[0]) / RES), round((b[1] - a[1]) / RES))
        d2 = (round((c[0] - b[0]) / RES), round((c[1] - b[1]) / RES))
        if d1 != d2:
            out.append(b)
    out.append(pts[-1])
    return out


def prune_file(path, pads, nets=None):
    """Delete, in the saved board file, tracks with an end that touches nothing of their own net (unused escape stubs),
    repeating until none is left. Works on the file text: removing items through KiCad 7's Python interface corrupts
    its object list. pads: Board.pads (assembly frame). Returns the number of segments removed."""
    import re
    txt = open(path).read()
    netname = {int(m.group(1)): m.group(2) for m in re.finditer(r'^  \(net (\d+) "([^"]*)"\)', txt, re.M)}
    segre = re.compile(r'^  \(segment(?: locked)? \(start ([-\d.]+) ([-\d.]+)\) \(end ([-\d.]+) ([-\d.]+)\) '
                       r'\(width ([-\d.]+)\) \(layer "([FB])\.Cu"\) \(net (\d+)\) \(tstamp ([0-9a-f-]+)\)\)\n', re.M)
    viare = re.compile(r'^  \(via(?: locked)? \(at ([-\d.]+) ([-\d.]+)\) \(size ([-\d.]+)\).*?\(net (\d+)\)', re.M)
    fw = lambda X, Y: (float(X) - 100, 100 - float(Y))
    segs = {m.group(8): dict(a=fw(m.group(1), m.group(2)), b=fw(m.group(3), m.group(4)), w=float(m.group(5)),
                             L=m.group(6), net=netname[int(m.group(7))]) for m in segre.finditer(txt)}
    vias = [(fw(m.group(1), m.group(2)), float(m.group(3)), netname[int(m.group(4))]) for m in viare.finditer(txt)]
    padby = {}
    for q in pads:
        for L in q["layers"]:
            padby.setdefault((q["net"], L), []).append(q["poly"])
    dead = set()
    while True:
        live = {k: v for k, v in segs.items() if k not in dead}
        new = set()
        for k, t in live.items():
            if nets is not None and t["net"] not in nets:
                continue
            for e in (t["a"], t["b"]):
                p = Point(e)
                ok = any(g.distance(p) < t["w"] / 2 - 0.01 for g in padby.get((t["net"], t["L"]), []))
                # an end inside the copper of a via or another track of the net is connected
                ok = ok or any(n == t["net"] and math.dist(v, e) < d / 2 + t["w"] / 2 - 0.01 for v, d, n in vias)
                if not ok:
                    for k2, u in live.items():
                        if k2 != k and u["net"] == t["net"] and u["L"] == t["L"] and \
                                LineString([u["a"], u["b"]]).distance(p) < u["w"] / 2 + t["w"] / 2 - 0.01:
                            ok = True; break
                if not ok:
                    new.add(k); break
        if not new:
            break
        dead |= new
    out = segre.sub(lambda m: "" if m.group(8) in dead else m.group(0), txt)
    open(path, "w").write(out)
    return len(dead)


def prune_kicad(path, pro, max_iter=20):
    """Delete tracks and vias that KiCad's own check reports as dangling (an end or a layer joined to nothing), then
    repeat until it reports none. KiCad decides connectivity; the file text is edited directly (removing items through
    KiCad 7's Python interface corrupts its object list). pro: the project file to place beside a scratch copy so the
    net classes load. Returns (segments removed, vias removed)."""
    import re, shutil, os, tempfile
    nseg = nvia = 0
    tmpd = tempfile.mkdtemp()
    for _ in range(max_iter):
        tb = os.path.join(tmpd, "p.kicad_pcb")
        shutil.copy(path, tb); shutil.copy(pro, os.path.join(tmpd, "p.kicad_pro"))
        b = pcbnew.LoadBoard(tb)
        pcbnew.ZONE_FILLER(b).Fill(b.Zones())
        rpt = os.path.join(tmpd, "p.rpt")
        pcbnew.WriteDRCReport(b, rpt, pcbnew.EDA_UNITS_MILLIMETRES, False)
        rep = open(rpt).read()
        trk = re.findall(r"\[track_dangling\].*?\n.*?\n\s+@\(([-\d.]+) mm, ([-\d.]+) mm\): Track \[([^\]]*)\] on (\w)\.Cu, "
                         r"length ([-\d.]+) mm", rep)
        via = re.findall(r"\[via_dangling\].*?\n.*?\n\s+@\(([-\d.]+) mm, ([-\d.]+) mm\): Via \[([^\]]*)\]", rep)
        if not trk and not via:
            break
        txt = open(path).read()
        netnum = {m.group(2): m.group(1) for m in re.finditer(r'^  \(net (\d+) "([^"]*)"\)', txt, re.M)}
        lines = txt.split("\n")
        keep = []
        for ln in lines:
            drop = False
            m = re.match(r'^  \(segment(?: locked)? \(start ([-\d.]+) ([-\d.]+)\) \(end ([-\d.]+) ([-\d.]+)\) '
                         r'\(width [-\d.]+\) \(layer "(\w)\.Cu"\) \(net (\d+)\)', ln)
            if m:
                sx, sy, ex, ey = map(float, m.group(1, 2, 3, 4))
                for x, y, n, L, length in trk:
                    if netnum.get(n) == m.group(6) and L == m.group(5) and \
                            abs(sx - float(x)) < 2e-3 and abs(sy - float(y)) < 2e-3 and \
                            abs(math.hypot(ex - sx, ey - sy) - float(length)) < 2e-3:
                        drop = True; nseg += 1; break
            m = re.match(r'^  \(via(?: locked)? \(at ([-\d.]+) ([-\d.]+)\).*\(net (\d+)\)', ln)
            if m:
                for x, y, n in via:
                    if netnum.get(n) == m.group(3) and abs(float(m.group(1)) - float(x)) < 2e-3 and \
                            abs(float(m.group(2)) - float(y)) < 2e-3:
                        drop = True; nvia += 1; break
            if not drop:
                keep.append(ln)
        open(path, "w").write("\n".join(keep))
    return nseg, nvia
