"""Routed-board figure: pads, tracks (F.Cu red, B.Cu blue), vias, host-side zone and moat.
Usage: python3 plot_route.py <board> <out stem> [xmin xmax ymin ymax] [--layers F,B] [--title "..."]
Writes <stem>.png/.pdf/.svg."""
import sys
import pcbnew
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MPoly, Circle
from matplotlib.collections import LineCollection, PatchCollection
from shapely.geometry import Polygon

args = [a for a in sys.argv[1:]]
title = None
if "--title" in args:
    i = args.index("--title"); title = args[i + 1]; del args[i:i + 2]
layers = "F,B"
if "--layers" in args:
    i = args.index("--layers"); layers = args[i + 1]; del args[i:i + 2]
layers = layers.split(",")
board, stem = args[0], args[1]
win = [float(v) for v in args[2:6]] if len(args) >= 6 else [-46, 48, -50, 50]
B = pcbnew.LoadBoard(board)
OUTER = [(46.22, -47.96), (46.22, 47.94), (-43.95, 47.94), (-43.95, 25.0), (-44.0, 25.0), (-44.0, 24.5), (-34.5, 24.5),
         (-34.5, 18.5), (-43.95, 18.5), (-43.95, -47.96)]
HOSTZ = Polygon([(-43.95, -47.96), (-11.0, -47.96), (-11.0, -5.0), (-26.0, -5.0), (-26.0, 8.9), (-43.95, 8.9)])
MOAT = HOSTZ.buffer(2.5, join_style=2).intersection(Polygon(OUTER)).difference(HOSTZ)
COL = {"F": "#c0392b", "B": "#1f5fa8"}
LID = {"F": pcbnew.F_Cu, "B": pcbnew.B_Cu}


def W(v):
    return pcbnew.ToMM(v.x) - 100, 100 - pcbnew.ToMM(v.y)


span = max(win[1] - win[0], win[3] - win[2])
fig, ax = plt.subplots(figsize=(10, 10 * (win[3] - win[2]) / (win[1] - win[0]) + 0.6))
ax.add_patch(MPoly(OUTER, closed=True, fc="white", ec="k", lw=0.8))
ax.add_patch(MPoly(list(HOSTZ.exterior.coords), closed=True, fc="#fbeee6", ec="#b5562a", lw=0.5))
for g in getattr(MOAT, "geoms", [MOAT]):
    ax.add_patch(MPoly(list(g.exterior.coords), closed=True, fc="none", ec="#b5562a", lw=0.4, ls="--", hatch="///",
                       alpha=0.4))
pads = []
for fp in B.GetFootprints():
    for pd in fp.Pads():
        on = [L for L in layers if pd.IsOnLayer(LID[L])]
        if not on:
            continue
        ps = pcbnew.SHAPE_POLY_SET()
        pd.TransformShapeToPolygon(ps, LID[on[0]], 0, pcbnew.FromMM(0.01))
        for k in range(ps.OutlineCount()):
            o = ps.Outline(k)
            pads.append(MPoly([W(o.CPoint(i)) for i in range(o.PointCount())], closed=True))
ax.add_collection(PatchCollection(pads, fc="0.72", ec="0.45", lw=0.2, zorder=2))
for L in layers:
    segs, widths = [], []
    for t in B.GetTracks():
        if t.GetClass() == "PCB_TRACK" and t.GetLayer() == LID[L]:
            segs.append([W(t.GetStart()), W(t.GetEnd())]); widths.append(pcbnew.ToMM(t.GetWidth()))
    scale = 72 * 10 / (win[1] - win[0]) * 0.8          # points per mm (approx.)
    ax.add_collection(LineCollection(segs, linewidths=[w * scale for w in widths], colors=COL[L], alpha=0.75,
                                     capstyle="round", zorder=3 if L == "B" else 4))
for t in B.GetTracks():
    if t.GetClass() == "PCB_VIA":
        ax.add_patch(Circle(W(t.GetPosition()), pcbnew.ToMM(t.GetWidth()) / 2, fc="#e0b000", ec="k", lw=0.3, zorder=5))
if span < 40:
    for fp in B.GetFootprints():
        x, y = W(fp.GetPosition())
        if win[0] <= x <= win[1] and win[2] <= y <= win[3]:
            ax.text(x, y, fp.GetReference(), fontsize=5, ha="center", va="center", zorder=6, color="k")
ax.set_xlim(win[0], win[1]); ax.set_ylim(win[2], win[3]); ax.set_aspect("equal")
ax.set_xlabel("x (mm)"); ax.set_ylabel("y (mm)")
ax.set_title(title or f"{board}: tracks on {'+'.join(layers)} (F.Cu red, B.Cu blue), vias yellow", fontsize=9, loc="left")
fig.tight_layout()
for ext in ("png", "pdf", "svg"):
    fig.savefig(f"{stem}.{ext}", dpi=200 if ext == "png" else None)
print("ok")
