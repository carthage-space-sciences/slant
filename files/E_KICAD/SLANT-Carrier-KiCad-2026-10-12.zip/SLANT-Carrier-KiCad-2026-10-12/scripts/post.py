"""Finishing pass on the routed board:
  1. duplicate vias (same net and position) and track stubs shorter than 0.06 mm with a free end are deleted;
  2. the GND pours connect to pads solidly (no thermal spokes; the smallest parts are 0805);
  3. every GND pour fragment gets a stitching via to the In1/In2 plane, and large fragments one about every 5 mm, at
     sites where a 0.6/0.3 mm via clears other copper on both outer layers; refill and repeat once.
Usage: python3 post.py <in.kicad_pcb> <out.kicad_pcb>   (.kicad_pro beside the input)
"""
import sys, os, re, shutil, math, json
import numpy as np
import pcbnew
from shapely.geometry import Point
import rt

src, dst = sys.argv[1], sys.argv[2]
shutil.copy(src, dst); shutil.copy(os.path.splitext(src)[0] + ".kicad_pro", os.path.splitext(dst)[0] + ".kicad_pro")
log = {}
# ---- 1. duplicate vias and tiny stubs (file text)
txt = open(dst).read()
seen, out, ndup = set(), [], 0
for ln in txt.split("\n"):
    m = re.match(r'^  \(via(?: locked)? \(at ([-\d.]+) ([-\d.]+)\).*\(net (\d+)\)', ln)
    if m:
        key = (round(float(m.group(1)), 3), round(float(m.group(2)), 3), m.group(3))
        if key in seen:
            ndup += 1; continue
        seen.add(key)
    out.append(ln)
open(dst, "w").write("\n".join(out))
log["duplicate_vias_removed"] = ndup

b = pcbnew.LoadBoard(dst)
rpt = dst + ".tmp.rpt"
pcbnew.WriteDRCReport(b, rpt, pcbnew.EDA_UNITS_MILLIMETRES, False)
stubs = re.findall(r"\[track_dangling\].*?\n.*?\n\s+@\(([-\d.]+) mm, ([-\d.]+) mm\): Track \[[^\]]*\] on \w\.Cu, "
                   r"length ([-\d.]+) mm", open(rpt).read())
stubs = [(float(x), float(y)) for x, y, L in stubs if float(L) < 0.06]
txt = open(dst).read(); out, nst = [], 0
for ln in txt.split("\n"):
    m = re.match(r'^  \(segment(?: locked)? \(start ([-\d.]+) ([-\d.]+)\) \(end ([-\d.]+) ([-\d.]+)\)', ln)
    if m and any(abs(float(m.group(1)) - x) < 2e-3 and abs(float(m.group(2)) - y) < 2e-3 for x, y in stubs) and \
            math.hypot(float(m.group(3)) - float(m.group(1)), float(m.group(4)) - float(m.group(2))) < 0.06:
        nst += 1; continue
    out.append(ln)
open(dst, "w").write("\n".join(out))
log["stubs_removed"] = nst
os.remove(rpt)

# ---- 2 and 3. pours: solid pad connection; stitching vias
V = (0.6, 0.3)
added = 0
for it in range(2):
    b = pcbnew.LoadBoard(dst)
    for z in b.Zones():
        if z.GetZoneName() == "GND pour":
            z.SetPadConnection(pcbnew.ZONE_CONNECTION_FULL)
    pcbnew.ZONE_FILLER(b).Fill(b.Zones())
    pcbnew.SaveBoard(dst, b)
    # fragments of the filled pours on each outer layer
    frags = []
    for z in b.Zones():
        if z.GetZoneName() != "GND pour":
            continue
        lid = z.GetLayer()
        ps = z.GetFilledPolysList(lid)
        for k in range(ps.OutlineCount()):
            o = ps.Outline(k)
            from shapely.geometry import Polygon
            pts = [rt.W(o.CPoint(i)) for i in range(o.PointCount())]
            if len(pts) >= 3:
                frags.append(("F" if lid == pcbnew.F_Cu else "B", Polygon(pts)))
    B = rt.Board(dst)
    # via sites for GND clear of other copper on both outer layers
    k = B.netid["GND"]
    dm = B.dist_maps("GND")
    vr = V[0] / 2
    vo = B.open_cells(dm, vr, B.allowed("GND", vr))
    ok = vo["F"] & vo["B"] & ~rt.raster([rt.J1BOX], 1).astype(bool)
    vias = [Point(rt.W(t.GetPosition())) for t in B.b.GetTracks() if t.GetClass() == "PCB_VIA" and t.GetNetname() == "GND"]
    tht = [p["poly"] for p in B.pads if p["net"] == "GND" and p["tht"]]
    new = []
    for L, f in frags:
        if f.area < 0.5:
            continue
        has = any(f.contains(v) for v in vias + new) or any(f.intersects(g) for g in tht)
        inner = f.buffer(-(vr + 0.05))
        if inner.is_empty:
            continue
        cand = ok & rt.raster([inner], 1).astype(bool)
        ii, jj = np.nonzero(cand)
        if not len(ii):
            continue
        pts = np.c_[rt.X0 + jj * rt.RES, rt.Y0 + ii * rt.RES]
        want = [] if has else [f.representative_point()]
        # stitching: one site about every 5 mm over large fragments
        if f.area > 40:
            minx, miny, maxx, maxy = f.bounds
            for gx in np.arange(minx + 2.5, maxx, 5.0):
                for gy in np.arange(miny + 2.5, maxy, 5.0):
                    if inner.contains(Point(gx, gy)):
                        want.append(Point(gx, gy))
        for w in want:
            d = np.hypot(pts[:, 0] - w.x, pts[:, 1] - w.y)
            i = int(np.argmin(d))
            p = (float(pts[i, 0]), float(pts[i, 1]))
            if d[i] > 3.0 and has:
                continue
            if any(Point(p).distance(q) < 1.0 for q in vias + new):
                continue
            new.append(Point(p))
            ok &= ~rt.raster([Point(p).buffer(V[0] + 0.3)], 1).astype(bool)
    for p in new:
        B.add_via("GND", (p.x, p.y), *V, lock=False)
    added += len(new)
    B.save(dst)
b = pcbnew.LoadBoard(dst)
pcbnew.ZONE_FILLER(b).Fill(b.Zones()); b.BuildConnectivity(); pcbnew.SaveBoard(dst, b)
log["stitching_vias"] = added
json.dump(log, open(dst.replace(".kicad_pcb", "-post-log.json"), "w"), indent=1)
print(log)
