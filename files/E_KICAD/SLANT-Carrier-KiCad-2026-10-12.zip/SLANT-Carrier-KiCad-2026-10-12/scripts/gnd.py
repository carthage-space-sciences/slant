"""GND for the routed carrier board: copper pours on F.Cu and B.Cu over the payload side, then a plane via (or a short
track to GND copper that already reaches the plane) from every surface-mount GND pad the pours do not reach.

The pour outline is the board less the host-side zone grown by 2.55 mm, the same outline as the In1/In2 GND planes, so
the 2.5 mm barrier holds. Pours: 0.25 mm clearance (the net-class clearances and the custom rules still apply in
KiCad), thermal reliefs 0.25 mm, islands removed. Fan-out: 0.15 mm at the CM5 and J3 (0.4 and 0.5 mm pitch), 0.3 mm
elsewhere, vias 0.6/0.3 mm.
Usage: python3 gnd.py <in.kicad_pcb> <out.kicad_pcb>   (.kicad_pro beside the input)
"""
import sys, os, shutil, json, time
import pcbnew
import rt

src, dst = sys.argv[1], sys.argv[2]
t0 = time.time()
pro = os.path.splitext(src)[0] + ".kicad_pro"
shutil.copy(src, dst); shutil.copy(pro, os.path.splitext(dst)[0] + ".kicad_pro")
bd = pcbnew.LoadBoard(dst)
from shapely.geometry import LineString, Point
from shapely.ops import unary_union
# chassis copper (pads, tracks, vias) held 0.85 mm clear of the pours (chassis rule 0.8 mm), cut into the outlines
# because the fill here does not read the custom rules
Bc = rt.Board(dst)
chas = {L: [p["poly"] for p in Bc.pads if p["net"] == "CHASSIS" and L in p["layers"]] for L in ("F", "B")}
for t in bd.GetTracks():
    if t.GetNetname() != "CHASSIS":
        continue
    if t.GetClass() == "PCB_VIA":
        for L in chas:
            chas[L].append(Point(rt.W(t.GetPosition())).buffer(pcbnew.ToMM(t.GetWidth()) / 2))
    else:
        L = "F" if t.GetLayer() == pcbnew.F_Cu else "B"
        chas[L].append(LineString([rt.W(t.GetStart()), rt.W(t.GetEnd())]).buffer(pcbnew.ToMM(t.GetWidth()) / 2))
base = rt.BOARD.difference(rt.HOSTZ.buffer(2.55, join_style=2))
for lid, L in ((pcbnew.F_Cu, "F"), (pcbnew.B_Cu, "B")):
    pour = base.difference(unary_union(chas[L]).buffer(0.85)) if chas[L] else base
    for q in (pour.geoms if hasattr(pour, "geoms") else [pour]):
        if q.area < 1.0:
            continue
        z = pcbnew.ZONE(bd); z.SetLayer(lid)
        ol = z.Outline(); kk = ol.NewOutline()
        for x, y in list(q.exterior.coords)[:-1]:
            ol.Append(rt.MM(100 + x), rt.MM(100 - y), kk)
        for ring in q.interiors:
            h = ol.NewHole(kk)
            for x, y in list(ring.coords)[:-1]:
                ol.Append(rt.MM(100 + x), rt.MM(100 - y), kk, h)
        z.SetNet(bd.FindNet("GND")); z.SetPadConnection(pcbnew.ZONE_CONNECTION_THERMAL)
        z.SetLocalClearance(rt.MM(0.25)); z.SetMinThickness(rt.MM(0.2)); z.SetAssignedPriority(0)
        z.SetThermalReliefGap(rt.MM(0.25)); z.SetThermalReliefSpokeWidth(rt.MM(0.25))
        z.SetIslandRemovalMode(pcbnew.ISLAND_REMOVAL_MODE_ALWAYS)
        z.SetZoneName("GND pour")
        bd.Add(z)
pcbnew.ZONE_FILLER(bd).Fill(bd.Zones())
bd.BuildConnectivity()
pcbnew.SaveBoard(dst, bd)

# pads the pours reach, by KiCad's connectivity
bd = pcbnew.LoadBoard(dst); bd.BuildConnectivity(); cn = bd.GetConnectivity()
on_pour = set()
for z in bd.Zones():
    if z.GetZoneName() == "GND pour":
        for pd in cn.GetConnectedPads(z):
            on_pour.add((pd.GetParent().GetReference(), pd.GetNumber()))
B = rt.Board(dst)
gnd = [p for p in B.pads if p["net"] == "GND" and not p["tht"] and (p["ref"], p["num"]) not in on_pour]
fine = [p for p in gnd if p["ref"] in ("M1", "J3")]
rest = [p for p in gnd if p["ref"] not in ("M1", "J3")]
V = (0.6, 0.3)
f1 = B.fanout_many("GND", fine, 0.15, V, max_len=4.0, share=True)
f2 = B.fanout_many("GND", rest, 0.3, V, share=True)
f3 = B.fanout_many("GND", f2, 0.2, V, max_len=5.0, share=True) if f2 else []
B.save(dst)
b = pcbnew.LoadBoard(dst)
pcbnew.ZONE_FILLER(b).Fill(b.Zones()); b.BuildConnectivity(); pcbnew.SaveBoard(dst, b)
log = dict(on_pour=len(on_pour), fanout=len(gnd) - len(f1) - len(f3), surface_gnd_pads=len(gnd) + len(on_pour),
           failed=[f"{p['ref']}.{p['num']}" for p in f1 + f3], s=round(time.time() - t0))
json.dump(log, open(dst.replace(".kicad_pcb", "-gnd-log.json"), "w"), indent=1)
print(log)
