"""Placement figure: board outline, host-side zone and moat, courtyards and pads per face, references.
Writes the two-panel figure and each panel alone, as PNG, PDF and SVG.
Usage: python3 plot_pcb.py <stem>
Inputs: out/slant_carrier.kicad_pcb, make_pcb.HOSTZ (copied here)."""
import sys
import pcbnew
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MPoly, Rectangle
from shapely.geometry import Polygon

STEM = sys.argv[1]
B = pcbnew.LoadBoard("out/slant_carrier.kicad_pcb")
OUTER = [(46.22, -47.96), (46.22, 47.94), (-43.95, 47.94), (-43.95, 25.0), (-44.0, 25.0), (-44.0, 24.5), (-34.5, 24.5),
         (-34.5, 18.5), (-43.95, 18.5), (-43.95, -47.96)]
HOSTZ = Polygon([(-43.95, -47.96), (-11.0, -47.96), (-11.0, -5.0), (-26.0, -5.0), (-26.0, 8.9), (-43.95, 8.9)])
BOARD = Polygon(OUTER)
MOAT = HOSTZ.buffer(2.5, join_style=2).intersection(BOARD).difference(HOSTZ)
HOSTNET = lambda n: bool(n) and (n.startswith(("BUS_", "LIM_", "HOST_THERM")) or n in ("FILT_DAMP", "PRI_RTN"))


def W(x, y):
    return pcbnew.ToMM(x) - 100, 100 - pcbnew.ToMM(y)


def bbox(it):
    bb = it.GetBoundingBox()
    x0, y1 = W(bb.GetX(), bb.GetY()); x1, y0 = W(bb.GetRight(), bb.GetBottom())
    return x0, y0, x1, y1


def panel(ax, side):
    lay_cy = pcbnew.F_CrtYd if side == "top" else pcbnew.B_CrtYd
    lay_cu = pcbnew.F_Cu if side == "top" else pcbnew.B_Cu
    ax.add_patch(MPoly(OUTER, closed=True, fc="0.97", ec="k", lw=0.8))
    ax.add_patch(MPoly(list(HOSTZ.exterior.coords), closed=True, fc="#f6d7c3", ec="#b5562a", lw=0.6))
    for g in getattr(MOAT, "geoms", [MOAT]):
        ax.add_patch(MPoly(list(g.exterior.coords), closed=True, fc="none", ec="#b5562a", lw=0.5, ls="--", hatch="////",
                           alpha=0.5))
    if side == "bottom":
        ax.add_patch(Rectangle((4.5, -27.5), 40, 55, fc="#dde6f2", ec="#5b7fae", lw=0.5))
        ax.text(24.5, -26.5, "CM5 module (below)", ha="center", fontsize=6, color="#5b7fae")
    for fp in B.GetFootprints():
        ref = fp.GetReference()
        on = (fp.GetLayer() == lay_cu)
        for it in fp.GraphicalItems():
            if it.GetLayer() == lay_cy:
                x0, y0, x1, y1 = bbox(it)
                ax.add_patch(Rectangle((x0, y0), x1 - x0, y1 - y0, fc="none", ec="0.55", lw=0.3))
        for pd in fp.Pads():
            tht = pd.GetAttribute() in (pcbnew.PAD_ATTRIB_PTH, pcbnew.PAD_ATTRIB_NPTH)
            if not (on or tht):
                continue
            x0, y0, x1, y1 = bbox(pd)
            n = pd.GetNetname()
            col = "#c0392b" if HOSTNET(n) else ("#2c7a3f" if n == "CHASSIS" else ("0.7" if not n else "#1f4e8c"))
            ax.add_patch(Rectangle((x0, y0), x1 - x0, y1 - y0, fc=col, ec="none", alpha=0.85 if on else 0.4))
        if on and not ref.startswith("H"):
            x, y = W(fp.GetPosition().x, fp.GetPosition().y)
            big = ref[0] in "UJFLYM" or ref in ("C13", "C14", "D5", "D1", "RT1", "RT2", "RT3", "RT4")
            ax.text(x, y, ref, ha="center", va="center", fontsize=5.2 if big else 3.2, color="k",
                    fontweight="bold" if big else "normal")
    ax.set_xlim(-46, 48); ax.set_ylim(-50, 50); ax.set_aspect("equal")
    if side == "bottom":
        ax.invert_xaxis()
    ax.set_xlabel("x (mm)"); ax.set_ylabel("y (mm)")
    ax.set_title(f"{'A' if side == 'top' else 'B'}. {'Top face, from above' if side == 'top' else 'Bottom face, from below (x reversed)'}",
                 fontsize=9, loc="left")


NOTE = ("Shaded: host-side zone (bus power, PRI_RTN, limiter, host thermistor). Hatched: 2.5 mm moat (IPC-2221B B2, "
        "301-500 V). Pads: red host side, blue payload, green chassis, grey no net; faint pads are through-hole pads of "
        "parts on the other face.")
fig, axs = plt.subplots(1, 2, figsize=(16, 8.6))
panel(axs[0], "top"); panel(axs[1], "bottom")
fig.suptitle(f"SLANT carrier board, placement after the isolation pass ({STEM.split('Placement-')[-1]})", fontsize=11,
             x=0.01, ha="left")
fig.text(0.01, 0.01, NOTE, fontsize=7.5, color="0.25")
fig.tight_layout(rect=(0, 0.03, 1, 0.96))
for ext in ("png", "pdf", "svg"):
    fig.savefig(f"{STEM}.{ext}", dpi=220 if ext == "png" else None)
plt.close(fig)
for side in ("top", "bottom"):
    fig, ax = plt.subplots(figsize=(8.4, 8.8)); panel(ax, side)
    fig.text(0.01, 0.005, NOTE, fontsize=6, color="0.25", wrap=True); fig.tight_layout(rect=(0, 0.04, 1, 1))
    for ext in ("png", "pdf", "svg"):
        fig.savefig(f"{STEM}-{side}.{ext}", dpi=250 if ext == "png" else None)
    plt.close(fig)
# Inner-layer plane (In1; In2 is the same): filled copper from the board file
fig, ax = plt.subplots(figsize=(8.4, 8.8))
ax.add_patch(MPoly(OUTER, closed=True, fc="white", ec="k", lw=0.8))
for z in B.Zones():
    if z.GetIsRuleArea() or z.GetLayer() != pcbnew.In1_Cu:
        continue
    col = "#c0392b" if z.GetNetname() == "PRI_RTN" else "#1f4e8c"
    ps = z.GetFilledPolysList(pcbnew.In1_Cu)
    for i in range(ps.OutlineCount()):
        ol = ps.Outline(i)
        ax.add_patch(MPoly([W(ol.CPoint(j).x, ol.CPoint(j).y) for j in range(ol.PointCount())], closed=True, fc=col,
                           ec="none", alpha=0.75))
        for h in range(ps.HoleCount(i)):
            hl = ps.Hole(i, h)
            ax.add_patch(MPoly([W(hl.CPoint(j).x, hl.CPoint(j).y) for j in range(hl.PointCount())], closed=True,
                               fc="white", ec="none"))
for g in getattr(MOAT, "geoms", [MOAT]):
    ax.add_patch(MPoly(list(g.exterior.coords), closed=True, fc="none", ec="#b5562a", lw=0.5, ls="--", hatch="////", alpha=0.5))
ax.text(-27, -30, "PRI_RTN island", ha="center", color="w", fontsize=9, fontweight="bold")
ax.text(15, 35, "GND plane", ha="center", color="w", fontsize=9, fontweight="bold")
ax.set_xlim(-46, 48); ax.set_ylim(-50, 50); ax.set_aspect("equal"); ax.set_xlabel("x (mm)"); ax.set_ylabel("y (mm)")
ax.set_title("C. Inner layer In1 (In2 identical), filled copper; holes are pad clearances", fontsize=9, loc="left")
fig.tight_layout()
for ext in ("png", "pdf", "svg"):
    fig.savefig(f"{STEM}-In1.{ext}", dpi=250 if ext == "png" else None)
plt.close(fig)
print("ok")
