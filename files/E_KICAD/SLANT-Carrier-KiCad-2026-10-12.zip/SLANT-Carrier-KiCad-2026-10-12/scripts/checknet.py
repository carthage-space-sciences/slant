"""Compare the netlist KiCad exports from the drawn schematic with the intended netlist in design.py."""
import sys, xml.etree.ElementTree as ET
from collections import defaultdict
import design as D
x = ET.parse(sys.argv[1]).getroot()
got = {}
for n in x.find("nets"):
    nodes = frozenset((d.get("ref"), d.get("pin")) for d in n.findall("node") if not d.get("ref").startswith("#"))
    name = n.get("name").split("/")[-1]
    if nodes:
        got[nodes] = name
want = defaultdict(set)
for c in D.COMP:
    if c["ref"].startswith("#"): continue
    for p, net in c["pins"].items():
        if net: want[net].add((c["ref"], p))
want_sets = {frozenset(v): k for k, v in want.items()}
missing = [k for s, k in want_sets.items() if s not in got]
extra = [got[s] for s in got if s not in want_sets and len(s) > 1]
named_wrong = [(k, got[s]) for s, k in want_sets.items() if s in got and got[s] != k]
comps = {c.get("ref") for c in x.find("components")}
print("components in netlist:", len([c for c in comps if not c.startswith('#')]), "design:", len({c['ref'] for c in D.COMP if not c['ref'].startswith('#')}))
print("intended nets:", len(want_sets), "matched exactly:", len(want_sets) - len(missing))
print("missing or merged:", missing[:20]); print("extra:", extra[:20]); print("name mismatch:", named_wrong[:10])
