"""Independent check of the isolation rules on a routed board (all four copper layers), from the copper geometry:
  - host-side copper (BUS_*, FILT_DAMP, PRI_RTN, LIM_*, HOST_THERM_*) to payload copper: at least 2.5 mm, or 1.5 mm
    where both pieces lie in J1's courtyard (J1 rules, KC 10 Oct 2026);
  - CHASSIS copper to any other net: at least 0.8 mm, except the chassis-tie parts R14 and C19.
Copper: pads (per layer; plated pads on every layer), tracks, vias (every layer), filled zones.
Usage: python3 check_barrier.py <board.kicad_pcb>   (prints violations; exit status 1 if any)
"""
import sys
import pcbnew
from shapely.geometry import Polygon, Point, LineString, box as sbox
from shapely.ops import unary_union
from shapely import STRtree

B = pcbnew.LoadBoard(sys.argv[1])
J1BOX = sbox(-32.78, 1.62, -27.32, 22.38)
HOST = lambda n: n.startswith(("BUS_", "LIM_", "HOST_THERM")) or n in ("FILT_DAMP", "PRI_RTN")
LAYERS = {"F": pcbnew.F_Cu, "In1": pcbnew.In1_Cu, "In2": pcbnew.In2_Cu, "B": pcbnew.B_Cu}


def W(v):
    return (pcbnew.ToMM(v.x) - 100, 100 - pcbnew.ToMM(v.y))


def polyset(ps):
    out = []
    for k in range(ps.OutlineCount()):
        o = ps.Outline(k)
        ext = [W(o.CPoint(i)) for i in range(o.PointCount())]
        holes = []
        for h in range(ps.HoleCount(k)):
            hl = ps.Hole(k, h)
            holes.append([W(hl.CPoint(i)) for i in range(hl.PointCount())])
        if len(ext) >= 3:
            out.append(Polygon(ext, holes))
    return unary_union(out) if out else None


items = {L: [] for L in LAYERS}      # (net, owner ref, geometry)
for fp in B.GetFootprints():
    for pd in fp.Pads():
        n = pd.GetNetname()
        if not n:
            continue
        for L, lid in LAYERS.items():
            if pd.IsOnLayer(lid) or (pd.GetAttribute() == pcbnew.PAD_ATTRIB_PTH and L in ("In1", "In2")):
                ps = pcbnew.SHAPE_POLY_SET()
                pd.TransformShapeToPolygon(ps, lid if pd.IsOnLayer(lid) else pcbnew.F_Cu, 0, pcbnew.FromMM(0.005))
                g = polyset(ps)
                if g is not None:
                    items[L].append((n, fp.GetReference(), g))
for t in B.GetTracks():
    n = t.GetNetname()
    if t.GetClass() == "PCB_VIA":
        g = Point(W(t.GetPosition())).buffer(pcbnew.ToMM(t.GetWidth()) / 2)
        for L in LAYERS:
            items[L].append((n, "via", g))
    else:
        for L, lid in LAYERS.items():
            if t.GetLayer() == lid:
                items[L].append((n, "track", LineString([W(t.GetStart()), W(t.GetEnd())]).buffer(
                    pcbnew.ToMM(t.GetWidth()) / 2)))
for z in B.Zones():
    if z.GetIsRuleArea():
        continue
    for L, lid in LAYERS.items():
        if z.IsOnLayer(lid) and z.IsFilled():
            g = polyset(z.GetFilledPolysList(lid))
            if g is not None:
                items[L].append((z.GetNetname(), "zone", g))

viol = []
for L, its in items.items():
    geoms = [g for _, _, g in its]
    tree = STRtree(geoms)
    for i, (n, ref, g) in enumerate(its):
        if HOST(n):
            for j in tree.query(g.buffer(2.5)):
                m, r2, h = its[j]
                if not m or HOST(m) or m == "CHASSIS":
                    continue
                d = g.distance(h)
                lim = 1.5 if (g.intersects(J1BOX) and h.intersects(J1BOX)) else 2.5
                if d < lim - 1e-4:
                    viol.append((L, "barrier", n, ref, m, r2, round(d, 3), lim))
        if n == "CHASSIS" and ref not in ("R14", "C19"):
            for j in tree.query(g.buffer(0.8)):
                m, r2, h = its[j]
                if m in ("CHASSIS", "") or r2 in ("R14", "C19"):
                    continue
                d = g.distance(h)
                if d < 0.8 - 1e-4:
                    viol.append((L, "chassis", n, ref, m, r2, round(d, 3), 0.8))
for v in viol:
    print(*v)
print(f"{len(viol)} violations; items checked per layer:", {L: len(v) for L, v in items.items()})
sys.exit(1 if viol else 0)
