"""Routes the carrier board's critical nets with rt.py (KC, 10 Oct 2026, 21:53). The remaining nets go to Freerouting.

Order:
  1. host side (inside the host-side zone): bus power chain, damping bank, limiter signals, host thermistor, and a via
     from every PRI_RTN surface pad to the PRI_RTN island on In1/In2;
  2. differential pairs: the USB pairs (90 ohm) and the RS-422 and CAN pairs (120 ohm), P first, then N drawn toward
     P's track at the pair pitch;
  3. payload power: shunt sense lines (Kelvin, to the shunt pads), then the 5 V trunks at 1.0 mm, then 0.3 mm branches
     to small loads.
Tracks too wide to reach a fine-pitch pad are finished at 0.3 mm (neck-down). Every track and via is locked.
A4-8 (11 Oct 2026): the chassis tie and the transceivers' single-ended escapes go before the pairs (section 1b).
Usage: python3 route_critical.py <in.kicad_pcb> <out.kicad_pcb>  (the .kicad_pro must sit beside the input)
"""
import sys, time, json
import rt
from shapely.geometry import LineString

src, dst = sys.argv[1], sys.argv[2]
LOG = {"nets": {}, "fail": {}, "host_signal_orders": []}
V_PWR, V_SIG, V_USB = (0.8, 0.4), (0.7, 0.35), (0.6, 0.3)
B = None


def go(net, width, via, pads=None, neck=0.25, **kw):
    """Route at full width (with any reserved spacing), then without the reservation, then at the neck width."""
    t = time.time()
    u = B.route(net, width, via, pads=pads, **kw)
    plain = {k: v for k, v in kw.items() if k != "reserve"}
    if u and "reserve" in kw:
        u = B.route(net, width, via, pads=pads, **plain)
    if u and neck and neck < width:
        u = B.route(net, neck, via, pads=pads, **plain)
    LOG["nets"].setdefault(net, []).append(dict(width=width, pads=None if pads is None else sorted(map(list, pads)),
                                                unreached=[f"{p['ref']}.{p['num']}" for p in u],
                                                s=round(time.time() - t, 1)))
    print(f"{net:14s} w={width:<5} unreached={[p['ref'] + '.' + p['num'] for p in u]} {time.time() - t:.1f}s",
          flush=True)
    LOG["fail"].pop(net, None)
    if u:
        LOG["fail"][net] = [p["ref"] + "." + p["num"] for p in u]
    return u


def ppos(ref, num):
    return [p for p in B.pads if p["ref"] == ref and p["num"] == num][0]["pos"]


def prelude():
    """U1 (TPS26636, HTSSOP-20, 0.65 mm pitch): join adjacent pins of one net at the pads, tie the PRI_RTN pins straight
    to the exposed pad (its thermal vias reach the PRI_RTN island), and draw a 1.2 mm escape stub straight out from each
    signal pin and from pin 6 (BUS_F, between unconnected pins 5 and limiter pin 7), so no route closes another pin's
    exit."""
    B.add_track("BUS_F", "F", [ppos("U1", "1"), ppos("U1", "3")], 0.4)
    B.add_track("BUS_SW", "F", [ppos("U1", "20"), ppos("U1", "18")], 0.4)
    for num, dy in (("8", +1.3), ("9", +1.3), ("16", -1.3)):     # bottom row pins go up (+y), top row pin goes down
        x, y = ppos("U1", num)
        B.add_track("PRI_RTN", "F", [(x, y), (x, y + dy)], 0.3)
    for num in ("6", "7", "10"):                                     # bottom row (y -18.4): out is -y
        x, y = ppos("U1", num)
        B.add_track([p for p in B.pads if p["ref"] == "U1" and p["num"] == num][0]["net"], "F",
                    [(x, y), (x, y - 1.2)], 0.3 if num != "6" else 0.4)
    for num in ("11", "13", "14", "15"):                             # top row (y -12.6): out is +y
        x, y = ppos("U1", num)
        B.add_track([p for p in B.pads if p["ref"] == "U1" and p["num"] == num][0]["net"], "F",
                    [(x, y), (x, y + 1.2)], 0.3)


# ------------------------------------------------------------------ 1. host side
# Limiter and host-thermistor signals first (short runs between U1's pins and their parts). When one cannot finish,
# the board is reloaded and the failed nets go first (up to five orders).
order = ["LIM_SHDN", "LIM_DVDT", "LIM_ILIM", "LIM_IMON", "LIM_UVLO", "LIM_FLT", "HOST_THERM_A", "HOST_THERM_B"]
for attempt in range(5):
    B = rt.Board(src)
    prelude()
    LOG["fail"] = {}
    failed = [n for n in order if go(n, 0.25, V_SIG, neck=0.2)]
    LOG["host_signal_orders"].append(dict(order=list(order), failed=failed))
    if not failed:
        break
    order = failed + [n for n in order if n not in failed]
for net in ("BUS_IN", "BUS_F", "BUS_SW", "BUS_FILT", "FILT_DAMP"):
    go(net, 1.0, V_PWR)
n_ok = 0
for p in [p for p in B.pads if p["net"] == "PRI_RTN" and not p["tht"]]:
    if p["ref"] == "U1" and p["num"] == "21":
        continue                          # U1's thermal pad: its own thermal vias reach the island
    if p["ref"] == "U1" and p["num"] in ("8", "9", "16"):
        continue                          # tied to the exposed pad above
    ok = B.fanout("PRI_RTN", p, 0.5, V_PWR)
    if not ok:                            # no room for a via: a track to U1's exposed pad instead
        ok = not B.route("PRI_RTN", 0.3, V_SIG, pads={(p["ref"], p["num"]), ("U1", "21")})
    n_ok += ok
    if not ok:
        LOG["fail"].setdefault("PRI_RTN fanout", []).append(f"{p['ref']}.{p['num']}")
print("PRI_RTN fanout", n_ok, LOG["fail"].get("PRI_RTN fanout"), flush=True)

# ------------------------------------------------------------------ 1b. chassis tie and transceiver escapes (A4-8)
# The chassis tie (J1 pin 26 to R14/C19 and mounting hole H3) runs before the pairs, which otherwise close its path
# out of J1's pin field.
go("CHASSIS", 0.5, V_SIG, pads={("J1", "26"), ("R14", "2"), ("C19", "2"), ("H3", "1")}, neck=0.3)
# Single-ended pins of the RS-422 transceivers sit between pair pins (U15 pins 3-5 and 12, U16 pins 3 and 6). A short
# track to a via from each, placed before the pairs, keeps a way out on B.Cu once the pairs occupy F.Cu.
esc = []
for ref, nums in (("U15", ("3", "4", "5", "9", "12", "15")), ("U16", ("3", "6"))):
    for num in nums:
        p = [q for q in B.pads if q["ref"] == ref and q["num"] == num][0]
        if not B.fanout(p["net"], p, 0.2, V_USB, max_len=2.5):
            esc.append(f"{ref}.{num}")
LOG["fail"]["transceiver escapes"] = esc
print("transceiver escapes failed", esc, flush=True)

# ------------------------------------------------------------------ 2. differential pairs
# USB at the CM5: the 0.205 mm track cannot enter a 0.2 mm pad at 0.4 mm pitch with 0.2 mm clearance, so each pad gets
# a 0.15 mm neck 1.0 mm long, straight out from the pad's free end (KiCad allows a narrower track at a pad).
def neck(ref, num, dx):
    p = [q for q in B.pads if q["ref"] == ref and q["num"] == num][0]
    x, y = p["pos"]
    a, b = (x, y), (x + dx, y)
    B.add_track(p["net"], p["layers"][0], [a, b], 0.15)
    return (ref, num), LineString([a, b]).buffer(0.03)


ext = {}
for num in ("128", "130", "134", "136", "140", "142"):        # outer row of the 101-200 connector, x = 6.18: out is -x
    k, g = neck("M1", num, -1.1); ext[k] = g
for num in ("103", "105"):                                    # inner row, x = 8.82: into the 1.5 mm channel between
    k, g = neck("M1", num, -0.9); ext[k] = g                  # the rows (-x), which opens at the connector's end
USB = [("HEAD_SSTX_P", "HEAD_SSTX_N"), ("HEAD_SSRX_P", "HEAD_SSRX_N"), ("HEAD_USB2_P", "HEAD_USB2_N"),
       ("MAINT_USB_P", "MAINT_USB_N")]
NECKS = {}                                                    # net -> neck segment ends (KiCad nm), kept on a retry
for (ref, num), g in ext.items():
    p = [q for q in B.pads if q["ref"] == ref and q["num"] == num][0]
    NECKS[p["net"]] = p


def strip(nets):
    """Save, delete the nets' tracks and vias except the CM5 necks, and reload (rt.Board has no item removal)."""
    global B
    import re, os, shutil
    tmp = dst.replace(".kicad_pcb", "-tmp.kicad_pcb")
    B.save(tmp)
    shutil.copy(src.replace(".kicad_pcb", ".kicad_pro"), tmp.replace(".kicad_pcb", ".kicad_pro"))
    txt = open(tmp).read()
    codes = {m.group(1) for m in re.finditer(r'^  \(net (\d+) "([^"]*)"\)', txt, re.M) if m.group(2) in nets}
    keep = {(round(100 + NECKS[n]["pos"][0], 3), round(100 - NECKS[n]["pos"][1], 3)) for n in nets if n in NECKS}
    out = []
    for ln in txt.split("\n"):
        m = re.match(r'^  \((segment|via)\b.*\(net (\d+)\)', ln)
        if m and m.group(2) in codes:
            st = re.search(r'\(start ([-\d.]+) ([-\d.]+)\)', ln)
            if st and (round(float(st.group(1)), 3), round(float(st.group(2)), 3)) in keep:
                out.append(ln); continue
            continue
        out.append(ln)
    open(tmp, "w").write("\n".join(out))
    B = rt.Board(tmp)


LOG["usb_orders"] = []
# The CM5's USB pins sit in one row: SSRX (128/130), USB2 (134/136), SSTX (140/142). A pair whose N strays closes the
# exit of the pair beside it, so the four pairs are tried in up to three orders, inner pair first after the first (A4-8).
ORDERS = [USB, [USB[2], USB[0], USB[1], USB[3]], [USB[2], USB[1], USB[0], USB[3]]]
for oi, order in enumerate(ORDERS):
    if oi:
        strip({n for pr in USB for n in pr})
    bad = []
    for P, N in order:
        u = go(P, 0.205, V_USB, neck=0.15, pad_ext=ext, reserve=0.205 + 2 * (0.15 + 0.205))
        u = go(N, 0.205, V_USB, neck=0.15, pad_ext=ext, attract=(P, 0.205 + 0.15)) or u
        if u:
            bad.append(P)
    LOG["usb_orders"].append(dict(order=[p for p, n in order], failed=bad))
    if not bad:
        break
# J1 pairs from the top pin down: each pair's P leaves J1's +x row and its N the -x row, and both turn upward, so the
# pin nearest the top takes the innermost path. P and N cannot run side by side inside J1's pin field.
D120 = [("CANH", "CANL"), ("PPS_IN_P", "PPS_IN_N"), ("BULKIN_P", "BULKIN_N"), ("BULKOUT_P", "BULKOUT_N"),
        ("TLM_P", "TLM_N"), ("CMD_IN_P", "CMD_IN_N")]
# J1's N lines all pass between the board notch (x -34.5, y 18.5 to 24.5) and chassis pin 26 on F.Cu (the chassis track
# takes B.Cu there). The gap allows six 0.15 mm lines at 0.35 mm pitch with 0.07 mm to spare at each side: centres
# from -32.10 (0.80 mm to pin 26's pad, 0.53 mm to the latch slot) to -33.85 (0.58 mm to the notch edge). The raster
# margin does not leave that room, so the six lanes are drawn here (A4-8): from each pin straight left to its lane,
# then up past the notch; pin 19 first rises inside J1's courtyard to clear the moat (y 11.4).
LANES = [("24", "CANL", -32.10, 23.0), ("23", "PPS_IN_N", -32.45, 23.5), ("22", "BULKIN_N", -32.80, 24.0),
         ("21", "BULKOUT_N", -33.15, 24.5), ("20", "TLM_N", -33.50, 25.0), ("19", "CMD_IN_N", -33.85, 25.5)]
# each lane ends turning 45 degrees away from the lanes outside it, into open board. N goes first (from its lane's
# end), then P drawn toward it, so no P track closes a lane end.
LANE = {net: (num, x, ytop) for num, net, x, ytop in LANES}


def lane(net):
    num, x, ytop = LANE[net]
    px, py = ppos("J1", num)
    pts = [(px, py)] + ([(px - 0.85, py + 0.85)] if num == "19" else []) + [(x, py + (0.85 if num == "19" else 0)),
                                                                         (x, ytop), (x + 0.7, ytop + 0.7)]
    B.add_track(net, "F", pts, 0.15)


for net in LANE:
    lane(net)
# J2's maintenance signals reach the CM5 through the ESD arrays D2 and D3 beside J2. The J1 pair bundle passes on both
# sides of J2, so the short J2-to-diode legs go before the pairs; the diode-to-CM5 legs are routed with the rest (A4-8).
J2LEGS = [("MAINT_UART_TX", ("J2", "6"), ("D2", "4")), ("MAINT_UART_RX", ("J2", "7"), ("D2", "5")),
          ("NRPIBOOT", ("J2", "9"), ("D3", "1")), ("PMIC_EN", ("J2", "10"), ("D3", "2")),
          ("PWR_BUT", ("J2", "11"), ("D3", "4")), ("EEPROM_NWP", ("J2", "12"), ("D3", "5")),
          ("MAINT_3V3_REF", ("J2", "13"), ("R69", "2"))]
for net, a_, b_ in J2LEGS:
    go(net, 0.2, V_SIG, pads={a_, b_}, neck=0.15)
LOG["pair_retries"] = []
for P, N in D120:
    go(N, 0.15, V_SIG, neck=0, reserve=0.15 + 2 * (0.3 + 0.15))
    if go(P, 0.15, V_SIG, neck=0, attract=(N, 0.15 + 0.3)):
        # N closed P's pin at the transceiver: both again, P first and N drawn toward it, N from its lane
        LOG["pair_retries"].append(P)
        strip({P, N})
        lane(N)
        go(P, 0.15, V_SIG, neck=0, reserve=0.15 + 2 * (0.3 + 0.15))
        go(N, 0.15, V_SIG, neck=0, attract=(P, 0.15 + 0.3))

# ------------------------------------------------------------------ 3. payload power
# Kelvin sense lines first, straight to the shunt pads
for net, a, b in (("SW1_OUT", ("U7", "4"), ("R17", "1")), ("5V_CM5", ("U7", "5"), ("R17", "2")),
                  ("SW2_OUT", ("U8", "4"), ("R18", "1")), ("5V_HEAD", ("U8", "5"), ("R18", "2"))):
    go(net, 0.25, V_SIG, pads={a, b}, neck=0.2)
TRUNK = {
    "5V_BUS": {("U3", "6"), ("C13", "2"), ("C15", "1"), ("C16", "1"), ("C66", "1"), ("U5", "5"), ("C21", "1"),
               ("U6", "5"), ("C24", "1"), ("U10", "1"), ("U10", "5"), ("C34", "1")},
    "SW1_OUT": {("U5", "6"), ("C22", "1"), ("R17", "1")},
    "5V_CM5": {("R17", "2"), ("C26", "1"), ("C69", "1")} | {("M1", str(n)) for n in (77, 79, 81, 83, 85, 87)},
    "SW2_OUT": {("U6", "6"), ("C25", "1"), ("R18", "1")},
    "5V_HEAD": {("R18", "2"), ("C27", "1"), ("J3", "1"), ("J3", "2"), ("J3", "3")},
}
# CM5 5 V pins 77-87 are adjacent in one row (0.4 mm pitch): a 0.2 mm bar through their centres joins all six and keeps
# 0.2 mm to pins 75 and 89
B.add_track("5V_CM5", "B", [ppos("M1", "77"), ppos("M1", "87")], 0.2)
for net, pads in TRUNK.items():
    go(net, 1.0, V_PWR, pads=pads, neck=0.25)
for net in TRUNK:
    go(net, 0.3, V_SIG, neck=0.2)

B.save(dst)
# unused escape stubs: delete tracks with an end whose copper meets nothing of their net
LOG["pruned_segments"] = rt.prune_file(dst, B.pads)
print("pruned segments", LOG["pruned_segments"])
json.dump(LOG, open(dst.replace(".kicad_pcb", "-route-log.json"), "w"), indent=1)
print("failures:", LOG["fail"])
