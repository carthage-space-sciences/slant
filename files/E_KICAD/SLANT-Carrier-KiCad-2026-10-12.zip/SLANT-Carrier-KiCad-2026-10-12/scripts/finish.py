"""Finishes the negotiated routing: the nets still in conflict at the last round lose their tracks, then each is routed
again with every other net's copper as a hard obstacle (rt.Board.route, net-class width, then a neck-down). What
cannot be routed is listed as open connections.
A4-8 (11 Oct 2026): the nets the negotiation left with unreached pads keep their partial routes and are then completed
the same way, at net-class width, then the neck width, then 0.15 mm. Three orders are tried (most pads first, fewest
pads first, the negotiation's order) and the result with the fewest open pads is kept.
Usage: python3 finish.py <neg.kicad_pcb> <neg-negotiate-log.json> <out.kicad_pcb>   (.kicad_pro beside the input)
"""
import sys, re, json, os, shutil, time
import rt

src, logf, dst = sys.argv[1], sys.argv[2], sys.argv[3]
t0 = time.time()
LOG = json.load(open(logf))
last = LOG["rounds"][-1]
redo = list(last["nets_in_conflict"])
txt = open(src).read()
netnum = {m.group(2): m.group(1) for m in re.finditer(r'^  \(net (\d+) "([^"]*)"\)', txt, re.M)}
codes = {netnum[n] for n in redo}
out, removed = [], 0
for ln in txt.split("\n"):
    m = re.match(r'^  \((segment|via)\b.*\(net (\d+)\)', ln)
    if m and m.group(2) in codes and " locked" not in ln[:20]:
        removed += 1
        continue
    out.append(ln)
open(dst, "w").write("\n".join(out))
shutil.copy(os.path.splitext(src)[0] + ".kicad_pro", os.path.splitext(dst)[0] + ".kicad_pro")
print("removed", removed, "items of", redo, flush=True)
CHASSIS_PADS = {("J1", "26"), ("R14", "2"), ("C19", "2"), ("H3", "1")}
W = {"Default": (0.2, 0.15), "PowerLow": (0.4, 0.25), "Power": (0.3, 0.2), "Chassis": (0.5, 0.3),
     "Diff120": (0.15, 0.15), "USB90": (0.205, 0.15)}
base = dst.replace(".kicad_pcb", "-base.kicad_pcb")
shutil.copy(dst, base); shutil.copy(os.path.splitext(dst)[0] + ".kicad_pro", os.path.splitext(base)[0] + ".kicad_pro")
B0 = rt.Board(base)
unr = [n for n in LOG.get("unreached", {}) if n not in redo]
npads = {n: len([p for p in B0.pads if p["net"] == n]) for n in redo + unr}
# three orders, each from the same stripped board; the one leaving the fewest open pads is kept (A4-8)
ORDERS = {"most pads first": sorted(redo, key=lambda n: -npads[n]) + sorted(unr, key=lambda n: -npads[n]),
          "fewest pads first": sorted(redo, key=lambda n: npads[n]) + sorted(unr, key=lambda n: npads[n]),
          "negotiation order": list(redo) + list(unr)}
trials = {}
for name, order in ORDERS.items():
    B = rt.Board(base)
    res = {}
    for n in order:
        w, nk = W.get(B.netcls[B.netid[n]], (0.2, 0.15))
        pads = CHASSIS_PADS if n == "CHASSIS" else None
        u = B.route(n, w, (0.6, 0.3), pads=pads)
        if u:
            u = B.route(n, nk, (0.6, 0.3), pads=pads)
        if u and nk > 0.15:                     # fine-pitch pins: 0.15 mm, the board's minimum track (A4-8)
            u = B.route(n, 0.15, (0.6, 0.3), pads=pads)
        res[n] = [f"{p['ref']}.{p['num']}" for p in u]
    out_t = dst.replace(".kicad_pcb", f"-t{len(trials)}.kicad_pcb")
    B.save(out_t)
    nopen = sum(len(v) for v in res.values())
    trials[name] = dict(file=out_t, open=nopen, rerouted=res)
    print(f"{name}: {nopen} open pads", {k: v for k, v in res.items() if v}, flush=True)
best = min(trials, key=lambda k: trials[k]["open"])
shutil.copy(trials[best]["file"], dst)
res = trials[best]["rerouted"]
pr = rt.prune_file(dst, B0.pads)
json.dump(dict(rerouted=res, order=best, trials={k: v["open"] for k, v in trials.items()}, removed=removed, pruned=pr,
               s=round(time.time() - t0)), open(dst.replace(".kicad_pcb", "-finish-log.json"), "w"), indent=1)
print("done", best, res, "pruned", pr)
