"""Write the SLANT carrier-board KiCad project (KiCad 7 file format, opens in 7, 8 and 9) from design.py.

Every component pin gets a short wire and a net label. Nets on more than one sheet use global labels.
Unused pins get a no-connect flag. Power nets without a power-output pin get a PWR_FLAG.
Usage: python gen.py <outdir>
"""
import math, os, sys, uuid
from collections import defaultdict
import design as D

OUT = sys.argv[1] if len(sys.argv) > 1 else "out"
PROJ = "slant_carrier"
LIB = "SLANT"
G = 2.54
DATE = "2026-10-10"
REV = "A4-5"
os.makedirs(OUT, exist_ok=True)
NS = uuid.UUID("6b0d5a8e-9b1e-4a38-9c51-5a1a4e2f0a00")


def U(*k):
    return str(uuid.uuid5(NS, "/".join(map(str, k))))


def q(s):
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'


def snap(v):
    return round(round(v / 1.27) * 1.27, 2)


def font(h=1.27):
    return f"(effects (font (size {h} {h})))"


# ------------------------------------------------------------------ symbol geometry
def units_of(sym):
    s = D.SYM[sym]
    return s["units"] if "units" in s else [s["pins"]]


GEO = {}  # (sym, unit) -> dict(pins={num: (x, y, side)}, w, h)


def geo(sym, unit=1):
    key = (sym, unit)
    if key in GEO:
        return GEO[key]
    s = D.SYM[sym]
    pins = units_of(sym)[unit - 1]
    out = {}
    if s["kind"] == "two":
        out = {"1": (-5.08, 0, "L"), "2": (5.08, 0, "R")}
        g = dict(pins=out, x0=-2.54, x1=2.54, y0=-1.27, y1=1.27)
    elif s["kind"] in ("one", "flag"):
        out = {"1": (0 if s["kind"] == "flag" else -2.54, 0, "L")}
        g = dict(pins=out, x0=-1.27, x1=1.27, y0=-1.27, y1=1.27)
    else:
        L = [p for p in pins if p[3] == "L"]
        R = [p for p in pins if p[3] == "R"]
        wl = max([len(p[1]) for p in L] + [0])
        wr = max([len(p[1]) for p in R] + [0])
        half = math.ceil(((wl + wr) * 0.95 + 5.0) / 2 / G) * G
        n = max(len(L), len(R))
        top = math.ceil((n - 1) / 2) * G
        for side, lst, x in (("L", L, -half - G), ("R", R, half + G)):
            for i, p in enumerate(lst):
                out[p[0]] = (x, top - i * G, side)
        g = dict(pins=out, x0=-half, x1=half, y0=top - (n - 1) * G - G, y1=top + G)
    GEO[key] = g
    return g


def lib_symbol(sym, prefix=True):
    s = D.SYM[sym]
    name = f"{LIB}:{sym}" if prefix else sym
    kind = s["kind"]
    refp = {"two": "R", "one": "TP", "flag": "#FLG", "ic": "U"}[kind]
    if sym in ("C", "C_Pol"):
        refp = "C"
    elif sym == "L":
        refp = "L"
    elif sym == "Fuse":
        refp = "F"
    elif sym == "D_Schottky":
        refp = "D"
    elif sym == "Crystal":
        refp = "Y"
    elif sym == "Thermistor":
        refp = "RT"
    elif sym == "MountingHole":
        refp = "H"
    elif sym.startswith("Conn"):
        refp = "J"
    elif sym == "CM5":
        refp = "M"
    hide_names = kind in ("two", "one", "flag")
    lines = [f"(symbol {q(name)}" + (" (power)" if kind == "flag" else "")
             + (" (pin_numbers hide)" if kind in ("one", "flag", "two") else "")
             + (" (pin_names (offset 0) hide)" if hide_names else " (pin_names (offset 1.016))")
             + " (in_bom " + ("no" if kind == "flag" else "yes") + ") (on_board yes)"]
    lines.append(f'  (property "Reference" {q(refp)} (at 0 3.81 0) {font()})')
    lines.append(f'  (property "Value" {q(sym)} (at 0 -3.81 0) {font()})')
    lines.append(f'  (property "Footprint" "" (at 0 0 0) (effects (font (size 1.27 1.27)) hide))')
    lines.append(f'  (property "Datasheet" {q(s.get("ds", ""))} (at 0 0 0) (effects (font (size 1.27 1.27)) hide))')
    lines.append(f'  (property "ki_description" {q(s["desc"])} (at 0 0 0) (effects (font (size 1.27 1.27)) hide))')
    nunits = len(units_of(sym))
    for ui in range(1, nunits + 1):
        g = geo(sym, ui)
        gr = []
        if kind == "ic":
            gr.append(f"(rectangle (start {g['x0']} {g['y1']}) (end {g['x1']} {g['y0']}) (stroke (width 0.254) (type default)) (fill (type background)))")
        elif kind == "two":
            gg = s["g"]
            if gg in ("R", "RT", "F", "L"):
                gr.append("(rectangle (start -2.54 1.016) (end 2.54 -1.016) (stroke (width 0.254) (type default)) (fill (type none)))")
                if gg == "RT":
                    gr.append("(polyline (pts (xy -3.302 -1.778) (xy -1.778 -1.778) (xy 1.778 1.778)) (stroke (width 0.2) (type default)) (fill (type none)))")
                if gg == "F":
                    gr.append("(polyline (pts (xy -2.54 0) (xy 2.54 0)) (stroke (width 0.2) (type default)) (fill (type none)))")
                if gg == "L":
                    gr.append("(polyline (pts (xy -2.54 0.5) (xy 2.54 0.5)) (stroke (width 0.2) (type default)) (fill (type none)))")
                gr.append("(polyline (pts (xy -2.54 0) (xy -2.54 0)) (stroke (width 0) (type default)) (fill (type none)))")
            elif gg in ("C", "CP"):
                gr.append("(polyline (pts (xy -0.508 1.778) (xy -0.508 -1.778)) (stroke (width 0.4) (type default)) (fill (type none)))")
                gr.append("(polyline (pts (xy 0.508 1.778) (xy 0.508 -1.778)) (stroke (width 0.4) (type default)) (fill (type none)))")
                gr.append("(polyline (pts (xy -2.54 0) (xy -0.508 0)) (stroke (width 0) (type default)) (fill (type none)))")
                gr.append("(polyline (pts (xy 0.508 0) (xy 2.54 0)) (stroke (width 0) (type default)) (fill (type none)))")
                if gg == "CP":
                    gr.append("(polyline (pts (xy -1.778 1.27) (xy -1.778 2.286)) (stroke (width 0.2) (type default)) (fill (type none)))")
                    gr.append("(polyline (pts (xy -2.286 1.778) (xy -1.27 1.778)) (stroke (width 0.2) (type default)) (fill (type none)))")
            elif gg == "D":
                gr.append("(polyline (pts (xy -1.27 1.27) (xy -1.27 -1.27)) (stroke (width 0.254) (type default)) (fill (type none)))")
                gr.append("(polyline (pts (xy 1.27 1.27) (xy 1.27 -1.27) (xy -1.27 0) (xy 1.27 1.27)) (stroke (width 0.254) (type default)) (fill (type none)))")
                gr.append("(polyline (pts (xy -2.54 0) (xy 2.54 0)) (stroke (width 0) (type default)) (fill (type none)))")
            elif gg == "Y":
                gr.append("(rectangle (start -1.016 1.778) (end 1.016 -1.778) (stroke (width 0.254) (type default)) (fill (type none)))")
                gr.append("(polyline (pts (xy -1.778 1.778) (xy -1.778 -1.778)) (stroke (width 0.3) (type default)) (fill (type none)))")
                gr.append("(polyline (pts (xy 1.778 1.778) (xy 1.778 -1.778)) (stroke (width 0.3) (type default)) (fill (type none)))")
        elif kind == "one":
            gr.append("(circle (center 0 0) (radius 1.016) (stroke (width 0.254) (type default)) (fill (type none)))")
        elif kind == "flag":
            gr.append("(polyline (pts (xy 0 0) (xy 0 1.27) (xy -1.016 1.905) (xy 0 2.54) (xy 1.016 1.905) (xy 0 1.27)) (stroke (width 0) (type default)) (fill (type none)))")
        base = sym.split(":")[-1]
        lines.append(f'  (symbol {q(base + f"_{ui}_1")}')
        for x in gr:
            lines.append("    " + x)
        for num, nm, typ, side in units_of(sym)[ui - 1]:
            x, y, sd = g["pins"][num]
            if kind == "flag":
                ang, ln = 90, 0
            else:
                ang = 0 if sd == "L" else 180
                ln = G if kind != "one" else 1.27
                if kind == "two":
                    ln = G
            nmshow = nm if nm != "~" else "~"
            lines.append(f"    (pin {typ} line (at {x} {y} {ang}) (length {ln}) (name {q(nmshow)} {font()}) (number {q(num)} {font()}))")
        lines.append("  )")
    lines.append(")")
    return "\n".join(lines)


# ------------------------------------------------------------------ nets
pins_of_net = defaultdict(list)
sheets_of_net = defaultdict(set)
for c in D.COMP:
    for num, net in c["pins"].items():
        if net:
            pins_of_net[net].append((c, num))
            sheets_of_net[net].add(c["sheet"])
GLOBAL = set(pins_of_net)  # every net drawn with a boxed label; names are unique across the project


def pintype(c, num):
    for p in units_of(c["sym"])[c["unit"] - 1]:
        if p[0] == num:
            return p[2]


# PWR_FLAGs: nets with a power_in pin and no power_out pin
flags = []
for net, lst in pins_of_net.items():
    types = {pintype(c, n) for c, n in lst}
    if "power_in" in types and "power_out" not in types:
        sheet = sorted(sheets_of_net[net], key=lambda x: [s for s, _ in D.SHEETS].index(x))[0]
        flags.append((net, sheet))
for i, (net, sheet) in enumerate(flags, 1):
    D.COMP.append(dict(ref=f"#FLG{i:02d}", sym="PWR_FLAG", value="PWR_FLAG", sheet=sheet, pins={"1": net}, unit=1, f={}))

# ------------------------------------------------------------------ placement
PAPERS = [("A3", 420, 297), ("A2", 594, 420), ("A1", 841, 594)]


def item_size(c):
    g = geo(c["sym"], c["unit"])
    labw = {"L": 0, "R": 0}
    for num, (x, y, sd) in g["pins"].items():
        net = c["pins"].get(num)
        if net:
            labw[sd] = max(labw[sd], len(net) * 1.0 + (4 if net in GLOBAL else 1))
    left = -g["x0"] + G + (G + labw["L"] if labw["L"] else 1.5)
    right = g["x1"] + G + (G + labw["R"] if labw["R"] else 1.5)
    if D.SYM[c["sym"]]["kind"] in ("two", "one", "flag"):
        left, right = -g["x0"] + G + G + labw["L"], g["x1"] + G + G + labw["R"]
    top = g["y1"] + 3.8
    bot = -g["y0"] + 3.8
    return left, right, top, bot


GROUPS = {
    "power_entry": {"J1": "Harness header (Harwin Gecko 26-way, host power and data)",
                    "F1": "Fuse, TVS and latching current limiter (bus side)",
                    "C4": "Input filter (TDK CCG10 Class A, damped ceramic) and isolated converter",
                    "R14": "Chassis and mounting holes"},
    "rails": {"U5": "SW1: CM5 5 V rail switch (and shared OVLO divider)", "U6": "SW2: head 5 V rail switch",
              "R17": "Rail shunts and current amplifiers",
              "U10": "Always-on 3.71 V (amplifiers, watchdog, enable pull-ups)",
              "U11": "Supervisor: holds SW1 off until 5 V is good",
              "U12": "Watchdog: opens SW1 when not serviced", "TP6": "Test points"},
    "cm5": {"M1": "Raspberry Pi Compute Module 5 (both connectors)", "C39": "CM5 3.3 V output"},
    "interfaces": {"U13": "CAN FD controller (SPI)", "U14": "CAN transceiver, protection and optional termination",
                   "U15": "RS-422 host link", "R43": "Receiver termination, fail-safe bias and 5 V to 3.3 V dividers",
                   "U16": "PPS receiver"},
    "housekeeping": {"U19": "Precision 4.096 V reference (ADC VA and thermistor bias)", "U17": "Housekeeping ADC",
                     "R58": "Rail voltage and current channels", "R62": "Thermistor channels",
                     "RT4": "Host thermistor (read by the host, separate from payload circuits)"},
    "maint_head": {"J2": "CM5 maintenance header and protection", "J3": "Flex link to the XIMEA head"},
}


def layout(sheet):
    comps = [c for c in D.COMP if c["sheet"] == sheet]
    grp = GROUPS.get(sheet, {})
    for pname, W, H in PAPERS:
        nnotes = sum(1 for c in comps if c["f"].get("Note"))
        WC = W * 0.63 if nnotes else W - 15
        x, y, rowh, place, heads = 20.0, 22.0, 0.0, {}, []
        flag_started = False
        for c in comps:
            l, r, t, b = item_size(c)
            w, h = l + r + 6, t + b + 2
            head = grp.get(c["ref"]) if c["unit"] == 1 else None
            if c["ref"].startswith("#") and not flag_started:
                head, flag_started = "Power flags for ERC", True
            if head:
                if place:
                    y += rowh + 4
                x, rowh = 20.0, 0.0
                heads.append((head, snap(y)))
                y += 5
            elif x + w > WC:
                x, y, rowh = 20.0, y + rowh, 0.0
            place[id(c)] = (snap(x + l), snap(y + t))
            x += w
            rowh = max(rowh, h)
        nlines = sum(math.ceil(len(c["f"]["Note"]) / int(W * 0.29 / 0.95)) for c in comps if c["f"].get("Note"))
        if y + rowh < H - 40 and (nlines + 1) * 2.3 < H - 70:
            return pname, W, H, place, y + rowh, heads
    return pname, W, H, place, y + rowh, heads


# ------------------------------------------------------------------ write
ROOT = U("root")
SHEET_UUID = {s: U("sheet", s) for s, _ in D.SHEETS}


def sym_instance(c, X, Y, sheet):
    g = geo(c["sym"], c["unit"])
    kind = D.SYM[c["sym"]]["kind"]
    f = c["f"]
    dnp = "yes" if f.get("DNP") else "no"
    inbom = "no" if kind == "flag" else "yes"
    out = [f'(symbol (lib_id {q(LIB + ":" + c["sym"])}) (at {X} {Y} 0) (unit {c["unit"]})',
           f"  (in_bom {inbom}) (on_board yes) (dnp {dnp})",
           f'  (uuid {q(U("sym", c["ref"], c["unit"]))})']
    ry = snap(Y - g["y1"] - 1.27)
    vy = snap(Y - g["y0"] + 1.27)
    hid = " hide" if kind == "flag" else ""
    out.append(f'  (property "Reference" {q(c["ref"])} (at {X} {ry} 0) (effects (font (size 1.27 1.27)){hid}))')
    out.append(f'  (property "Value" {q(c["value"])} (at {X} {vy} 0) (effects (font (size 1.27 1.27)){hid}))')
    fp = f.get("Footprint", "")
    out.append(f'  (property "Footprint" {q(fp)} (at {X} {Y} 0) (effects (font (size 1.27 1.27)) hide))')
    out.append(f'  (property "Datasheet" {q(D.SYM[c["sym"]].get("ds", ""))} (at {X} {Y} 0) (effects (font (size 1.27 1.27)) hide))')
    for k in ("MPN", "MPN_ALT", "Mate", "Note"):
        if f.get(k):
            out.append(f'  (property {q(k)} {q(f[k])} (at {X} {Y} 0) (effects (font (size 1.27 1.27)) hide))')
    for num in g["pins"]:
        out.append(f'  (pin {q(num)} (uuid {q(U("pin", c["ref"], c["unit"], num))}))')
    out.append(f'  (instances (project {q(PROJ)} (path {q("/" + ROOT + "/" + SHEET_UUID[sheet])} (reference {q(c["ref"])}) (unit {c["unit"]}))))')
    out.append(")")
    return "\n".join(out)


def header(paper, title, sheetfile_uuid, page_title):
    return [f"(kicad_sch (version 20230121) (generator eeschema)", f"  (uuid {q(sheetfile_uuid)})",
            f'  (paper "{paper}")',
            f"  (title_block (title {q(page_title)}) (date {q(DATE)}) (rev {q(REV)}) (company \"Carthage College, SLANT\")",
            f"    (comment 1 {q('SLANT carrier board, option A4 (Raspberry Pi CM5). Pin-accurate first pass.')})",
            f"    (comment 2 {q('Pin tables from vendor datasheets read 10 Oct 2026; see README for sources and TBC items.')}))"]


def libblock(syms):
    return ["  (lib_symbols"] + ["    " + l for s in sorted(syms) for l in lib_symbol(s).split("\n")] + ["  )"]


report = []
for page, (sheet, title) in enumerate(D.SHEETS, start=2):
    pname, W, H, place, ybottom, heads = layout(sheet)
    comps = [c for c in D.COMP if c["sheet"] == sheet]
    body = header(pname, title, U("file", sheet), title)
    body += libblock({c["sym"] for c in comps})
    items = []
    for c in comps:
        X, Y = place[id(c)]
        items.append(sym_instance(c, X, Y, sheet))
        g = geo(c["sym"], c["unit"])
        for num, (px, py, sd) in g["pins"].items():
            cx, cy = snap(X + px), snap(Y - py)
            net = c["pins"].get(num)
            if not net:
                items.append(f'(no_connect (at {cx} {cy}) (uuid {q(U("nc", c["ref"], c["unit"], num))}))')
                continue
            if c["sym"] == "PWR_FLAG":
                ex, ey = cx, snap(cy + G)
                ang, just = 270, "right"
            else:
                ex = snap(cx - G if sd == "L" else cx + G)
                ey = cy
                ang, just = (180, "right") if sd == "L" else (0, "left")
            items.append(f'(wire (pts (xy {cx} {cy}) (xy {ex} {ey})) (stroke (width 0) (type default)) (uuid {q(U("w", c["ref"], c["unit"], num))}))')
            lu = q(U("lab", c["ref"], c["unit"], num))
            if net in GLOBAL:
                items.append(f'(global_label {q(net)} (shape passive) (at {ex} {ey} {ang}) (fields_autoplaced) '
                             f'(effects (font (size 1.27 1.27)) (justify {just})) (uuid {lu}) '
                             f'(property "Intersheetrefs" "${{INTERSHEET_REFS}}" (at {ex} {ey} 0) (effects (font (size 1.27 1.27)) hide)))')
            else:
                items.append(f'(label {q(net)} (at {ex} {ey} {ang}) (fields_autoplaced) '
                             f'(effects (font (size 1.27 1.27)) (justify {just} bottom)) (uuid {lu}))')
    for i, (hd, hy) in enumerate(heads):
        items.append(f'(text {q(hd)} (at 20 {hy} 0) (effects (font (size 2 2) bold) (justify left top)) (uuid {q(U("head", sheet, i))}))')
    # notes block
    notes = [f"{c['ref']}: {c['f']['Note']}" for c in comps if c["f"].get("Note")]
    if notes:
        import textwrap
        wrapped = []
        for n_ in notes:
            wrapped += textwrap.wrap(n_, width=int(W * 0.29 / 0.95), subsequent_indent="    ")
        txt = "NOTES (value basis and items to confirm)\n" + "\n".join(wrapped)
        items.append(f'(text {q(txt)} (at {snap(W * 0.65)} 25 0) (effects (font (size 1.27 1.27)) (justify left top)) (uuid {q(U("notes", sheet))}))')
    body += ["  " + l for it in items for l in it.split("\n")]
    body.append(")")
    open(f"{OUT}/{sheet}.kicad_sch", "w").write("\n".join(body) + "\n")
    report.append((sheet, pname, len(comps), len(notes)))

# root sheet
root = header("A3", "SLANT carrier board", ROOT, "SLANT carrier board, option A4 (CM5): sheet index")
root.append("  (lib_symbols)")
for i, (sheet, title) in enumerate(D.SHEETS):
    x, y = 30 + (i % 3) * 125, 60 + (i // 3) * 70
    root.append(f"  (sheet (at {x} {y}) (size 100 40) (fields_autoplaced)")
    root.append("    (stroke (width 0.1524) (type solid)) (fill (color 0 0 0 0.0000))")
    root.append(f"    (uuid {q(SHEET_UUID[sheet])})")
    root.append(f'    (property "Sheetname" {q(title)} (at {x} {snap(y - 0.7)} 0) (effects (font (size 1.27 1.27)) (justify left bottom)))')
    root.append(f'    (property "Sheetfile" {q(sheet + ".kicad_sch")} (at {x} {snap(y + 40.6)} 0) (effects (font (size 1.27 1.27)) (justify left top)))')
    root.append(f"    (instances (project {q(PROJ)} (path {q('/' + ROOT)} (page {q(str(i + 2))}))))")
    root.append("  )")
dom = ("POWER DOMAINS\n"
       "BUS_IN / BUS_F / BUS_SW / BUS_FILT, PRI_RTN: spacecraft bus side of the CCG10 isolation barrier.\n"
       "5V_BUS: CCG10 output, always on while the payload is powered.\n"
       "3V7_A: always-on 3.71 V (shunt amplifiers, watchdog, enable pull-ups). VREF: 4.096 V reference (ADC VA, thermistor bias).\n"
       "5V_CM5 (SW1) and 5V_HEAD (SW2): switched rails. CM5_3V3: the CM5's own 3.3 V output, on only while the CM5 runs.\n"
       "Every part that drives a CM5 pin is powered from CM5_3V3 or 5V_RS422 (gated by CM5_3V3), so no CM5 pin is driven before its 5 V is up (CM5 datasheet, section 3).\n"
       "GND: payload ground (CCG10 secondary). CHASSIS: rods and housing; tied to GND only through the DNP R14/C19.\n"
       "Commercial parts are fitted where the space-grade variant is not buyable (MPN_ALT names it). Derating: NASA EEE-INST-002 (README).")
root.append(f'  (text {q(dom)} (at 30 210 0) (effects (font (size 1.27 1.27)) (justify left top)) (uuid {q(U("rootnotes"))}))')
root.append('  (sheet_instances (path "/" (page "1")))')
root.append(")")
open(f"{OUT}/{PROJ}.kicad_sch", "w").write("\n".join(root) + "\n")

# library, project, lib table
lib = ["(kicad_symbol_lib (version 20220914) (generator kicad_symbol_editor)"]
for s in sorted(D.SYM):
    lib += ["  " + l for l in lib_symbol(s, prefix=False).split("\n")]
lib.append(")")
open(f"{OUT}/{LIB}.kicad_sym", "w").write("\n".join(lib) + "\n")
open(f"{OUT}/sym-lib-table", "w").write(
    '(sym_lib_table\n  (lib (name "SLANT")(type "KiCad")(uri "${KIPRJMOD}/SLANT.kicad_sym")(options "")(descr "SLANT carrier board symbols, from vendor datasheets"))\n)\n')
open(f"{OUT}/{PROJ}.kicad_pro", "w").write('{\n  "meta": {\n    "filename": "%s.kicad_pro",\n    "version": 1\n  },\n  "schematic": {\n    "legacy_lib_dir": "",\n    "legacy_lib_list": []\n  },\n  "sheets": [\n    ["%s", ""]\n  ]\n}\n' % (PROJ, ROOT))
print("sheets:", report)
print("nets:", len(pins_of_net), "global:", len(GLOBAL), "flags:", [n for n, _ in flags])
