"""Adds the inner-layer planes and the isolation moat keep-out to out/slant_carrier.kicad_pcb (run after make_pcb.py).

In1 and In2 carry GND over the payload side and a PRI_RTN island over the host-side zone (HOSTZ in make_pcb.py). The
outlines carry the 2.5 mm moat themselves (plus 0.05 mm), so the gap does not depend on the fill engine reading the
custom rules. Near J1 the island is cut back 2.55 mm from the payload pins 6 and 19, which sit inside the moat. A rule
area over the moat (all copper layers, outside J1's courtyard) forbids tracks, vias and pours there.
Usage: python3 add_zones.py [--nofill]
"""
import json, sys
import pcbnew
from shapely.geometry import Polygon, box as sbox
from shapely.ops import unary_union

MM = pcbnew.FromMM
PCB = "out/slant_carrier.kicad_pcb"
OUTER = [(46.22, -47.96), (46.22, 47.94), (-43.95, 47.94), (-43.95, 25.0), (-44.0, 25.0), (-44.0, 24.5), (-34.5, 24.5),
         (-34.5, 18.5), (-43.95, 18.5), (-43.95, -47.96)]
BOARD_POLY = Polygon(OUTER)
HOSTZ = Polygon([(-43.95, -47.96), (-11.0, -47.96), (-11.0, -5.0), (-26.0, -5.0), (-26.0, 8.9), (-43.95, 8.9)])
BARRIER = 2.5
HOSTNET = lambda n: bool(n) and (n.startswith(("BUS_", "LIM_", "HOST_THERM")) or n in ("FILT_DAMP", "PRI_RTN"))

board = pcbnew.LoadBoard(PCB)


def W(v):
    return (pcbnew.ToMM(v.x) - 100, 100 - pcbnew.ToMM(v.y))


def padshape(pd):
    bb = pd.GetBoundingBox()
    x0, y0 = W(pcbnew.VECTOR2I(bb.GetX(), bb.GetY() + bb.GetHeight()))
    x1, y1 = W(pcbnew.VECTOR2I(bb.GetX() + bb.GetWidth(), bb.GetY()))
    return sbox(x0, y0, x1, y1)


def polys(g):
    return [q for q in (g.geoms if hasattr(g, "geoms") else [g]) if q.area > 0.5]


J1 = board.FindFootprintByReference("J1")
j1_pay = unary_union([padshape(pd) for pd in J1.Pads() if pd.GetNetname() and not HOSTNET(pd.GetNetname())])
ISLAND = HOSTZ.difference(j1_pay.buffer(BARRIER + 0.05, join_style=2)).intersection(BOARD_POLY)
GNDPL = BOARD_POLY.difference(HOSTZ.buffer(BARRIER + 0.05, join_style=2))
J1BOX = sbox(-32.78, 1.62, -27.32, 22.38)    # J1's courtyard (bottom face); its pins 5/18 and 6/19 sit in the moat
KEEP = HOSTZ.buffer(BARRIER, join_style=2).difference(HOSTZ).intersection(BOARD_POLY).difference(J1BOX)
# Chassis pads (mounting holes H1-H4, J1 pin 26): the planes keep 0.85 mm from them (chassis rule 0.8 mm), cut into the
# outlines because the KiCad 7 fill applies the zone's own 0.3 mm clearance there.
CHASSIS_CUT = unary_union([padshape(pd).buffer(0.85) for fp in board.GetFootprints() for pd in fp.Pads()
                           if pd.GetNetname() == "CHASSIS"])
ISLAND = ISLAND.difference(CHASSIS_CUT)
GNDPL = GNDPL.difference(CHASSIS_CUT)
NET = {n: board.FindNet(n) for n in ("GND", "PRI_RTN")}


def outline(z, poly):
    ol = z.Outline()
    k = ol.NewOutline()
    for x, y in list(poly.exterior.coords)[:-1]:
        ol.Append(MM(100 + x), MM(100 - y), k)
    for ring in poly.interiors:
        h = ol.NewHole(k)
        for x, y in list(ring.coords)[:-1]:
            ol.Append(MM(100 + x), MM(100 - y), k, h)


def plane(poly, layer, net, prio):
    z = pcbnew.ZONE(board)
    z.SetLayer(layer)
    outline(z, poly)
    z.SetNet(NET[net])
    z.SetPadConnection(pcbnew.ZONE_CONNECTION_THERMAL)
    z.SetLocalClearance(MM(0.3)); z.SetMinThickness(MM(0.25)); z.SetAssignedPriority(prio)
    z.SetThermalReliefGap(MM(0.3)); z.SetThermalReliefSpokeWidth(MM(0.4))
    z.SetZoneName(f"{net} plane")
    board.Add(z)


def keepout(poly):
    z = pcbnew.ZONE(board)
    z.SetIsRuleArea(True)
    ls = pcbnew.LSET(); [ls.AddLayer(l) for l in (pcbnew.F_Cu, pcbnew.In1_Cu, pcbnew.In2_Cu, pcbnew.B_Cu)]
    z.SetLayerSet(ls)
    outline(z, poly)
    z.SetDoNotAllowTracks(True); z.SetDoNotAllowVias(True); z.SetDoNotAllowCopperPour(True)
    z.SetDoNotAllowPads(False); z.SetDoNotAllowFootprints(False)
    z.SetZoneName("Isolation moat 2.5 mm")
    board.Add(z)


for lay in (pcbnew.In1_Cu, pcbnew.In2_Cu):
    for q in polys(GNDPL):
        plane(q, lay, "GND", 0)
    for q in polys(ISLAND):
        plane(q, lay, "PRI_RTN", 1)
for q in polys(KEEP):
    keepout(q)
if "--nofill" not in sys.argv:
    pcbnew.ZONE_FILLER(board).Fill(board.Zones())
board.BuildConnectivity()
pcbnew.SaveBoard(PCB, board)
info = dict(gnd_mm2=round(GNDPL.area, 1), pri_rtn_mm2=round(ISLAND.area, 1), moat_keepout_mm2=round(KEEP.area, 1),
            n_zones=board.GetAreaCount())
L = json.load(open("out/placement.json")); L["zones"] = info; json.dump(L, open("out/placement.json", "w"), indent=1)
print(info)
