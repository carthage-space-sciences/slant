"""Builds the carrier board's KiCad PCB (steps 1-3: footprints, outline and mounting holes, placement).
KC, 10 Oct 2026, 17:37: footprints from the best available vendor data, flagged TBC; small passives placed beside the
part each one serves; 4 copper layers. Routing, stackup and net classes are later steps.

Frames: the assembly frame of the 3D model (x, y in mm; +z up, board top face up) maps to KiCad as X = 100 + x,
Y = 100 - y. Bottom-face parts are flipped. Positions of the large parts come from the option A4-3 3D model, except the
input-filter group, which moves to the converter's input pins (README).
Inputs : design.py, out/*.kicad_sch (symbol UUIDs), SLANT.pretty, KiCad 7 libraries, ../outA4_3/parts.json
Output : out/slant_carrier.kicad_pcb, out/placement.json
"""
import json, math, re, sys
import pcbnew
from shapely.geometry import Polygon, box as sbox, Point
from shapely.ops import unary_union
import design as D

LIBROOT = "/usr/share/kicad/footprints"
OUT = "out"
MM = pcbnew.FromMM


def K(x, y):
    return pcbnew.VECTOR2I(MM(100 + x), MM(100 - y))


def W(v):  # KiCad point -> assembly frame
    return (pcbnew.ToMM(v.x) - 100, 100 - pcbnew.ToMM(v.y))


# ------------------------------------------------------------------ schematic UUIDs, for the footprint-to-symbol links
SHEETS = {}
root = open(f"{OUT}/slant_carrier.kicad_sch").read()
for m in re.finditer(r'\(sheet \(at [^\n]*\n[^\n]*\n\s*\(uuid "([^"]+)"\)\n\s*\(property "Sheetname"[^\n]*\n\s*\(property "Sheetfile" "([^"]+)"', root):
    SHEETS[m.group(2)] = m.group(1)
SYMPATH = {}
for fn, su in SHEETS.items():
    t = open(f"{OUT}/{fn}").read()
    for m in re.finditer(r'\(symbol \(lib_id "[^"]+"\) \(at [^)]*\) \(unit (\d+)\)\n[^\n]*\n\s*\(uuid "([^"]+)"\)(.*?)\(reference "([^"]+)"\)', t, re.S):
        unit, uid, ref = int(m.group(1)), m.group(2), m.group(4)
        if ref.startswith("#"):
            continue
        if unit == 1 or ref not in SYMPATH:
            SYMPATH[ref] = f"/{su}/{uid}"
assert len(SYMPATH) == len({c["ref"] for c in D.COMP}), (len(SYMPATH), len({c["ref"] for c in D.COMP}))

# ------------------------------------------------------------------ parts and nets from the design data
PARTS = {}
for c in D.COMP:
    p = PARTS.setdefault(c["ref"], dict(ref=c["ref"], value=c["value"], sym=c["sym"], pins={}, f=dict(c["f"]), sheet=c["sheet"]))
    p["pins"].update({k: v for k, v in c["pins"].items()})

board = pcbnew.BOARD()
board.SetCopperLayerCount(4)
ds = board.GetDesignSettings()
ds.SetBoardThickness(MM(2.4))
# KC, 10 Oct 20:25: IPC-6012 Class 3, polyimide, 4 layers. In1 and In2 are ground planes (with the PRI_RTN island under
# the bus-side zone); KiCad's "power" layer type marks them as plane layers.
board.SetLayerType(pcbnew.In1_Cu, pcbnew.LT_POWER)
board.SetLayerType(pcbnew.In2_Cu, pcbnew.LT_POWER)
NETS = {}
for p in PARTS.values():
    for n in p["pins"].values():
        if n and n not in NETS:
            ni = pcbnew.NETINFO_ITEM(board, n); board.Add(ni); NETS[n] = ni

# ------------------------------------------------------------------ outline (the A4-3 board solid's section)
OUTER = [(46.22, -47.96), (46.22, 47.94), (-43.95, 47.94), (-43.95, 25.0), (-44.0, 25.0), (-44.0, 24.5), (-34.5, 24.5),
         (-34.5, 18.5), (-43.95, 18.5), (-43.95, -47.96)]
for i in range(len(OUTER)):
    a, b = OUTER[i], OUTER[(i + 1) % len(OUTER)]
    s = pcbnew.PCB_SHAPE(board); s.SetShape(pcbnew.SHAPE_T_SEGMENT); s.SetStart(K(*a)); s.SetEnd(K(*b))
    s.SetLayer(pcbnew.Edge_Cuts); s.SetWidth(MM(0.1)); board.Add(s)
BOARD_POLY = Polygon(OUTER)


def load(fpid):
    lib, name = fpid.split(":")
    path = "SLANT.pretty" if lib == "SLANT" else f"{LIBROOT}/{lib}.pretty"
    fp = pcbnew.FootprintLoad(path, name)
    assert fp is not None, fpid
    fp.SetFPID(pcbnew.LIB_ID(lib, name))
    return fp


FPS = {}


def make(ref):
    p = PARTS[ref]
    fp = load(p["f"]["Footprint"])
    fp.SetReference(ref); fp.SetValue(p["value"])
    fp.SetPath(pcbnew.KIID_PATH(SYMPATH[ref]))
    for k in ("MPN", "MPN_ALT"):
        if p["f"].get(k):
            try:
                fp.SetProperty(k, p["f"][k])
            except Exception:
                pass
    nums = {pd.GetNumber() for pd in fp.Pads() if pd.GetNumber()}
    missing = set(p["pins"]) - nums
    assert not missing, (ref, sorted(missing))
    for pd in fp.Pads():
        n = p["pins"].get(pd.GetNumber())
        if n:
            pd.SetNet(NETS[n])
    fp.Reference().SetTextSize(pcbnew.VECTOR2I(MM(0.8), MM(0.8))); fp.Reference().SetTextThickness(MM(0.12))
    board.Add(fp); FPS[ref] = fp
    return fp


def put(ref, x, y, rot=0.0, side="top"):
    """Place (or move) a footprint. Footprints are never removed from the board: KiCad 7's SWIG wrapper corrupts its
    type table after BOARD.Remove, so a search moves one footprint around instead."""
    fp = FPS[ref] if ref in FPS else make(ref)
    on_bottom = fp.GetLayer() == pcbnew.B_Cu
    fp.SetPosition(K(x, y))
    if (side == "bottom") != on_bottom:
        fp.Flip(K(x, y), True)
    fp.SetOrientationDegrees(rot)
    return fp


def padpos(fp):
    return {pd.GetNumber(): W(pd.GetPosition()) for pd in fp.Pads() if pd.GetNumber()}


def fit(ref, x, y, side, targets):
    """Choose the rotation that puts the named pads on their target positions; report the worst error.
    (On the bottom face a flip about the other axis equals this flip turned 180 degrees, so four rotations cover both.)"""
    best = None
    for rot in (0, 90, 180, 270):
        fp = put(ref, x, y, rot, side)
        pp = padpos(fp)
        err = max(math.hypot(pp[n][0] - tx, pp[n][1] - ty) for n, (tx, ty) in targets.items())
        if best is None or err < best[0]:
            best = (err, rot)
    put(ref, x, y, best[1], side)
    return best


LOG = {"fit": {}}

# ------------------------------------------------------------------ the CM5 (bottom face) and the converter (body below)
TX, TY = 4.5, -27.5          # 3D model: world (x, y) = (y_module + 4.5, x_module - 27.5)


def cm5_world(n):
    top = n <= 100
    k = n - 1 if top else n - 101
    xs = 34.8 - 0.4 * (k // 2)
    ys = (37.0 if top else 3.0) + (1.32 if n % 2 else -1.32)
    return (ys + TX, xs + TY)


LOG["fit"]["M1"] = fit("M1", 24.5, 0.0, "bottom", {str(n): cm5_world(n) for n in (1, 2, 99, 100, 101, 102, 199, 200)})
# The converter's pin positions in the 3D model (TDK's STEP), turned 180 degrees about the body centre (-9.5, -12.2)
# (KC, 10 Oct 2026): input pins 1-3 now face J1 (-x), output pins 4-6 face the rail switches and the CM5 (+x).
CONV_HOLES = {"1": (-18.1, -16.01), "2": (-18.1, -10.93), "3": (-18.1, -8.39), "6": (-0.9, -14.49), "5": (-0.9, -11.95),
              "4": (-0.9, -9.41)}
LOG["fit"]["U3"] = fit("U3", -9.5, -12.2, "bottom", CONV_HOLES)
J1C = (-30.05, 12.0)   # pins 1-3 and 14-16 (bus and return) at the y = 4.5 end, where the power bundle enters
LOG["fit"]["J1"] = fit("J1", *J1C, "bottom", {"1": (-29.425, 4.5), "13": (-29.425, 19.5)})   # pin 1 row on the +x side (bottom-face mirror)
for k, v in LOG["fit"].items():
    print(f"fit {k}: worst pad error {v[0]:.4f} mm at rotation {v[1]}")

# ------------------------------------------------------------------ the other placed parts (assembly frame, mm)
# (ref, x, y, KiCad rotation, side). Rotation 90 turns a footprint whose pin rows run along KiCad y so they run along x,
# as drawn in the 3D model.
PLACE = [
    # ---- host side (bus power and return), lower left. Chain: J1 pins 1-3 -> F1 -> D5, C2 -> U1 -> (via) L1 -> C12, C65
    # -> converter input pins at x = -18.1 (bottom face). KC, 10 Oct 2026: one host-side zone; isolation pass (README).
    ("F1", -38.5, 4.5, 0, "top"), ("D5", -38.5, -1.5, 0, "top"), ("U1", -37.5, -15.5, 90, "top"),
    ("C12", -22.5, -10.0, 90, "bottom"), ("C65", -22.5, -15.0, 90, "bottom"),
    ("L1", -28.0, -12.5, 0, "bottom"), ("C4", -28.0, -18.0, 0, "bottom"), ("R73", -22.5, -20.0, 90, "bottom"),
    ("C11", -28.0, -21.5, 0, "bottom"), ("C60", -28.0, -25.0, 0, "bottom"), ("C61", -28.0, -28.5, 0, "bottom"),
    ("C62", -22.5, -24.5, 0, "bottom"), ("C63", -22.5, -28.0, 0, "bottom"), ("C64", -22.5, -31.5, 0, "bottom"),
    # ---- barrier capacitors: top face, across the moat over the converter body (pad 1 host side, pad 2 payload side)
    ("C13", -9.75, -9.0, 0, "top"), ("C14", -9.75, -16.0, 0, "top"),
    # ---- payload side, near the converter output and the rail switches
    ("U5", -9.0, 0.0, 0, "top"), ("U6", -9.0, 9.5, 0, "top"),
    ("C21", -12.5, 0.0, 90, "top"), ("C22", -5.5, 0.0, 90, "top"), ("C24", -12.5, 9.5, 90, "top"), ("C25", -5.5, 9.5, 90, "top"),
    ("R17", -1.2, 0.0, 0, "top"), ("R18", -1.2, 9.5, 0, "top"), ("U7", 3.6, 0.0, 90, "top"), ("U8", 3.6, 9.5, 90, "top"),
    ("C26", 8.5, -2.5, 0, "top"), ("C69", 8.5, 1.4, 0, "top"), ("C27", 8.5, 9.5, 0, "top"),
    ("C15", -21.0, 2.5, 0, "top"), ("C16", -21.0, 6.5, 0, "top"), ("C66", -16.3, 6.5, 0, "top"),
    ("C39", 12.0, 20.0, 0, "top"), ("U19", 24.0, -16.5, 90, "top"), ("C48", 16.5, -22.0, 0, "top"),
    # supervisor (U11), watchdog (U12) and 3.71 V LDO (U10): below the rail switches and shunt amplifiers they serve,
    # in the free top-face area between the moat and the CM5's courtyard. The first A4-8 position (x -2 to 5,
    # y 19 to 30) sat in the corridor that carries J1's pairs and J2's signals to the transceivers and the CM5, and
    # the routing there left 3V7_A, U10_FB, U12_WDEN and SW1_EN open (A4-8, 11 Oct 2026)
    ("U11", -4.0, -18.0, 90, "top"), ("U12", 1.5, -20.0, 90, "top"), ("U10", -2.0, -30.0, 0, "top"),
    ("U17", 16.5, -16.5, 90, "top"), ("D2", -11.5, 31.0, 90, "top"),
    ("D3", -11.5, 33.5, 90, "top"), ("J2", -22.95, 32.54, 0, "top"), ("J3", 22.3, 0.0, 90, "top"),

    # ---- CAN and RS-422 interfaces: top face over the CM5 (KC, 10 Oct 2026). D1 (CAN ESD) sits just right of J1's top
    # end, where CANH (J1's +x row) and CANL (looping around the connector's top end from the -x row) run together;
    # left of J1 it forced CANH around the connector end and closed the corridor the other N lines use (routing, 22:30).
    ("D1", -22.5, 24.0, 0, "top"),
    # ICs 3-5 mm apart, edge to edge, for routing channels (layout skill; A4-8)
    ("U13", 17.0, 41.5, 90, "top"), ("Y1", 25.0, 42.0, 0, "top"), ("U14", 33.0, 41.5, 90, "top"),
    ("U15", 17.0, 29.0, 90, "top"), ("U16", 29.0, 29.0, 90, "top"),
    ("U18", 39.5, 29.0, 0, "top"), ("D4", 36.0, 24.5, 0, "top"), ("C59", 39.5, 33.5, 0, "top"),
    # ---- chassis tie (R14 0 ohm, C19 10 nF 2 kV; not fitted, the host's grounding plan decides): bottom face beside
    # J1 pin 26 (CHASSIS, at (-30.675, 19.5)), where the harness and its common-mode current enter (KC, 10 Oct 21:11)
    ("C19", -35.3, 14.8, 90, "bottom"), ("R14", -39.0, 14.8, 90, "bottom"),
    # ---- thermistors: RT1 on the board; RT2-RT4 are remote and land their leads on turrets here. RT4 (host) moves into
    # the host-side zone beside the bus input.
    ("RT1", 30.0, 16.0, 0, "top"), ("RT2", 30.0, -36.0, 0, "top"), ("RT3", 0.0, -36.0, 0, "top"), ("RT4", -38.5, -8.5, 0, "top"),
]
for ref, x, y, rot, side in PLACE:
    put(ref, x, y, rot, side)
RODS = [(-36.32, -42.88), (37.33, -42.88), (-38.87, 42.86), (41.15, 42.86)]   # PC/104 rod holes in the board solid
for i, (x, y) in enumerate(RODS):
    put(f"H{i + 1}", x, y, 0, "top")

# ------------------------------------------------------------------ occupancy per face
CLR = 0.5        # between courtyards: about 1.0 mm body to body for 0805 parts (layout skill: 1.0 mm minimum; A4-8)
EDGE = 0.5       # copper and courtyard to board edge
AREA = BOARD_POLY.buffer(-EDGE)


def courtyard(fp, layer):
    """Bounding rectangle of the footprint's courtyard graphics on the given layer (assembly frame)."""
    xs, ys = [], []
    for it in fp.GraphicalItems():
        if it.GetLayer() == layer:
            bb = it.GetBoundingBox()
            for X, Y in ((bb.GetX(), bb.GetY()), (bb.GetX() + bb.GetWidth(), bb.GetY() + bb.GetHeight())):
                x, y = W(pcbnew.VECTOR2I(X, Y)); xs.append(x); ys.append(y)
    return sbox(min(xs), min(ys), max(xs), max(ys)) if xs else None


def occ_of(fp):
    """Shapes the footprint occupies on the top and bottom faces (assembly frame)."""
    side = "bottom" if fp.GetLayer() == pcbnew.B_Cu else "top"
    cy = courtyard(fp, pcbnew.B_CrtYd if side == "bottom" else pcbnew.F_CrtYd)
    if cy is None or cy.is_empty:
        bb = fp.GetBoundingBox()
        x0, y0 = W(pcbnew.VECTOR2I(bb.GetLeft(), bb.GetBottom())); x1, y1 = W(pcbnew.VECTOR2I(bb.GetRight(), bb.GetTop()))
        cy = sbox(x0, y0, x1, y1)
    occ = {"top": [], "bottom": []}
    occ[side].append(cy)
    other = "top" if side == "bottom" else "bottom"
    for pd in fp.Pads():
        if pd.GetAttribute() in (pcbnew.PAD_ATTRIB_PTH, pcbnew.PAD_ATTRIB_NPTH):
            bb = pd.GetBoundingBox()
            x0, y0 = W(pcbnew.VECTOR2I(bb.GetX(), bb.GetY() + bb.GetHeight()))
            x1, y1 = W(pcbnew.VECTOR2I(bb.GetX() + bb.GetWidth(), bb.GetY()))
            occ[other].append(sbox(x0, y0, x1, y1).buffer(0.2))
    return occ


OCC = {"top": [], "bottom": []}
for fp in FPS.values():
    o = occ_of(fp)
    for s in o:
        OCC[s] += o[s]
# The CM5 module below the board: bottom-face parts stay off its whole outline (connectors, standoffs, 2.9 mm gap).
OCC["bottom"].append(sbox(4.5, -27.5, 44.5, 27.5))
# The converter body below the board, J1's cable housing and the harness bundles (3D model) are inside the courtyards
# of U3 and J1. The maintenance cable crosses the top face from J2 to the notch: keep the top face clear under it.
OCC["top"].append(Polygon([(-34.5, 18.5), (-34.5, 24.5), (-28.0, 31.0), (-24.0, 31.0), (-24.0, 27.0), (-30.0, 18.5)]))

# ------------------------------------------------------------------ isolation domains (KC, 10 Oct 2026: 500 Vdc test)
# HOSTZ is where host-side copper may go (bus power, its return, the limiter and the host thermistor). Payload copper
# stays at least BARRIER = 2.5 mm from it on every layer (IPC-2221B B2, 301-500 V); the band between is the moat.
# The moat runs between J1's pins 4/17 and 6/19, down at x = -26, and across the converter body between its input pins
# (x = -18.1) and output pins (x = -0.9).
HOSTZ = Polygon([(-43.95, -47.96), (-11.0, -47.96), (-11.0, -5.0), (-26.0, -5.0), (-26.0, 8.9), (-43.95, 8.9)])
BARRIER = 2.5
MOAT = HOSTZ.buffer(BARRIER, join_style=2)
HOSTNET = lambda n: bool(n) and (n.startswith(("BUS_", "LIM_", "HOST_THERM")) or n in ("FILT_DAMP", "PRI_RTN"))


def domain(ref):
    nets = [n for n in PARTS[ref]["pins"].values() if n and n != "CHASSIS"]
    if not nets:
        return "cross"      # chassis only (mounting holes): the 0.8 mm chassis rule applies, checked by DRC
    h = any(HOSTNET(n) for n in nets); o = any(not HOSTNET(n) for n in nets)
    return "cross" if h and o else ("host" if h else "payload")


def domain_ok(ref, shapes):
    d = domain(ref)
    if d == "host":
        return all(HOSTZ.contains(q) for q in shapes)
    if d == "payload":
        return not any(q.intersects(MOAT) for q in shapes)
    return True

# ------------------------------------------------------------------ the parts not drawn in 3D: beside the part they serve
placed = set(FPS)
rest = [r for r in PARTS if r not in placed]
anchors_ok = {r for r in placed if not r.startswith(("H", "RT"))}
# The CM5 and the two cable connectors share a net with almost every part; they anchor a part only when its note names them.
SCORE_SKIP = {"M1", "J1", "J2", "J3"}
pin_count = {}
for p in PARTS.values():
    for n in p["pins"].values():
        if n:
            pin_count[n] = pin_count.get(n, 0) + 1


ANCHORS = {r for r in anchors_ok if re.match(r"(U|D|Y|J|F|M)\d", r)} | {"L1"}
GROUND = {"GND", "PRI_RTN", "CHASSIS"}


# Decoupling capacitors on shared rails: the part each one bypasses (schematic notes and sheet grouping).
ANCHOR_OVERRIDE = {"C37": "U11", "C38": "U12", "C40": "U13", "C43": "U14", "C44": "U14", "C46": "U15", "C47": "U16",
                   "C49": "U17", "C50": "U17", "C72": "U17", "C70": "U19", "C71": "U19", "R69": "J2", "R68": "D3",
                   "R57": "U17", "R33": "U13", "R32": "U13"}


def anchor_for(ref, depth=0, seen=None):
    if ref in ANCHOR_OVERRIDE:
        return ANCHOR_OVERRIDE[ref], "decoupling or pull-up for this part (assigned)"
    """The IC, diode or connector a small part serves: named in its note, else the anchor sharing its least-common
    non-ground nets, else (through another small part on the same signal net) that part's anchor."""
    seen = (seen or set()) | {ref}
    p = PARTS[ref]
    note = p["f"].get("Note", "")
    for m in re.findall(r"\b(U\d+|J\d+|M1|L1|D\d+)\b", note):
        if m in ANCHORS:
            return m, "named in the part's note"
    nets = [v for v in set(p["pins"].values()) if v and v not in GROUND]
    score = {}
    for n in nets:
        for q in ANCHORS - SCORE_SKIP:
            if n in PARTS[q]["pins"].values():
                score[q] = score.get(q, 0) + 1.0 / pin_count[n]
    if score:
        q = max(sorted(score), key=lambda k: score[k])
        return q, f"shares a net (score {score[q]:.2f})"
    if depth < 2:
        for n in sorted(nets, key=lambda n: pin_count[n]):
            for r2 in sorted(rest):
                if r2 not in seen and n in PARTS[r2]["pins"].values():
                    q, why = anchor_for(r2, depth + 1, seen)
                    if q:
                        return q, f"through {r2} ({why})"
    for q in ("M1", "J1", "J3", "J2"):
        if any(n in PARTS[q]["pins"].values() for n in nets):
            return q, "connector net only"
    return None, "no shared net"


def _prio(r):
    """Placement order within an anchor's group (layout skill): decoupling capacitors first, then parts on a net of the
    anchor's own pins, then parts reached through another part, test points last (A4-8)."""
    anc, why = anchor_for(r)
    nets = set(PARTS[r]["pins"].values())
    if r.startswith("TP"):
        return 3
    if r.startswith("C") and nets & GROUND:
        return 0
    return 2 if why.startswith("through") else 1


ORDER = sorted(rest, key=lambda r: (anchor_for(r)[0] or "zz", _prio(r), r))
LOG["passives"] = {}
for ref in ORDER:
    anc, why = anchor_for(ref)
    if anc is None:
        anc = "U3"
    afp = FPS[anc]
    side = "bottom" if afp.GetLayer() == pcbnew.B_Cu else "top"
    if anc in ("J1", "U3", "M1"):     # through-hole or bottom-mounted anchors: their small parts go on the top face
        side = "top"
    ax, ay = W(afp.GetPosition())
    # start the search at the anchor's pins that share a signal or supply net with this part (a decoupling capacitor
    # beside its supply pin, a divider beside its pin), so the part lands within a few mm of that pin (A4-8)
    mynets = {n for n in PARTS[ref]["pins"].values() if n and n not in GROUND}
    pp = [W(pd.GetPosition()) for pd in afp.Pads() if pd.GetNetname() in mynets]
    if pp and anc not in ("J1", "M1", "U3"):
        ax = sum(p[0] for p in pp) / len(pp); ay = sum(p[1] for p in pp) / len(pp)
    done = False
    for rad in [i * 0.5 for i in range(0, 70)]:
        nang = max(1, int(2 * math.pi * rad / 0.6))
        for ia in range(nang):
            a = 2 * math.pi * ia / nang
            x, y = round(ax + rad * math.cos(a), 2), round(ay + rad * math.sin(a), 2)
            for rot in (0, 90):
                fp = put(ref, x, y, rot, side)
                o = occ_of(fp)
                ok = True
                for s in ("top", "bottom"):
                    for shp in o[s]:
                        if not AREA.contains(shp) or any(shp.buffer(CLR).intersects(q) for q in OCC[s]):
                            ok = False; break
                    if ok and not domain_ok(ref, o["top"] + o["bottom"]):
                        ok = False
                    if not ok:
                        break
                if ok:
                    for s in o:
                        OCC[s] += o[s]
                    LOG["passives"][ref] = dict(anchor=anc, why=why, x=x, y=y, rot=rot, side=side, dist=round(rad, 2))
                    done = True; break
            if done:
                break
        if done:
            break
    if not done:
        raise SystemExit(f"no place for {ref} near {anc}")

# ------------------------------------------------------------------ checks and output
assert set(FPS) == set(PARTS), set(PARTS) - set(FPS)
over = []
allfp = list(FPS.values())
for i, a in enumerate(allfp):
    oa = occ_of(a)
    for b in allfp[i + 1:]:
        ob = occ_of(b)
        for s in ("top", "bottom"):
            if any(x.intersects(y) and x.intersection(y).area > 0.01 for x in oa[s] for y in ob[s]):
                over.append((a.GetReference(), b.GetReference(), s))
LOG["overlaps"] = over
outside = [fp.GetReference() for fp in allfp if any(not BOARD_POLY.contains(s) for s in sum(occ_of(fp).values(), []))]
LOG["outside_board"] = outside


def padshape(pd):
    bb = pd.GetBoundingBox()
    x0, y0 = W(pcbnew.VECTOR2I(bb.GetX(), bb.GetY() + bb.GetHeight()))
    x1, y1 = W(pcbnew.VECTOR2I(bb.GetX() + bb.GetWidth(), bb.GetY()))
    return sbox(x0, y0, x1, y1)


# Barrier check on pad bounding boxes, all layers: host pads against payload pads (J1's own pins excepted: 1.5 mm rule).
hostp, payp = [], []
for r, fp in FPS.items():
    for pd in fp.Pads():
        n = pd.GetNetname()
        if not n or n == "CHASSIS":
            continue
        (hostp if HOSTNET(n) else payp).append((r, pd.GetNumber(), padshape(pd)))
viol = []
for r1, n1, a in hostp:
    for r2, n2, b in payp:
        d = a.distance(b)
        lim = 1.5 if (r1 == r2 == "J1") else BARRIER
        if d < lim:
            viol.append((r1, n1, r2, n2, round(d, 2)))
LOG["barrier_pad_check"] = viol
LOG["domain_misplaced"] = [r for r, fp in FPS.items() if domain(r) != "cross" and not domain_ok(r, sum(occ_of(fp).values(), []))]
LOG["placed"] = {r: dict(x=W(fp.GetPosition())[0], y=W(fp.GetPosition())[1], rot=fp.GetOrientationDegrees(),
                         side="bottom" if fp.GetLayer() == pcbnew.B_Cu else "top", footprint=PARTS[r]["f"]["Footprint"])
                 for r, fp in FPS.items()}

board.BuildConnectivity()
pcbnew.SaveBoard(f"{OUT}/slant_carrier.kicad_pcb", board)
# Stackup (written into the setup section; pcbnew 7's Python interface cannot build it). Total 2.40 mm:
# mask 0.01, Cu 0.035, prepreg 0.15, Cu 0.035, core 1.94, Cu 0.035, prepreg 0.15, Cu 0.035, mask 0.01.
# Dielectric constant 4.2 and loss tangent 0.02 are placeholders for a polyimide laminate until the fab names one.
DIEL = '(material "Polyimide") (epsilon_r 4.2) (loss_tangent 0.02)'
STACK = f"""  (setup
    (stackup
      (layer "F.SilkS" (type "Top Silk Screen"))
      (layer "F.Paste" (type "Top Solder Paste"))
      (layer "F.Mask" (type "Top Solder Mask") (thickness 0.01))
      (layer "F.Cu" (type "copper") (thickness 0.035))
      (layer "dielectric 1" (type "prepreg") (thickness 0.15) {DIEL})
      (layer "In1.Cu" (type "copper") (thickness 0.035))
      (layer "dielectric 2" (type "core") (thickness 1.94) {DIEL})
      (layer "In2.Cu" (type "copper") (thickness 0.035))
      (layer "dielectric 3" (type "prepreg") (thickness 0.15) {DIEL})
      (layer "B.Cu" (type "copper") (thickness 0.035))
      (layer "B.Mask" (type "Bottom Solder Mask") (thickness 0.01))
      (layer "B.Paste" (type "Bottom Solder Paste"))
      (layer "B.SilkS" (type "Bottom Silk Screen"))
      (copper_finish "ENIG")
      (dielectric_constraints no)
    )"""
_t = open(f"{OUT}/slant_carrier.kicad_pcb").read()
assert _t.count("  (setup\n") == 1
_t = _t.replace("  (setup", STACK, 1)
open(f"{OUT}/slant_carrier.kicad_pcb", "w").write(_t)
json.dump(LOG, open(f"{OUT}/placement.json", "w"), indent=1)
print("footprints", len(FPS), "nets", len(NETS), "passives placed", len(LOG["passives"]))
print("courtyard overlaps", over)
print("outside the board", outside)
print("barrier pad check", viol)
print("domain misplaced", LOG["domain_misplaced"])

