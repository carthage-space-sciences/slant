"""Negotiated routing (PathFinder; McMurchie and Ebeling, 1995) of the carrier board's remaining nets, on top of the
fixed critical routing from route_critical.py. Used in place of Freerouting, which made no progress on this board.

Every pad and every critical (locked) track is a hard obstacle, with the clearances of rt.py (net classes, the 2.5 mm
barrier as regions, 0.8 mm to chassis). The nets routed here may cross one another's clearance zones at a price. Each
round reroutes every net in turn; a cell inside another new net's zone costs (1 + h) * p, where p grows each round and
the history h of a cell grows each time a conflict sits on it. Rounds stop when no new net violates another's clearance.
GND is left to the pours and plane vias afterwards (route_rest.py step 2).

Usage: python3 negotiate.py <in.kicad_pcb> <out.kicad_pcb> [max rounds]   (.kicad_pro beside the input)
"""
import sys, time, json, math
import numpy as np
from scipy import ndimage as ndi
from skimage.graph import MCP_Geometric
from shapely.geometry import LineString, Point
from shapely.ops import unary_union
import rt

src, dst = sys.argv[1], sys.argv[2]
ROUNDS = int(sys.argv[3]) if len(sys.argv) > 3 else 25
t0 = time.time()
B = rt.Board(src)
RES, M = rt.RES, rt.MARGIN
V_SIG = (0.6, 0.3)
DONE_HOST = {"BUS_IN", "BUS_F", "BUS_SW", "BUS_FILT", "FILT_DAMP", "PRI_RTN", "HOST_THERM_A", "HOST_THERM_B",
             "LIM_UVLO", "LIM_ILIM", "LIM_IMON", "LIM_DVDT", "LIM_SHDN", "LIM_FLT"}
CHASSIS_PADS = {("J1", "26"), ("R14", "2"), ("C19", "2"), ("H3", "1")}
OFFS = [(0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1), (0, 1, 1), (0, 1, -1), (0, -1, 1), (0, -1, -1), (1, 0, 0),
        (-1, 0, 0)]
J1MASK = rt.raster([rt.J1BOX], 1).astype(bool)


def widths(net):
    c = B.netcls[B.netid[net]]
    return {"Default": (0.2, 0.15), "PowerLow": (0.4, 0.25), "Power": (0.3, 0.2), "Chassis": (0.5, 0.3),
            "Diff120": (0.15, 0.15), "USB90": (0.205, 0.15)}.get(c, (0.2, 0.15))


# ------------------------------------------------------------------ nets and their fixed (hard) costs
nets = {}
for p in B.pads:
    if p["net"] and p["net"] not in DONE_HOST and p["net"] != "GND":
        if p["net"] == "CHASSIS" and (p["ref"], p["num"]) not in CHASSIS_PADS:
            continue
        nets.setdefault(p["net"], []).append(p)
nets = {n: ps for n, ps in nets.items() if len(ps) >= 2}


def components(k, conn, drill):
    lab, n0 = {}, 0
    for L in rt.LAY:
        l, n = ndi.label(conn[L] == k)
        l[l > 0] += n0
        lab[L] = l; n0 += n
    parent = np.arange(n0 + 1)

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]; a = parent[a]
        return a
    d = drill == k
    for a, b in set(zip(lab["F"][d].tolist(), lab["B"][d].tolist())):
        if a and b:
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[max(ra, rb)] = min(ra, rb)
    root = np.array([find(i) for i in range(n0 + 1)])
    return {L: root[lab[L]] for L in rt.LAY}


HARD = {}


def hard(net):
    """Open cells for this net among the fixed copper, at its width (or neck width if a pad has no open cell)."""
    if net in HARD:
        return HARD[net]
    w, nk = widths(net)
    pads = nets[net]
    for width in (w, nk):
        hw = width / 2
        al = B.allowed(net, hw)
        dm = B.dist_maps(net)
        oc = B.open_cells(dm, hw, al)
        oc = B.refine(net, hw, oc, al, unary_union([p["poly"].buffer(0.6) for p in pads]))
        vr = V_SIG[0] / 2
        vo = B.open_cells(dm, vr, B.allowed(net, vr))
        via_ok = vo["F"] & vo["B"] & oc["F"] & oc["B"] & ~J1MASK
        padmask = {id(p): rt.raster([p["poly"]], 1).astype(bool) for p in pads}
        cells = {}
        for p in pads:
            c = []
            for zi, L in ((0, "F"), (2, "B")):
                if L in p["layers"]:
                    ii, jj = np.nonzero(padmask[id(p)] & oc[L])
                    c += [(zi, i, j) for i, j in zip(ii, jj)]
            cells[id(p)] = c
        if all(cells.values()) or width == nk:
            HARD[net] = dict(width=width, oc=oc, via_ok=via_ok, cells=cells, padmask=padmask)
            return HARD[net]


# ------------------------------------------------------------------ soft state
# new copper, nets per cell, kept per clearance group: "a" nets with 0.15 mm net-class clearance, "b" with 0.2 mm;
# new chassis copper separately (0.8 mm)
occ = {g: {L: np.zeros((rt.NY, rt.NX), np.int16) for L in rt.LAY} for g in ("a", "b")}
occ_ch = {L: np.zeros((rt.NY, rt.NX), bool) for L in rt.LAY}


def group(net):
    return "a" if B.clr[B.netid[net]] < 0.175 else "b"


CLRG = {"a": 0.15, "b": 0.2}
hist = {L: np.zeros((rt.NY, rt.NX), np.float32) for L in rt.LAY}
routes = {n: dict(items=[], cells={L: np.array([], np.int64) for L in rt.LAY}) for n in nets}


def item_geoms(items):
    g = {L: [] for L in rt.LAY}
    for it in items:
        if it[0] == "T":
            _, L, pts, w = it
            g[L].append(LineString(pts).buffer(w / 2) if len(pts) > 1 else Point(pts[0]).buffer(w / 2))
        else:
            _, pos, dia, drill = it
            for L in rt.LAY:
                g[L].append(Point(pos).buffer(dia / 2))
    return g


def put(net, sign):
    r = routes[net]
    for L in rt.LAY:
        np.add.at(occ[group(net)][L].ravel(), r["cells"][L], sign)
        if net == "CHASSIS":
            occ_ch[L].ravel()[r["cells"][L]] = sign > 0


def route_net(net, pf):
    """Reroute one net with the current soft costs. Returns the pads it could not reach."""
    k = B.netid[net]
    H = hard(net)
    width = H["width"]; hw = width / 2
    vr = V_SIG[0] / 2
    cost = np.full((3, rt.NY, rt.NX), np.inf)
    zone_v = None
    for zi, L in ((0, "F"), (2, "B")):
        z = np.zeros((rt.NY, rt.NX), bool); zv = np.zeros((rt.NY, rt.NX), bool)
        for g in ("a", "b"):
            other = occ[g][L] > 0
            if not other.any():
                continue
            d = ndi.distance_transform_edt(~other) * RES
            need = 0.8 if net == "CHASSIS" else max(B.clr[k], CLRG[g])
            z |= d < need + hw + 0.03
            zv |= d < need + vr + 0.03
        if net != "CHASSIS" and occ_ch[L].any():
            dc = ndi.distance_transform_edt(~occ_ch[L]) * RES
            z |= dc < 0.8 + hw + 0.03; zv |= dc < 0.8 + vr + 0.03
        c = 1.0 + hist[L] + pf * z * (1.0 + hist[L])
        cost[zi] = np.where(H["oc"][L], c, np.inf)
        zone_v = zv if zone_v is None else (zone_v | zv)
    cost[1] = np.where(H["via_ok"], rt.VIA_COST * (1.0 + pf * zone_v), np.inf)
    # own copper of this net: fixed (pads, locked tracks) plus what this round adds
    conn = {L: B.conn[L].copy() for L in rt.LAY}
    cl = {L: B.cl[L].copy() for L in rt.LAY}
    drill = B.drill.copy()
    items = []
    pads = nets[net]
    cells = H["cells"]; padmask = H["padmask"]
    todo = [p for p in pads if cells[id(p)]]
    unreach = [p for p in pads if not cells[id(p)]]
    if not todo:
        return items, unreach
    cx = np.mean([p["pos"][0] for p in todo]); cy = np.mean([p["pos"][1] for p in todo])
    todo.sort(key=lambda p: math.hypot(p["pos"][0] - cx, p["pos"][1] - cy))
    tree = [todo.pop(0)]

    def ids_of(p, C):
        s = set()
        for L in p["layers"]:
            v = np.unique(C[L][padmask[id(p)]]); s |= set(v[v > 0].tolist())
        return s
    while todo:
        C = components(k, conn, drill)
        tid = set()
        for p in tree:
            tid |= ids_of(p, C)
        for q in list(todo):
            if ids_of(q, C) & tid:
                todo.remove(q); tree.append(q)
        if not todo:
            break
        starts = []
        for p in tree:
            starts += cells[id(p)]
        ta = np.array(sorted(tid))
        for zi, L in ((0, "F"), (2, "B")):
            ii, jj = np.nonzero((cl[L] == k) & np.isin(C[L], ta) & np.isfinite(cost[zi]))
            starts += [(zi, i, j) for i, j in zip(ii, jj)]
        ends, owner = [], {}
        for p in todo:
            for c in cells[id(p)]:
                ends.append(c); owner[c] = p
        mcp = MCP_Geometric(cost, offsets=OFFS)
        cum, _ = mcp.find_costs(starts, ends, find_all_ends=False)
        reached = [c for c in ends if np.isfinite(cum[c])]
        if not reached:
            unreach += todo
            break
        end = min(reached, key=lambda c: cum[c])
        path = mcp.traceback(end)
        p = owner[end]
        new = []
        run = None
        for z, i, j in path:
            if z == 1:
                if run and len(run[1]) > 1:
                    new.append(("T", run[0], rt.simplify(run[1]), width))
                run = None
                new.append(("V", rt.xy(i, j), *V_SIG))
                continue
            L = "F" if z == 0 else "B"
            if run and run[0] == L:
                run[1].append(rt.xy(i, j))
            else:
                if run and len(run[1]) > 1:
                    new.append(("T", run[0], rt.simplify(run[1]), width))
                run = (L, [rt.xy(i, j)])
        if run and len(run[1]) > 1:
            new.append(("T", run[0], rt.simplify(run[1]), width))
        if not [it for it in new if it[0] == "T"] and not [it for it in new if it[0] == "V"]:
            zi, i, j = end
            minx, miny, maxx, maxy = p["poly"].bounds
            new.append(("T", "F" if zi == 0 else "B", [rt.xy(i, j), p["pos"]], min(width, maxx - minx, maxy - miny)))
        # dedupe consecutive vias at one point
        seen = set(); new2 = []
        for it in new:
            if it[0] == "V":
                key = (round(it[1][0], 3), round(it[1][1], 3))
                if key in seen:
                    continue
                seen.add(key)
            new2.append(it)
        for it in new2:
            if it[0] == "T":
                _, L, pts, w = it
                g = LineString(pts)
                rt.raster([g.buffer(max(w / 2 - 0.04, 0.02))], k, conn[L], np.int32)
                rt.raster([g.buffer(0.03)], k, cl[L], np.int32)
            else:
                _, pos, dia, drl = it
                g = Point(pos).buffer(dia / 2)
                rt.raster([g], k, drill, np.int32)
                for L in rt.LAY:
                    rt.raster([g.buffer(-0.04)], k, conn[L], np.int32)
                    rt.raster([g.buffer(-0.03)], k, cl[L], np.int32)
        items += new2
        todo.remove(p); tree.append(p)
    return items, unreach


def set_route(net, items):
    put(net, -1)
    g = item_geoms(items)
    cells = {}
    for L in rt.LAY:
        m = rt.raster(g[L], 1).astype(bool) if g[L] else np.zeros((rt.NY, rt.NX), bool)
        cells[L] = np.flatnonzero(m)
    routes[net] = dict(items=items, cells=cells)
    put(net, +1)


def conflicts():
    """Cells of each new net's copper that lie within the clearance of another new net's copper."""
    out = {}
    total = 0
    for n in nets:
        r = routes[n]
        bad = {}
        for L in rt.LAY:
            if not len(r["cells"][L]):
                bad[L] = np.array([], np.int64); continue
            mine = np.zeros(rt.NY * rt.NX, bool); mine[r["cells"][L]] = True
            hitmask = np.zeros(rt.NY * rt.NX, bool)
            for g in ("a", "b"):
                other = occ[g][L].ravel() - (mine.astype(np.int16) if group(n) == g else 0) > 0
                if not other.any():
                    continue
                need = 0.8 if n == "CHASSIS" else max(B.clr[B.netid[n]], CLRG[g])
                d = ndi.distance_transform_edt(~other.reshape(rt.NY, rt.NX)) * RES
                hitmask |= (d.ravel() < need) & mine
            if n != "CHASSIS" and occ_ch[L].any():
                dc = ndi.distance_transform_edt(~occ_ch[L]) * RES
                hitmask |= (dc.ravel() < 0.8) & mine
            bad[L] = np.flatnonzero(hitmask)
            total += len(bad[L])
        out[n] = bad
    return out, total


order = sorted(nets, key=lambda n: (n != "CHASSIS", not any(p["ref"] == "M1" for p in nets[n]),
                                    sum(abs(p["pos"][0] - nets[n][0]["pos"][0]) + abs(p["pos"][1] - nets[n][0]["pos"][1])
                                        for p in nets[n])))
LOG = dict(rounds=[])
pf = 0.5
unreached = {}
last_conflict, last_unreached = set(), {}
for rnd in range(ROUNDS):
    t1 = time.time()
    unreached = {}
    redo = order if rnd < 2 else [n for n in order if n in last_conflict or n in last_unreached]
    for n in redo:
        put(n, -1)                                   # this net's previous route is not an obstacle to itself
        routes[n]["cells"] = {L: np.array([], np.int64) for L in rt.LAY}
        items, u = route_net(n, pf)
        set_route(n, items)
        if u:
            unreached[n] = [f"{p['ref']}.{p['num']}" for p in u]
    for n in order:
        if n not in redo and n in last_unreached:
            unreached[n] = last_unreached[n]
    conf, total = conflicts()
    nets_in_conflict = sorted(n for n, b in conf.items() if any(len(v) for v in b.values()))
    LOG["rounds"].append(dict(round=rnd + 1, conflict_cells=int(total), nets_in_conflict=nets_in_conflict,
                              unreached=unreached, pf=pf, s=round(time.time() - t1)))
    print(f"round {rnd + 1}: conflict cells {total}, nets {len(nets_in_conflict)}, unreached "
          f"{sum(len(v) for v in unreached.values())} pads, pf {pf:.2f}, {time.time() - t1:.0f}s", flush=True)
    last_conflict, last_unreached = set(nets_in_conflict), dict(unreached)
    if total == 0:
        break
    for n, b in conf.items():
        for L in rt.LAY:
            hist[L].ravel()[b[L]] += 0.5
    pf *= 1.6
    # nets in conflict go first next round
    order = [n for n in order if n in nets_in_conflict] + [n for n in order if n not in nets_in_conflict]

# ------------------------------------------------------------------ commit to the board
for n in nets:
    for it in routes[n]["items"]:
        if it[0] == "T":
            B.add_track(n, it[1], it[2], it[3], lock=False)
        else:
            B.add_via(n, it[1], it[2], it[3], lock=False)
B.save(dst)
LOG["unreached"] = unreached
LOG["final_conflict_cells"] = LOG["rounds"][-1]["conflict_cells"]
LOG["pruned_segments"] = rt.prune_file(dst, B.pads)
json.dump(LOG, open(dst.replace(".kicad_pcb", "-negotiate-log.json"), "w"), indent=1)
print("done", f"{time.time() - t0:.0f}s", "unreached", unreached, "pruned", LOG["pruned_segments"])
